"""Read the supplied catalogue export without third-party packages."""
import base64, io, json, re, zipfile, xml.etree.ElementTree as ET
from decimal import Decimal, InvalidOperation
from collections import Counter, defaultdict

NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
HEADERS=['UUID','Код','Наименование','Единица измерения','Цена: Цена продажи','Штрихкод EAN13','Архивный']

def read_xlsx(encoded):
    try: content=base64.b64decode(encoded,validate=True)
    except Exception: raise ValueError('Не удалось прочитать файл')
    if len(content)>8_000_000: raise ValueError('Файл превышает 8 МБ')
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            if sum(i.file_size for i in z.infolist())>60_000_000: raise ValueError('Распакованный файл слишком большой')
            shared=[]
            if 'xl/sharedStrings.xml' in z.namelist():
                tree=ET.fromstring(z.read('xl/sharedStrings.xml'))
                shared=[''.join(x.itertext()) for x in tree.findall('s:si',NS)]
            sheets=[x for x in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',x)]
            found=[]
            for name in sheets:
                tree=ET.fromstring(z.read(name)); output=[]
                for row in tree.findall('s:sheetData/s:row',NS):
                    cells={}
                    for c in row.findall('s:c',NS):
                        ref=c.get('r',''); match=re.match('[A-Z]+',ref)
                        if not match: continue
                        col=0
                        for letter in match[0]: col=col*26+ord(letter)-64
                        if col>200: continue
                        v=c.find('s:v',NS); text=v.text if v is not None else ''
                        if c.get('t')=='s': text=shared[int(text)]
                        elif c.get('t')=='inlineStr': text=''.join(c.find('s:is',NS).itertext())
                        cells[col-1]=(text or '').strip()
                    if cells: output.append((int(row.get('r','0')),cells))
                if not output: continue
                headers=output[0][1]
                if not all(h in headers.values() for h in HEADERS): continue
                records=[{'_row':n,**{title:values.get(i,'') for i,title in headers.items()}} for n,values in output[1:] if any(values.values())]
                found.append(records)
            if len(found)!=1: raise ValueError('Нужен один лист с колонками UUID, Код, Наименование, Единица измерения, Цена: Цена продажи, Штрихкод EAN13, Архивный')
            if not 1<=len(found[0])<=10000: raise ValueError('Допустимо от 1 до 10 000 товаров')
            return found[0]
    except (zipfile.BadZipFile,ET.ParseError,KeyError,IndexError,TypeError): raise ValueError('Некорректный XLSX-файл')

def barcodes(p):
    aliases=p.get('barcodes','[]')
    if isinstance(aliases,str): aliases=json.loads(aliases)
    return list(dict.fromkeys(([p['barcode']] if p.get('barcode') else [])+aliases))

def prepare(raw,existing,include_all=False):
    normalized=[]
    for r in raw:
        notes=[]; errors=[]; review=[]
        name=r.get('Наименование','').strip(); code=r.get('Код','').strip(); uid=r.get('UUID','').strip(); group=r.get('Группы','').strip(); unit=r.get('Единица измерения','').strip().lower()
        if not name or len(name)>300: errors.append('Пустое или слишком длинное название')
        if not uid or not code: errors.append('Нет UUID или кода')
        if r.get('Валюта (Цена продажи)') not in ('руб','RUB',''): errors.append('Цена не в рублях')
        kind={'шт':'piece','кг':'weight','л; дм3':'draft','л':'draft'}.get(unit)
        if not unit:
            # 0.5.1: карточка, созданная без единицы измерения (через API или импорт), не пропадает с кассы.
            low=name.lower()
            if r.get('Разливной товар')=='да' or '(розлив' in low:kind='draft';guess='л'
            elif r.get('Весовой товар')=='да' or '(вес' in low:kind='weight';guess='кг'
            else:kind='piece';guess='шт'
            notes.append('Единица измерения не указана в МоемСкладе: принято «'+guess+'»')
        if not kind: errors.append('Неизвестная единица измерения: '+unit)
        if group.upper()=='ТАРА' and re.search(r'пэт.*бутыл',name,re.I): kind='packaging'
        try:
            n=Decimal(r.get('Цена: Цена продажи','').replace(' ','').replace('\xa0','').replace(',','.'))*100
            if not n.is_finite() or n!=n.to_integral_value() or n<0 or n>10**12: raise InvalidOperation()
            price=int(n)
        except (InvalidOperation,ValueError):price=0;errors.append('Некорректная розничная цена')
        codes=[]
        for key,value in r.items():
            if key.startswith('Штрихкод') and value:
                codes.extend(re.split(r'[\s;,]+',value))
        codes=list(dict.fromkeys(c for c in codes if c))
        if any(len(c)>100 for c in codes):errors.append('Некорректный штрихкод')
        if not codes:notes.append('Нет штрихкода')
        if len(codes)>1:notes.append('Несколько штрихкодов: '+str(len(codes)))
        archive=r.get('Архивный','').lower()=='да'
        if not archive:
            if price==0:review.append('Нулевая цена')
            if group.upper()=='БОНУСЫ':review.append('Бонус или уценка: проверьте назначение и единицу')
            if group=='Металл тара (кеги)':review.append('Возвратная кега: подтвердите использование в рознице')
            if 'дренаж' in name.lower():review.append('Служебная строка слива: не обычная продажа напитка')
            if name.lower()=='пегас':review.append('Оборудование: подтвердите назначение')
        if kind=='draft' and r.get('Разливной товар')!='да':notes.append('Тип «разливной» определён по единице «литр»')
        if kind=='weight' and r.get('Весовой товар')!='да':notes.append('Тип «весовой» определён по единице «кг»')
        normalized.append({'row':r['_row'],'source_uuid':uid,'source_code':code,'source_folder_uuid':r.get('_folder_uuid',''),'name':name,'category':group,'kind':kind,'price':price,'barcode':codes[0] if codes else '', 'barcodes':codes,'active':0 if archive else 1,'notes':notes,'errors':errors,'review':review})
    by_uuid=Counter(x['source_uuid'] for x in normalized);by_code=Counter(x['source_code'] for x in normalized)
    # 0.5.14: архивная карточка не владеет штрихкодом — его можно перенести на новую карточку.
    owners=defaultdict(set)
    for x in normalized:
        for c in x['barcodes']:
            if x['active']:owners[c].add(x['source_uuid'])
    for x in normalized:
        if not x['active']:x['barcodes']=[c for c in x['barcodes'] if not owners[c]];x['barcode']=x['barcodes'][0] if x['barcodes'] else ''
    existing_uuid={p['source_uuid']:p for p in existing if p.get('source_uuid')}
    existing_barcodes=defaultdict(set)
    existing_names=defaultdict(set)
    existing_by_id={p['id']:p for p in existing}
    for p in existing:
        # Товар, уже связанный с карточкой МоегоСклада, сопоставляется только по UUID. По штрихкоду и
        # названию ищем лишь старые товары без связи: другая карточка — это другой товар.
        if p.get('source_uuid'):continue
        for c in barcodes(p):existing_barcodes[c].add(p['id'])
        existing_names[' '.join(p['name'].lower().replace('ё','е').split())].add(p['id'])
    for x in normalized:
        if by_uuid[x['source_uuid']]>1 or by_code[x['source_code']]>1:x['errors'].append('Повтор UUID или кода в файле')
        if any(len(owners[c])>1 for c in x['barcodes']):x['errors'].append('Штрихкод принадлежит нескольким карточкам файла')
        matches=set().union(*(existing_barcodes[c] for c in x['barcodes'])) if x['barcodes'] else set()
        known=existing_uuid.get(x['source_uuid'])
        if known: matches.add(known['id'])
        if len(matches)>1:x['errors'].append('UUID и штрихкоды указывают на разные товары базы')
        target=existing_by_id[next(iter(matches))] if len(matches)==1 else None
        if target and target.get('source_uuid') not in ('',None,x['source_uuid']):x['errors'].append('Товар базы связан с другим UUID')
        linked=bool(target and target.get('source_uuid')==x['source_uuid'])
        # Та же карточка МоегоСклада: новая единица измерения (л→кг) и цена принимаются, а не замораживают старые.
        if target and x['kind'] and target['kind']!=x['kind']:
            if linked:x['previous_kind']=target['kind'];x['notes'].append('Единица измерения изменена в МоемСкладе')
            else:x['errors'].append('Тип товара базы отличается: требуется ручная проверка')
        # Карточку с ошибкой можно оставить в продаже, только если её цена и тип в кассе не устарели.
        x['keep']=bool(target and target.get('active') and x['active'] and x['price']==target['price']
                       and 'Некорректная розничная цена' not in x['errors'] and x['kind'] in (None,target['kind']))
        if not target and existing_names[' '.join(x['name'].lower().replace('ё','е').split())]:x['errors'].append('В базе есть такое название с другим штрихкодом: сопоставьте вручную')
        x['target_id']=target['id'] if target else None
        x['action']='update' if target else 'create'
        if include_all:
            x['notes'].extend(x['review']); x['review']=[]
        x['state']='error' if x['errors'] else 'review' if x['review'] else 'ready'
    assigned=Counter(x['target_id'] for x in normalized if x['target_id'])
    for x in normalized:
        if x['target_id'] and assigned[x['target_id']]>1:x['errors'].append('Несколько строк файла сопоставлены одной карточке');x['state']='error';x['keep']=False
    return normalized

"""Offline update from an official BeerMag ZIP; keeps data and restores code on failure."""
import argparse
import io
import json
import os
import re
import shutil
import socket
import sqlite3
import stat
import sys
import tempfile
import zipfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import app_lock


# Запущенные bat-файлы обновления не переписываются под cmd.exe (ОБНОВИТЬ_КАССУ.bat — копия UPDATE_WINDOWS.bat).
RUNNING_UPDATERS=('UPDATE_WINDOWS.bat','ОБНОВИТЬ_КАССУ.bat')
PROTECTED=('data','demo_data','updates')


def windows_name(part):
    """Имя так, как его поймёт Windows: без учёта регистра, без точек и пробелов в конце."""
    return part.rstrip(' .').lower()


def members(archive,keep=()):
    files = []
    seen = set()
    keep={windows_name(x) for x in keep}
    with zipfile.ZipFile(archive) as package:
        if sum(i.file_size for i in package.infolist()) > 1_000_000_000:
            raise ValueError('Архив слишком большой.')
        if package.testzip():
            raise ValueError('Архив повреждён.')
        for info in package.infolist():
            if '\\' in info.filename or ':' in info.filename:
                raise ValueError('В архиве обнаружен недопустимый путь.')
            path = PurePosixPath(info.filename)
            if info.is_dir():
                continue
            if path.is_absolute() or len(path.parts)<2 or path.parts[0]!='BeerMag' or any(p in ('..','') for p in path.parts):
                raise ValueError('В архиве обнаружен недопустимый путь.')
            # Windows не различает Data, data., data␠ и DATA~1: такие имена в архиве не принимаются вовсе.
            if any(p!=p.rstrip(' .') or re.search(r'~\d',p) for p in path.parts[1:]):
                raise ValueError('В архиве обнаружен недопустимый путь.')
            relative = Path(*path.parts[1:])
            name=windows_name(relative.as_posix())
            if name in keep:
                continue
            if windows_name(relative.parts[0]) in PROTECTED or relative.suffix.lower()=='.pyc':
                raise ValueError('Архив пытается изменить данные кассы.')
            if stat.S_ISLNK(info.external_attr >> 16) or name in seen:
                raise ValueError('В архиве обнаружена ссылка или повторяющийся файл.')
            seen.add(name)
            files.append((info,relative))
        if not {'server.py','web/app.js','readme.md'}.issubset(seen):
            raise ValueError('Это не полный архив программы BeerMag.')
        runtime=next((i for i,r in files if windows_name(r.as_posix())=='runtime/python313.zip'),None)
        if runtime:
            try:
                with zipfile.ZipFile(io.BytesIO(package.read(runtime))) as standard:
                    if 'encodings/__init__.pyc' not in standard.namelist() or standard.testzip():
                        raise ValueError('Встроенный Python повреждён: нет стандартной библиотеки.')
            except (zipfile.BadZipFile,EOFError):
                raise ValueError('Встроенный Python повреждён: не читается стандартная библиотека.') from None
    return files


def snapshot_database(root,stamp):
    database=root/'data'/'beerdesk.sqlite3'
    if not database.exists():
        return None
    destination=root/'data'/'backups'/('beerdesk-before-update-'+stamp+'.sqlite3')
    destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix('.tmp')
    try:
        with closing(sqlite3.connect(database)) as source,closing(sqlite3.connect(temporary)) as target:
            source.backup(target)
        with closing(sqlite3.connect(temporary)) as check:
            if check.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                raise sqlite3.DatabaseError('Резервная копия повреждена.')
        os.replace(temporary,destination)
    finally:
        try:temporary.unlink(missing_ok=True)
        except OSError:pass  # A cleanup failure must not mask the backup error.
    return destination


BACKUP_INFO='_beermag_backup.json'
BLOCKED='update-blocked.json'


def register_closed():
    # The lock is understood by this and subsequent releases. Also catch a
    # standard-port process running a release from before the lock existed.
    for port in (8765,8766):
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.15):
                raise RuntimeError('Закройте окно работающей кассы и демо перед обновлением.')
        except (ConnectionRefusedError,TimeoutError,OSError):
            pass


def program_version(folder):
    try:m=re.search(r'BeerMag (\d+\.\d+\.\d+)',(Path(folder)/'server.py').read_text(encoding='utf-8')[:200])
    except OSError:return ''
    return m.group(1) if m else ''


def blocked_versions(root):
    try:return {str(x) for x in json.loads((Path(root)/'data'/BLOCKED).read_text(encoding='utf-8'))}
    except (OSError,ValueError,TypeError):return set()


def block_version(root,version):
    """Отозванную на этой кассе версию автообновление больше не скачивает (ждёт следующую)."""
    if not version:return
    path=Path(root)/'data'/BLOCKED;path.parent.mkdir(parents=True,exist_ok=True)
    versions=sorted(blocked_versions(root)|{version})
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(versions),encoding='utf-8');os.replace(temporary,path)


def last_backup(root):
    """Самая свежая неиспользованная копия прежней версии (папки before-<время> сортируются по времени)."""
    folders=sorted(p for p in (Path(root)/'updates').glob('before-*') if p.is_dir())
    return folders[-1] if folders else None


def backup_info(backup):
    try:info=json.loads((backup/BACKUP_INFO).read_text(encoding='utf-8'))
    except (OSError,ValueError):info={}
    if 'existed' not in info:   # копия от 0.5.8 и раньше: описи нет, возвращаем то, что в ней лежит
        info['existed']=sorted(p.relative_to(backup).as_posix() for p in backup.rglob('*') if p.is_file() and p.name!=BACKUP_INFO)
        info['files']=info['existed']
    return info


def restore_database(root,snapshot,label):
    """Вернуть базу из копии, сделанной перед обновлением. Текущая база откладывается рядом, не удаляется."""
    database=root/'data'/'beerdesk.sqlite3'
    aside=root/'data'/'backups'/('beerdesk-failed-update-'+label+'.sqlite3')
    aside.parent.mkdir(parents=True,exist_ok=True)
    if database.exists():
        try:
            with closing(sqlite3.connect(database)) as source,closing(sqlite3.connect(aside)) as target:
                source.backup(target)
        except sqlite3.DatabaseError:   # база повреждена: откладываем её файлы как есть
            aside.unlink(missing_ok=True);shutil.copy2(database,aside)
            for extra in ('-wal','-shm'):
                if Path(str(database)+extra).is_file():shutil.copy2(str(database)+extra,str(aside)+extra)
    temporary=database.with_suffix('.restore')
    shutil.copy2(snapshot,temporary)
    with closing(sqlite3.connect(temporary)) as check:
        ok=check.execute('PRAGMA quick_check').fetchone()[0]=='ok'
    if not ok:
        temporary.unlink(missing_ok=True);raise sqlite3.DatabaseError('Копия базы перед обновлением повреждена.')
    for leftover in (Path(str(database)+'-wal'),Path(str(database)+'-shm')):
        leftover.unlink(missing_ok=True)
    os.replace(temporary,database)
    return aside


# Таблицы, по которым видно, что в новой версии уже работали: продажи, смены, деньги, возвраты, очередь.
BUSINESS=('documents','shifts','cash_movements','sale_returns','ms_outbox')


def newer_data(database,snapshot):
    """True — в рабочей базе есть операции, которых нет в копии перед обновлением (их нельзя терять).

    Повреждённая или нечитаемая база не бережётся: False, её заменит копия.
    """
    try:
        with closing(sqlite3.connect(Path(database).resolve().as_uri()+'?mode=ro',uri=True)) as now, \
             closing(sqlite3.connect(Path(snapshot).resolve().as_uri()+'?mode=ro&immutable=1',uri=True)) as before:
            if now.execute('PRAGMA quick_check').fetchone()[0]!='ok':return False
            names=lambda d:{r[0] for r in d.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            have,had=names(now),names(before)
            for table in BUSINESS:
                if table not in have:continue
                query='SELECT COUNT(*),COALESCE(MAX(rowid),0) FROM "%s"'%table
                n,top=now.execute(query).fetchone();n0,top0=before.execute(query).fetchone() if table in had else (0,0)
                if n>n0 or top>top0:return True
                if table=='ms_outbox':   # задания, переданные в МойСклад уже из новой версии
                    sent="SELECT COUNT(*) FROM ms_outbox WHERE status IN ('sent','skipped')"
                    if now.execute(sent).fetchone()[0]>(before.execute(sent).fetchone()[0] if table in had else 0):return True
    except (sqlite3.Error,OSError):return False
    return False


INSTALLING='installing.json'


def remove_tree(path):
    def writable(function,name,_):
        try:os.chmod(name,stat.S_IWRITE);function(name)
        except OSError:pass
    if Path(path).is_dir():shutil.rmtree(path,**{'onexc' if sys.version_info>=(3,12) else 'onerror':writable})


def write_json(path,data):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(data,ensure_ascii=False,indent=1),encoding='utf-8')
    os.replace(temporary,path)


def recover(root):
    """Довести до конца или отменить установку, прерванную выключением или сбоем (вызывать под блокировкой).

    Пока идёт установка, в updates/installing.json лежит опись: новые файлы ждут в updates/staging-<время>,
    прежние — в updates/partial-<время>. Если новые файлы на месте, установка завершается; если нет — всё
    возвращается к прежней версии. Возвращает {'result':'finished'|'rolled_back','from','to'} или None.
    """
    root=Path(root).resolve();updates=root/'updates';marker=updates/INSTALLING
    result=None
    if marker.is_file():
        try:info=json.loads(marker.read_text(encoding='utf-8'));stamp=str(info['stamp']);files=list(info['files'])
        except (OSError,ValueError,KeyError,TypeError):info=None
        if info is None:raise RuntimeError('Опись прерванной установки обновления повреждена (updates\\installing.json). Обратитесь к разработчику.')
        staging=updates/('staging-'+stamp);partial=updates/('partial-'+stamp);backup=updates/('before-'+stamp)
        saved=partial if partial.is_dir() else backup
        if staging.is_dir():
            for name in files:   # в описи server.py последний: версия меняется, когда остальные файлы уже новые
                if (staging/name).is_file():
                    (root/name).parent.mkdir(parents=True,exist_ok=True);os.replace(staging/name,root/name)
            if partial.is_dir():os.replace(partial,backup)
            result={'result':'finished','from':info.get('from',''),'to':info.get('to','')}
        else:
            existed=set(info.get('existed',[]))
            for name in sorted(files,key=lambda x:x=='server.py'):
                if name in existed:(root/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(saved/name,root/name)
                else:(root/name).unlink(missing_ok=True)
            remove_tree(saved)
            if info.get('snapshot'):(root/'data'/'backups'/info['snapshot']).unlink(missing_ok=True)
            result={'result':'rolled_back','from':info.get('to',''),'to':info.get('from','')}
        marker.unlink()
        remove_tree(staging)
    # Остатки установки, прерванной ещё до описи (файлы программы тогда не менялись).
    for leftover in list(updates.glob('staging-*'))+list(updates.glob('partial-*')):remove_tree(leftover)
    return result


def prune_updates(root,keep=3):
    """Хранить только 3 последние копии прежних версий и баз перед обновлением (диск кассы не бесконечный).

    Самая свежая копия прежней версии (её использует откат) и её база не удаляются никогда.
    """
    root=Path(root);updates=root/'updates';backups=root/'data'/'backups';removed=0
    folders=sorted(p for p in updates.glob('before-*') if p.is_dir())
    for old in folders[:-keep]+sorted(p for p in updates.glob('used-before-*') if p.is_dir())[:-keep]:
        remove_tree(old);removed+=1
    needed={backup_info(p).get('snapshot','') for p in folders[-keep:]}
    for pattern,order in (('beerdesk-before-update-*.sqlite3',lambda p:p.name),('beerdesk-failed-update-*.sqlite3',lambda p:p.stat().st_mtime)):
        try:copies=sorted((p for p in backups.glob(pattern) if p.is_file()),key=order)
        except OSError:continue
        for old in copies[:-keep]:
            if old.name in needed:continue
            try:old.unlink();removed+=1
            except OSError:pass
    return removed


def rollback(root,restore_db=False):
    """Вернуть файлы программы, какими они были до последнего обновления, и отозвать новую версию.

    restore_db=True только при автооткате, когда новая версия не запустилась: тогда база тоже
    возвращается к копии перед обновлением — но только если в новой версии не было продаж, смен,
    денег и передачи в МойСклад. Иначе база остаётся как есть: день продаж дороже новых колонок.
    """
    root=Path(root).resolve()
    with app_lock.exclusive(root/'data'/'beermag.lock'):
        register_closed()
        recover(root)
        backup=last_backup(root)
        if not backup:raise ValueError('Нет сохранённой прежней версии: откатывать не к чему.')
        info=backup_info(backup)
        bad=program_version(root)
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        existed=set(info['existed'])
        # Запущенный bat-файл отката под cmd.exe не переписывается и не удаляется.
        running={'ОТКАТИТЬ_ОБНОВЛЕНИЕ.bat'}
        for name in info['files']:
            if name not in existed and name not in running:(root/name).unlink(missing_ok=True)   # файл появился только в новой версии
        # server.py — последним: прерванный откат не выдаст себя за прежнюю версию.
        for name in sorted(info['existed'],key=lambda x:x=='server.py'):
            if name in running:continue
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(backup/name,target)
        aside=None;kept=False
        snapshot=root/'data'/'backups'/info['snapshot'] if info.get('snapshot') else None
        if restore_db and snapshot and snapshot.is_file():
            if newer_data(root/'data'/'beerdesk.sqlite3',snapshot):kept=True
            else:aside=restore_database(root,snapshot,(bad or 'unknown')+'-'+stamp)
        block_version(root,bad or info.get('to',''))
        # Копия использована: повторный откат не должен вернуть её ещё раз.
        os.replace(backup,backup.with_name('used-'+backup.name))
        try:prune_updates(root)
        except OSError:pass
    return {'from':bad or info.get('to',''),'to':program_version(root) or info.get('from',''),
            'database_restored':bool(aside),'database_kept':kept,'failed_database':str(aside) if aside else ''}


def install(archive,root,keep=()):
    root=Path(root).resolve()
    files=members(archive,keep)
    # Do not overwrite the interpreter that is executing this updater on Windows.
    if (root/'runtime'/'python.exe').is_file():
        files=[(info,path) for info,path in files if windows_name(path.parts[0])!='runtime']
    # server.py ставится последним: по нему касса узнаёт свою версию.
    files.sort(key=lambda item:windows_name(item[1].as_posix())=='server.py')
    if not (root/'server.py').is_file():
        raise ValueError('Запускайте обновление из установленной папки BeerMag.')
    with app_lock.exclusive(root/'data'/'beermag.lock'):
        register_closed()
        recover(root)   # прерванная прошлая установка — до того, как сохранять «прежнюю версию»
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        updates=root/'updates';updates.mkdir(parents=True,exist_ok=True)
        staging=updates/('staging-'+stamp);partial=updates/('partial-'+stamp);backup=updates/('before-'+stamp)
        marker=updates/INSTALLING;snapshot=None;names=[x.as_posix() for _,x in files]
        try:
            with zipfile.ZipFile(archive) as package:
                for info,relative in files:
                    target=staging/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    with package.open(info) as source,target.open('wb') as output:
                        shutil.copyfileobj(source,output)
            snapshot=snapshot_database(root,stamp)
            existed=[]
            for _,relative in files:
                existing=root/relative
                if existing.exists():
                    target=partial/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(existing,target);existed.append(relative.as_posix())
            # Опись копии: по ней откат вернёт прежние файлы и уберёт добавленные обновлением.
            partial.mkdir(parents=True,exist_ok=True)
            description={'from':program_version(root),'to':program_version(staging),'created':stamp,
                         'snapshot':snapshot.name if snapshot else '','files':names,'existed':existed}
            write_json(partial/BACKUP_INFO,description)
            write_json(marker,dict(description,stamp=stamp))   # с этой минуты прерванная установка будет завершена при запуске
        except BaseException:
            remove_tree(staging);remove_tree(partial)
            if snapshot:snapshot.unlink(missing_ok=True)
            raise
        changed=[]
        try:
            for _,relative in files:
                destination=root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                os.replace(staging/relative,destination)
                changed.append(relative)
        except Exception:
            # Неудачная попытка не оставляет ни смеси версий, ни копии, которую откат принял бы за «прежнюю версию».
            for relative in reversed(changed):
                previous=partial/relative
                if previous.exists():shutil.copy2(previous,root/relative)
                else:(root/relative).unlink(missing_ok=True)
            marker.unlink(missing_ok=True);remove_tree(staging);remove_tree(partial)
            if snapshot:snapshot.unlink(missing_ok=True)
            raise
        os.replace(partial,backup);marker.unlink();remove_tree(staging)
        try:prune_updates(root)
        except OSError:pass
    return snapshot,backup


def manual_rollback(parser):
    """ОТКАТИТЬ_ОБНОВЛЕНИЕ.bat: вернуть прежнюю версию программы. База и продажи остаются как есть."""
    root=Path(__file__).resolve().parent
    backup=last_backup(root)
    if not backup:parser.exit(1,'Нет сохранённой прежней версии: откатывать не к чему.\n')
    info=backup_info(backup)
    print('Сейчас установлена версия: '+(program_version(root) or 'неизвестна'))
    print('Будет возвращена версия:  '+(info.get('from') or 'предыдущая (копия от '+backup.name[7:15]+')'))
    print('Продажи, смены и настройки кассы сохранятся. Отозванную версию касса больше не скачает,')
    print('следующее исправленное обновление установится как обычно.')
    if input('Откатить обновление? (д/н): ').strip().lower() not in ('д','да','y','yes'):parser.exit(0,'Отменено.\n')
    try:result=rollback(root)
    except (OSError,ValueError,RuntimeError,sqlite3.Error) as error:
        parser.exit(1,'Откат не выполнен: '+str(error)+'\n')
    (root/'data'/'update-probation.json').unlink(missing_ok=True)
    print('Готово: версия '+result['from']+' отозвана, касса возвращена к версии '+(result['to'] or 'предыдущей')+'.')
    print('Теперь запустите кассу ярлыком «Касса БирМаг».')


def main():
    parser=argparse.ArgumentParser(description='Обновить BeerMag из нового ZIP')
    parser.add_argument('archive',nargs='?',help='Новый архив BeerMag-...-Windows.zip')
    parser.add_argument('--rollback',action='store_true',help='Вернуть версию, стоявшую до последнего обновления')
    args=parser.parse_args()
    if args.rollback:return manual_rollback(parser)
    if not args.archive:
        # Двойной щелчок без файла: ищем самый новый архив в «Загрузках» и рядом с папкой кассы.
        import re
        here=Path(__file__).resolve().parent
        places=[Path(os.environ.get('USERPROFILE',str(Path.home())))/'Downloads',here.parent,here]
        found=[]
        for place in places:
            try:found+=[p for p in place.glob('BeerMag-*-Windows*.zip') if p.is_file()]
            except OSError:pass
        def version(p):
            m=re.search(r'BeerMag-(\d+(?:\.\d+)+)',p.name);return tuple(int(x) for x in m.group(1).split('.')) if m else ()
        if not found:parser.exit(1,'Архив обновления не найден в «Загрузках». Перетащите файл BeerMag-...-Windows.zip на UPDATE_WINDOWS.bat.\n')
        best=max(found,key=lambda p:(version(p),p.stat().st_mtime))
        print('Найден архив: '+str(best))
        if input('Установить это обновление? (д/н): ').strip().lower() not in ('д','да','y','yes'):parser.exit(0,'Отменено.\n')
        args.archive=str(best)
    try:
        snapshot,backup=install(Path(args.archive).resolve(),Path(__file__).resolve().parent,keep=RUNNING_UPDATERS)
    except (OSError,ValueError,RuntimeError,sqlite3.Error,zipfile.BadZipFile) as error:
        parser.exit(1,'Обновление отменено: '+str(error)+'\n')
    print('Файлы программы обновлены. Папка data сохранена.')
    if snapshot:print('Копия базы перед обновлением: '+str(snapshot))
    print('Предыдущие файлы программы: '+str(backup))
    print('Теперь запустите BeerMag обычным способом.')


if __name__=='__main__':
    main()

"""BeerMag 0.5.14. Local-first single-server pilot. Python 3.11+, no dependencies."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
from decimal import Decimal, InvalidOperation, DecimalException, ROUND_HALF_UP
from contextlib import contextmanager, closing
import argparse, hashlib, hmac, json, os, re, secrets, shutil, sqlite3, time, traceback, webbrowser
import catalog_import
import app_lock
import moysklad, moysklad_bridge, packaging_rules, moysklad_outbox, autoupdate
from moysklad_outbox import pay_split
import threading, sys

ROOT = Path(__file__).resolve().parent
DB = Path(os.environ.get('BEERDESK_DB', str(ROOT / 'data' / 'beerdesk.sqlite3')))
# Приложение (значок у часов) передаёт свой ключ: окно кассы открывается с ним,
# поэтому код первой настройки не нужно переписывать из консоли.
SETUP_TOKEN = os.environ.get('BEERMAG_APP_KEY','').strip() or secrets.token_urlsafe(24)
VERSION = re.match(r'BeerMag (\d+\.\d+\.\d+)', __doc__ or '').group(1)   # единственный номер версии — строка 1 файла
ROLES = ('seller', 'admin', 'manager')
FAILURES = {}
SIGNUP_ATTEMPTS = {}

def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
def dumps(v): return json.dumps(v, ensure_ascii=False, separators=(',', ':'))
def rows(db, sql, args=()): return [dict(r) for r in db.execute(sql, args)]
def one(db, sql, args=()):
    r = db.execute(sql, args).fetchone()
    return dict(r) if r else None

def backup_health(d):
    options={x['key']:x['value'] for x in d.execute(
        "SELECT key,value FROM ms_options WHERE key IN ('backup_last','backup_error')")}
    last=options.get('backup_last')
    warning=options.get('backup_error','')
    if not warning and last:
        try:
            if (datetime.now(timezone.utc)-datetime.fromisoformat(last.replace('Z','+00:00'))).total_seconds()>7200:
                warning='Резервная копия не обновлялась более двух часов. Проверьте папку копий.'
        except ValueError:
            warning='Не удалось определить время последней резервной копии.'
    if not warning and not last:warning='Резервная копия ещё не создана.'
    try:
        if shutil.disk_usage(DB.parent).free<500*1024*1024:warning=(warning+' ' if warning else '')+'На диске кассы осталось меньше 500 МБ. Освободите место, иначе продажи остановятся.'
    except OSError:pass
    return {'last':last,'warning':warning,'separate_folder_configured':bool(os.environ.get('BEERMAG_BACKUP_DIR'))}

def queue_health(d, allowed):
    shops={s['id']:{'shop_id':s['id'],'name':s['name'],'pending':0,'retry':0,
                    'first':None,'last_confirmed':None} for s in rows(d,
                    "SELECT s.id,s.name FROM shops s WHERE s.active=1 OR EXISTS(SELECT 1 FROM ms_outbox q WHERE q.shop_id=s.id AND q.status NOT IN ('sent','skipped')) ORDER BY s.name,s.id") if s['id'] in allowed}
    for item in rows(d,'''SELECT q.id,q.shop_id,q.kind,
                              COALESCE(p.document_id,a.document_id,q.local_id) AS local_id,q.status,q.error,
                              COALESCE(p.part_no,a.part_no) AS part_no
        FROM ms_outbox q LEFT JOIN ms_inventory_parts p ON p.job_id=q.id
        LEFT JOIN ms_inventory_adjustments a ON a.job_id=q.id
        WHERE q.status NOT IN ('sent','skipped') ORDER BY q.id'''):
        shop=shops.get(item['shop_id'])
        if not shop:continue
        shop[item['status']]+=1
        if shop['first'] is None:shop['first']=item
    for item in rows(d,"SELECT shop_id,MAX(sent_at) AS last_confirmed FROM ms_outbox WHERE status='sent' AND sent_at IS NOT NULL GROUP BY shop_id"):
        if item['shop_id'] in shops:shops[item['shop_id']]['last_confirmed']=item['last_confirmed']
    return list(shops.values())

def require(ok, message='Доступ запрещён', code=403):
    if not ok: raise ApiError(message, code)

class ApiError(Exception):
    def __init__(self, message, code=400): self.message, self.code = message, code

@contextmanager
def connection(write=False):
    db = sqlite3.connect(DB, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    if write: db.execute('BEGIN IMMEDIATE')
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally: db.close()

def init():
    DB.parent.mkdir(parents=True, exist_ok=True)
    with connection() as d:
        d.execute('PRAGMA journal_mode=WAL')
        d.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, login TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL, shops TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER REFERENCES users(id), expires INTEGER);
        CREATE TABLE IF NOT EXISTS organizations(id INTEGER PRIMARY KEY, name TEXT NOT NULL, inn TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', bank TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS shops(id INTEGER PRIMARY KEY, name TEXT NOT NULL, organization_id INTEGER REFERENCES organizations(id), address TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, inn TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', contact TEXT NOT NULL DEFAULT '', bank TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL, barcode TEXT NOT NULL DEFAULT '', price INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
        CREATE UNIQUE INDEX IF NOT EXISTS product_barcode ON products(barcode) WHERE barcode != '';
        CREATE TABLE IF NOT EXISTS packaging(volume INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id));
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, type TEXT NOT NULL, shop_id INTEGER NOT NULL REFERENCES shops(id), author INTEGER NOT NULL REFERENCES users(id), status TEXT NOT NULL, body TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL, updated TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL REFERENCES documents(id), shop_id INTEGER NOT NULL REFERENCES shops(id), product_id INTEGER NOT NULL REFERENCES products(id), qty INTEGER NOT NULL, cost INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS ledger_stock ON ledger(shop_id, product_id);
        CREATE TABLE IF NOT EXISTS revisions(id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL REFERENCES documents(id), user_id INTEGER NOT NULL REFERENCES users(id), previous TEXT NOT NULL, reason TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, detail TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS requests(user_id INTEGER, key TEXT, response TEXT NOT NULL, PRIMARY KEY(user_id,key));
        CREATE TABLE IF NOT EXISTS shifts(id INTEGER PRIMARY KEY, shop_id INTEGER REFERENCES shops(id), user_id INTEGER REFERENCES users(id), opened TEXT NOT NULL, closed TEXT, opening_cash INTEGER NOT NULL DEFAULT 0, closing_cash INTEGER);
        CREATE UNIQUE INDEX IF NOT EXISTS shift_open ON shifts(shop_id,user_id) WHERE closed IS NULL;
        CREATE TABLE IF NOT EXISTS cash_movements(id INTEGER PRIMARY KEY,shop_id INTEGER NOT NULL REFERENCES shops(id),shift_id INTEGER NOT NULL REFERENCES shifts(id),user_id INTEGER NOT NULL REFERENCES users(id),kind TEXT NOT NULL CHECK(kind IN ('in','out')),amount INTEGER NOT NULL CHECK(amount>0),note TEXT NOT NULL,created TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS cash_movements_shift ON cash_movements(shift_id,id);
        CREATE TABLE IF NOT EXISTS sale_returns(id INTEGER PRIMARY KEY,sale_id INTEGER NOT NULL REFERENCES documents(id),shop_id INTEGER NOT NULL REFERENCES shops(id),shift_id INTEGER NOT NULL REFERENCES shifts(id),user_id INTEGER NOT NULL REFERENCES users(id),body TEXT NOT NULL,created TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS sale_returns_sale ON sale_returns(sale_id,id);
        ''')
        existing_columns={x['name'] for x in rows(d,'PRAGMA table_info(products)')}
        for field in ('source_uuid','source_code','category','barcodes','source_folder_uuid'):
            if field not in existing_columns:
                default='[]' if field=='barcodes' else ''
                d.execute(f"ALTER TABLE products ADD COLUMN {field} TEXT NOT NULL DEFAULT '{default}'")
        shift_columns={x['name'] for x in rows(d,'PRAGMA table_info(shifts)')}
        if 'expected_cash' not in shift_columns:d.execute('ALTER TABLE shifts ADD COLUMN expected_cash INTEGER')
        if 'closed_by' not in shift_columns:d.execute('ALTER TABLE shifts ADD COLUMN closed_by INTEGER REFERENCES users(id)')
        if 'created' not in {x['name'] for x in rows(d,'PRAGMA table_info(requests)')}:
            d.execute('ALTER TABLE requests ADD COLUMN created INTEGER NOT NULL DEFAULT 0')
        # Shift totals are read on every sale; avoid parsing every historic receipt.
        d.execute("CREATE INDEX IF NOT EXISTS sale_shift ON documents(shop_id,json_extract(body,'$.shift_id')) WHERE type='sale'")
        d.execute("CREATE INDEX IF NOT EXISTS sale_refund_shift ON documents(shop_id,json_extract(body,'$.refund_shift_id')) WHERE type='sale'")
        d.execute('CREATE INDEX IF NOT EXISTS sale_returns_shift ON sale_returns(shift_id)')
        d.execute('CREATE INDEX IF NOT EXISTS shifts_shop ON shifts(shop_id,id)')
        packaging_rules.init(d)
        moysklad_bridge.init(d)
        moysklad_outbox.init(d)
        d.execute('CREATE TABLE IF NOT EXISTS registration_requests(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password_hash TEXT NOT NULL,created TEXT NOT NULL)')
        d.execute('CREATE TABLE IF NOT EXISTS catalog_previews(token TEXT PRIMARY KEY,user_id INTEGER,payload TEXT,fingerprint TEXT,created INTEGER)')
        d.execute('''CREATE TABLE IF NOT EXISTS inventory_settings(shop_id INTEGER PRIMARY KEY,
            places TEXT NOT NULL DEFAULT '[]',scan_mode TEXT NOT NULL DEFAULT 'plus',
            require_done INTEGER NOT NULL DEFAULT 1,learn INTEGER NOT NULL DEFAULT 1)''')

def password_hash(p):
    require(isinstance(p,str) and 10 <= len(p) <= 200,'Пароль: от 10 до 200 символов',400)
    salt = secrets.token_hex(16)
    return salt + ':' + hashlib.scrypt(p.encode(), salt=salt.encode(), n=16384, r=8, p=1).hex()

def offline_password_hash(p):
    # The remote service accepts shorter passwords than BeerMag registration.
    # Cache only a salted verifier after a successful online authentication.
    salt=secrets.token_hex(16)
    return salt+':'+hashlib.scrypt(p.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()

def password_ok(p, stored):
    if not isinstance(p,str) or len(p)>200: return False
    salt, expected = stored.split(':')
    return hmac.compare_digest(hashlib.scrypt(p.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex(), expected)

def email_login(value):
    email=str(value or '').strip().lower()
    require(len(email)<=80 and re.fullmatch(r'[^@\s]{1,64}@[^@\s.]+(?:\.[^@\s.]+)+',email) is not None,'Укажите действительный адрес электронной почты',400)
    return email

SESSION_SECONDS=20*3600  # a long opening day (e.g. 09:00-01:00) fits in one login

def issue_session(d,u):
    token=secrets.token_urlsafe(32)
    d.execute('DELETE FROM sessions WHERE expires<?',(int(time.time()),))
    d.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],int(time.time())+SESSION_SECONDS))
    cookie='beerdesk='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+str(SESSION_SECONDS)+('; Secure' if os.environ.get('BEERDESK_SECURE_COOKIE')=='1' else '')
    return {'user':public_user(u)},cookie

def scaled(v, factor, label='Количество', positive=True):
    try:
        x = Decimal(str(v).replace(',','.')) * factor
        require(x.is_finite() and x == x.to_integral_value() and abs(x) <= 10**12, label+': неверное значение',400)
        n = int(x)
        require(n > 0 if positive else n >= 0,label+': неверное значение',400)
        return n
    except (InvalidOperation, DecimalException, ValueError, TypeError, OverflowError): raise ApiError(label+': неверное значение')

def rub(kopecks):return f'{kopecks/100:.2f}'.replace('.',',')

class KassaHTTPServer(ThreadingHTTPServer):
    """На Windows SO_REUSEADDR позволил бы второй кассе из другой папки занять тот же порт — запрещаем."""
    allow_reuse_address=os.name!='nt'
    daemon_threads=True
    def server_bind(self):
        import socket
        if os.name=='nt' and hasattr(socket,'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        super().server_bind()

def amount(price, qty):
    """Сумма строки в копейках — ровно так, как её считает МойСклад (проверено на живом аккаунте 30.09.2026):
    цена (коп.) × количество в двоичной арифметике и округление половины вверх. Например 51 ₽ × 0,285 кг = 14,53 ₽,
    а не 14,54 ₽ точной арифметики. Касса (браузер) считает так же: Math.round(price*qty)."""
    import math
    x=float(price)*(int(qty)/1000);r=math.floor(x)
    return int(r+1 if x-r>=0.5 else r)
def txt(v, field='Название', maxlen=300, empty=False):
    require(isinstance(v,str) and len(v.strip()) <= maxlen and (empty or bool(v.strip())),field+': заполните корректно',400)
    return v.strip()

def audit(d,u,action,detail): d.execute('INSERT INTO audit(user_id,action,detail,created) VALUES(?,?,?,?)',(u['id'] if u else None,action,dumps(detail),now()))
def is_manager(u): require(u['role']=='manager')

def set_token(handler,b):
    """Ввод API-токена МоегоСклада в окне кассы (вместо чёрного окна запуска)."""
    require(os.environ.get('BEERMAG_DEMO')!='1','Демо не подключается к МоемуСкладу.',403)
    require(hmac.compare_digest(str(b.get('key','')),SETUP_TOKEN),'Откройте кассу через значок БирМаг у часов и повторите.',403)
    if moysklad.configured():
        with connection() as d:is_manager(handler.user(d))   # замена токена — только управляющий
    token=str(b.get('token','')).strip()
    require(20<=len(token)<=200 and re.fullmatch(r'[0-9A-Za-z._~+/=-]+',token),'Проверьте токен: он скопирован не полностью или с лишними символами.',400)
    key=handler.client_address[0];recent=[x for x in FAILURES.get(key,[]) if x>time.time()-300]
    require(len(recent)<10,'Слишком много попыток. Повторите через 5 минут.',429)
    try:moysklad.Client(token).get('entity/retailstore',limit=1)
    except moysklad.SyncError as e:
        if 'не принят' in str(e) or 'прав' in str(e):FAILURES[key]=recent+[time.time()]
        raise ApiError(str(e)+' Токен не сохранён.',400)
    saved=True
    try:
        import start_moysklad
        start_moysklad.save_token(token)
    except OSError:saved=False
    os.environ['BEERMAG_MOYSKLAD_TOKEN']=token
    FAILURES.pop(key,None)
    with connection(True) as d:audit(d,None,'moysklad.token',{'saved':saved})
    return {'ok':True,'saved':saved}
def can_stock(u): require(u['role'] in ('admin','manager'))
def public_user(u): return {k:u[k] for k in ('id','login','name','role','shops')}
def available_shops(d,u):
    integrated=moysklad_bridge.active(d) and os.environ.get('BEERMAG_DEMO')!='1'
    available=rows(d,'SELECT s.*,o.name organization FROM shops s LEFT JOIN organizations o ON o.id=s.organization_id WHERE s.active=1'+(' AND s.id IN (SELECT shop_id FROM ms_shops)' if integrated else '')+' ORDER BY s.id')
    if u['role'] in ('manager','admin'):return available
    assigned=json.loads(u['shops']);bound=moysklad_bridge.bound_shop(d)
    return [s for s in available if s['id'] in assigned and (bound is None or s['id']==bound)]

def access(d,u,shop):
    shop=int(shop)
    require(one(d,'SELECT id FROM shops WHERE id=? AND active=1',(shop,)) is not None,'Магазин недоступен')
    integrated=moysklad_bridge.active(d) and os.environ.get('BEERMAG_DEMO')!='1'
    if integrated:
        require(one(d,'SELECT 1 FROM ms_shops WHERE shop_id=?',(shop,)) is not None,'Магазин недоступен')
    if u['role']=='seller':
        bound=moysklad_bridge.bound_shop(d)
        require(bound is None or shop==bound,'Эта касса закреплена за другим магазином')
        assigned=json.loads(u['shops'])
        if integrated and one(d,'SELECT 1 FROM ms_employees WHERE user_id=?',(u['id'],)):
            require(len(assigned)==1,'Сотруднику нужна одна торговая точка в МоемСкладе')
        require(shop in assigned,'Нет доступа к магазину')
    return shop

def bound_only(d,u,shop):
    """0.5.14: на закреплённой кассе смены, продажи, возвраты, деньги и пересчёт — только по её магазину (и для управляющего)."""
    bound=moysklad_bridge.bound_shop(d)
    if bound is None or shop==bound or not (moysklad_bridge.active(d) and os.environ.get('BEERMAG_DEMO')!='1'):return
    name=(one(d,'SELECT name FROM shops WHERE id=?',(bound,)) or {}).get('name','')
    raise ApiError('Эта касса закреплена за магазином «'+name+'». Смены, продажи, возвраты, деньги и пересчёт здесь — только по нему. Выберите его вверху экрана.',409)

def shift_not_skipped(d,shift_id):
    """0.5.14: если открытие смены пропущено в очереди, её продажи в МойСклад не попадут — новые операции не принимаем."""
    require(not one(d,"SELECT 1 FROM ms_outbox WHERE kind='shift_open' AND local_id=? AND status='skipped'",(shift_id,)),
        'Открытие этой смены не передано в МойСклад (управляющий пропустил его в очереди). Закройте смену и откройте новую — тогда продажи снова будут передаваться.',409)

def product(d,pid):
    p=one(d,'SELECT * FROM products WHERE id=?',(int(pid),))
    require(p is not None,'Товар не найден',400)
    return p

def stock(d,shop): return {r['product_id']:r['qty'] for r in rows(d,'SELECT product_id,SUM(qty) qty FROM ledger WHERE shop_id=? GROUP BY product_id',(shop,))}
def inventory_lock(d,shop,exclude=0):
    require(not one(d,"SELECT id FROM documents WHERE shop_id=? AND type='inventory' AND status='draft' AND id!=?",(shop,exclude)), 'В магазине идёт пересчёт. Завершите или отмените его перед движением товара.',409)

def inventory_zones(raw, known):
    """Validate physical counting places and aggregate each SKU exactly once."""
    require(isinstance(raw,list) and 1<=len(raw)<=50,'Добавьте от 1 до 50 мест пересчёта',400)
    zones=[];totals={};ids=set();names=set()
    for entry in raw:
        require(isinstance(entry,dict),'Неверное место пересчёта',400)
        ident=entry.get('id');name=txt(entry.get('name'),'Название места',80)
        require(isinstance(ident,str) and re.fullmatch(r'[A-Za-z0-9_-]{1,64}',ident) and ident not in ids,
                'Место пересчёта повторяется или имеет неверный идентификатор',400)
        require(name.casefold() not in names,'Названия мест пересчёта повторяются',400)
        ids.add(ident);names.add(name.casefold())
        entries=entry.get('items',[])
        require(isinstance(entries,list) and len(entries)<=len(known),'Неверные позиции места пересчёта',400)
        items=[];seen=set()
        for item in entries:
            require(isinstance(item,dict),'Неверная позиция пересчёта',400)
            try:pid=int(item['product_id'])
            except (KeyError,TypeError,ValueError):raise ApiError('Неверная позиция пересчёта',400)
            require(pid in known and pid not in seen,'Товар отсутствует или повторяется в месте пересчёта',400)
            seen.add(pid)
            quantity=scaled(item.get('qty'),1000,'Факт',False)
            require(known[pid] in ('draft','weight') or quantity%1000==0,'Штучный товар: целое количество',400)
            totals[pid]=totals.get(pid,0)+quantity
            require(totals[pid]<=10**12,'Факт: слишком большое количество',400)
            items.append({'product_id':pid,'qty':quantity})
        zones.append({'id':ident,'name':name,'items':items})
    return zones,totals

INVENTORY_DEFAULTS={'places':[],'scan_mode':'plus','require_done':True,'learn':True}

def inventory_settings(d,shop):
    row=one(d,'SELECT * FROM inventory_settings WHERE shop_id=?',(shop,))
    if not row:return dict(INVENTORY_DEFAULTS,places=[])
    return {'places':json.loads(row['places']),'scan_mode':row['scan_mode'],'require_done':bool(row['require_done']),'learn':bool(row['learn'])}

def place_names(raw):
    require(isinstance(raw,list) and len(raw)<=50,'Не более 50 мест',400)
    names=[];seen=set()
    for value in raw:
        name=txt(value,'Название места',80)
        if name.casefold() in seen:continue
        seen.add(name.casefold());names.append(name)
    return names

def save_inventory_settings(d,shop,settings):
    d.execute('''INSERT INTO inventory_settings(shop_id,places,scan_mode,require_done,learn) VALUES(?,?,?,?,?)
        ON CONFLICT(shop_id) DO UPDATE SET places=excluded.places,scan_mode=excluded.scan_mode,
        require_done=excluded.require_done,learn=excluded.learn''',
        (shop,dumps(settings['places']),settings['scan_mode'],int(settings['require_done']),int(settings['learn'])))

def inventory_extend(d,r,raw,integrated):
    """0.5.11: товар, заведённый в каталоге уже после начала пересчёта, тоже можно посчитать.

    Раньше список товаров фиксировался при старте: новый товар нельзя было внести, а при отправке
    он получал факт 0 — ложная недостача. Теперь он добавляется в пересчёт, как только его внесли в место."""
    known={line['product_id'] for line in r['body']['lines']}
    wanted=set()
    for zone in raw if isinstance(raw,list) else []:
        for item in (zone.get('items') if isinstance(zone,dict) else None) or []:
            try:pid=int(item['product_id'])
            except (KeyError,TypeError,ValueError):continue
            if pid not in known:wanted.add(pid)
    for pid in sorted(wanted):
        p=one(d,"SELECT id,name,kind FROM products WHERE id=? AND "+("source_uuid!=''" if integrated else 'active=1'),(pid,))
        if p:r['body']['lines'].append({'product_id':p['id'],'name':p['name'],'kind':p['kind'],'qty':None})

# Задания очереди, которые ещё ждут МойСклад. «skipped» — пропущено управляющим, дальше не ждёт.
QUEUE_OPEN="SELECT id FROM ms_outbox WHERE shop_id=? AND status NOT IN ('sent','skipped') LIMIT 1"
# Сколько продавец ждёт чтения остатков при отправке пересчёта; дольше — пересчёт отправится сам позже.
INVENTORY_READ_SECONDS=45
PREFETCH=threading.local()

def prefetch_inventory_stock(b):
    """Остатки склада для отправки пересчёта читаются ДО записи в базу.

    Раньше чтение шло внутри записи (до 3 минут при медленной связи), и всё это время касса не могла
    сохранить ни одной операции. Если очередь магазина не пуста или МойСклад не ответил, пересчёт
    не отклоняется, а ждёт связи (см. inventory_finish и moysklad_outbox.finish_waiting)."""
    PREFETCH.value=None
    shop=None
    try:
        with connection() as d:
            if os.environ.get('BEERMAG_DEMO')=='1' or not moysklad_bridge.active(d) or not moysklad.configured():return
            r=one(d,"SELECT shop_id,status FROM documents WHERE id=? AND type='inventory'",(int(b.get('id',0)),))
            if not r or r['status']!='draft':return
            shop=r['shop_id']
            binding=one(d,'SELECT store_id FROM ms_shops WHERE shop_id=?',(shop,))
            if not binding:return
            if one(d,QUEUE_OPEN,(shop,)):
                PREFETCH.value={'shop_id':shop,'error':'Ещё передаются предыдущие операции магазина.'};return
        client=moysklad.Client()
        if hasattr(client,'retries'):client.retries=0
        if hasattr(client,'deadline'):client.deadline=time.monotonic()+INVENTORY_READ_SECONDS
        stock=client.stock_for_store(binding['store_id'])
        PREFETCH.value={'shop_id':shop,'stock':stock,'names':getattr(client,'stock_names',{}) or {}}
    except moysklad.SyncError as e:
        PREFETCH.value={'shop_id':shop,'error':str(e)}
    except (TypeError,ValueError,sqlite3.Error):
        PREFETCH.value=None

def inventory_finish(d,r,remote,names,author):
    """Учётный остаток → строки «не найдено» с фактом 0, расхождения для управляющего, документы в очередь.

    Вызывается при отправке пересчёта или позже очередью, когда пересчёт ждал связи. В обоих случаях
    в МоемСкладе уже есть все операции этой кассы, сделанные до конца пересчёта, и ни одной после:
    очередь магазина передаёт операции строго по порядку."""
    products={p['source_uuid']:p for p in rows(d,"SELECT id,name,kind,source_uuid FROM products WHERE source_uuid!=''")}
    unknown=[key for key,quantity in remote.items() if quantity and key not in products]
    if unknown:
        listed=', '.join('«'+str((names or {}).get(key) or key[:8])+'»' for key in unknown[:5])+(f' и ещё {len(unknown)-5}' if len(unknown)>5 else '')
        raise moysklad.SyncError('В МоемСкладе есть остаток по товарам, которых нет в каталоге кассы: '+listed+
            '. Нажмите «Синхронизировать»; если не поможет — управляющему нужно проверить эти карточки (единица измерения, штрихкод, цена).')
    counted=[x for x in r['body']['lines'] if not x.get('auto_zero')]
    baseline={str(products[key]['id']):quantity for key,quantity in remote.items() if quantity}
    selected={x['product_id'] for x in counted}
    lines=list(counted)
    for key,quantity in remote.items():
        if quantity and products[key]['id'] not in selected:
            p=products[key]
            lines.append({'product_id':p['id'],'name':p['name'],'kind':p['kind'],'qty':0,'auto_zero':True})
    r['body']['lines']=lines
    r['body']['baseline']=baseline
    r['body']['differences']=[{'product_id':x['product_id'],'name':x['name'],
        'expected':baseline.get(str(x['product_id']),0),'actual':x['qty'],
        'difference':x['qty']-baseline.get(str(x['product_id']),0)} for x in lines]
    r['body'].pop('wait_reason',None)
    moysklad_outbox.inventory(d,r,author)

def zone_meta(zone):
    return {k:zone[k] for k in ('done','rev','by','updated') if k in zone}

def apply_zones(r,raw):
    """Validate places, keep their progress marks and recalculate totals."""
    known={line['product_id']:line['kind'] for line in r['body']['lines']}
    meta={z['id']:zone_meta(z) for z in r['body'].get('zones',[])}
    incoming={z.get('id'):z for z in raw if isinstance(z,dict)}
    zones,provided=inventory_zones(raw,known)
    for zone in zones:
        zone.update(meta.get(zone['id'],{}))
        source=incoming.get(zone['id'],{})
        for key in ('done','rev','by','updated'):
            if key in source:zone[key]=source[key]
    r['body']['zones']=zones
    for x in r['body']['lines']:x['qty']=provided.get(x['product_id'])

def doc(d,ident,u):
    r=one(d,'SELECT * FROM documents WHERE id=?',(int(ident),))
    require(r is not None,'Документ не найден',404)
    access(d,u,r['shop_id'])
    r['body']=json.loads(r['body'])
    if r['type']=='sale':
        r['sync_status']=moysklad_outbox.public_status(d,r['id'])
        r['refund_sync_status']=moysklad_outbox.refund_status(d,r['id'])
        r['returns']=sale_returns(d,r['id'])
        r['return_count']=len(r['returns'])
        returned={}
        for item in r['returns']:
            for line in item['body']['lines']:
                index=line['line_index'];returned[index]=returned.get(index,0)+line['qty']
        r['remaining']=[max(0,line['qty']-returned.get(i,0)) if r['status']=='posted' else 0 for i,line in enumerate(r['body']['lines'])]
    if r['type']=='inventory':
        r['sync_status']=moysklad_outbox.inventory_status(d,r['id'])
        if r['status']=='waiting':
            job=one(d,"SELECT status,error FROM ms_outbox WHERE kind='inventory_send' AND local_id=?",(r['id'],))
            if job:r['sync_status'],r['sync_error']=job['status'],job['error']
    return r

def safe_doc(r,u):
    r=json.loads(dumps(r))
    if u['role']=='seller':
        for key in ('baseline','differences','expected','reason'): r['body'].pop(key,None)
        if r['type']=='inventory':
            r['body']['lines']=[x for x in r['body'].get('lines',[]) if not x.get('auto_zero')]
    return r

def newdoc(d,u,kind,shop,body,status='draft'):
    t=now()
    ident=d.execute('INSERT INTO documents(type,shop_id,author,status,body,created,updated) VALUES(?,?,?,?,?,?,?)',(kind,shop,u['id'],status,dumps(body),t,t)).lastrowid
    return doc(d,ident,u)

def update_doc(d,u,r,body,status,reason):
    previous = one(d, 'SELECT * FROM documents WHERE id=?', (r['id'],))
    previous['body'] = json.loads(previous['body'])
    d.execute('INSERT INTO revisions(document_id,user_id,previous,reason,created) VALUES(?,?,?,?,?)',(r['id'],u['id'],dumps(previous),reason,now()))
    d.execute('UPDATE documents SET body=?,status=?,version=version+1,updated=? WHERE id=?',(dumps(body),status,now(),r['id']))
    audit(d,u,'document.'+reason,{'id':r['id']})
    return doc(d,r['id'],u)

def movement(d,r,pid,qty,cost=0):
    d.execute('INSERT INTO ledger(document_id,shop_id,product_id,qty,cost,created) VALUES(?,?,?,?,?,?)',(r['id'],r['shop_id'],pid,qty,cost,now()))

def reverse(d,r):
    for x in rows(d,'SELECT product_id,SUM(qty) qty,SUM(cost) cost FROM ledger WHERE document_id=? GROUP BY product_id',(r['id'],)):
        if x['qty'] or x['cost']: movement(d,r,x['product_id'],-x['qty'],-x['cost'])

def sale_returns(d,sale_id):
    result=rows(d,'''SELECT r.id,r.created,r.user_id,r.body,o.status sync_status FROM sale_returns r
        LEFT JOIN ms_outbox o ON o.kind='partial_refund' AND o.local_id=r.id
        WHERE r.sale_id=? ORDER BY r.id''',(sale_id,))
    for item in result:item['body']=json.loads(item['body'])
    return result

def lines_receipt(d,body):
    lines=body.get('lines',[])
    require(isinstance(lines,list) and 0<len(lines)<=500,'Добавьте товары',400)
    out=[]
    for x in lines:
        p=product(d,x['product_id']); q=scaled(x['qty'],1000); price=scaled(x.get('price',0),100,'Цена',False)
        require(p['kind'] in ('draft','weight') or q%1000==0,'Штучный товар: целое количество',400)
        out.append({'product_id':p['id'],'name':p['name'],'kind':p['kind'],'qty':q,'price':price,'total':amount(price,q)})
    supplier=one(d,'SELECT * FROM suppliers WHERE id=?',(int(body.get('supplier_id',0)),))
    require(supplier is not None,'Выберите поставщика',400)
    return {'supplier':supplier,'number':txt(body.get('number',''),'Номер накладной',100),'date':txt(body.get('date',''),'Дата',30),'lines':out,'total':sum(x['total'] for x in out)}

def shift_finances(d,shift):
    totals={'cash':0,'card':0,'count':0,'refund_count':0,'refund_cash':0,'refund_card':0}
    # Two indexed lookups instead of scanning every historic receipt of the shop.
    for x in rows(d,"""SELECT id,body,status FROM documents WHERE shop_id=? AND type='sale' AND json_extract(body,'$.shift_id')=?
            UNION SELECT id,body,status FROM documents WHERE shop_id=? AND type='sale' AND json_extract(body,'$.refund_shift_id')=?""",
            (shift['shop_id'],shift['id'],shift['shop_id'],shift['id'])):
        body=json.loads(x['body'])
        cash,card=pay_split(body)
        if body.get('shift_id')==shift['id'] and x['status'] in ('posted','refunded'):
            totals['cash']+=cash;totals['card']+=card;totals['count']+=1
            if body['payment']=='mixed':totals['mixed']=totals.get('mixed',0)+body['total']
        if body.get('refund_shift_id')==shift['id']:
            totals['cash']-=cash;totals['card']-=card;totals['refund_cash']+=cash;totals['refund_card']+=card;totals['refund_count']+=1
    for item in rows(d,'SELECT r.body,d.body sale_body FROM sale_returns r JOIN documents d ON d.id=r.sale_id WHERE r.shift_id=?',(shift['id'],)):
        returned=json.loads(item['body'])
        if 'payment' not in returned:returned['payment']=json.loads(item['sale_body'])['payment']
        cash,card=pay_split(returned)
        totals['cash']-=cash;totals['card']-=card;totals['refund_cash']+=cash;totals['refund_card']+=card;totals['refund_count']+=1
    movements=rows(d,"SELECT c.id,c.kind,c.amount,c.note,c.created,c.user_id,o.status sync_status FROM cash_movements c LEFT JOIN ms_outbox o ON o.local_id=c.id AND o.kind=CASE WHEN c.kind='in' THEN 'cash_in' ELSE 'cash_out' END WHERE c.shift_id=? ORDER BY c.id DESC",(shift['id'],))
    totals['cash_in']=sum(x['amount'] for x in movements if x['kind']=='in')
    totals['cash_out']=sum(x['amount'] for x in movements if x['kind']=='out')
    totals['cash_on_hand']=shift['opening_cash']+totals['cash']+totals['cash_in']-totals['cash_out']
    return totals,movements

def mutation(d,u,path,b):
    integrated=moysklad_bridge.active(d)
    if os.environ.get('BEERMAG_DEMO')=='1' and path in ('/api/moysklad/sales-enable','/api/moysklad/commit'):
        raise ApiError('В демо подключение к МоемСкладу выключено. Для работы используйте основной запуск.',403)
    if path=='/api/moysklad/sales-enable':
        is_manager(u); require(integrated,'Сначала синхронизируйте данные',409)
        require(moysklad.configured(),'Запустите сервер с API-токеном',409)
        require(not one(d,'SELECT 1 FROM shifts WHERE closed IS NULL'),'Сначала закройте прежние смены',409)
        require(b.get('enabled') is True,'Подтвердите включение передачи продаж',400)
        d.execute("INSERT INTO ms_options VALUES('sales_enabled','1') ON CONFLICT(key) DO UPDATE SET value='1'")
        audit(d,u,'moysklad.sales.enabled',{});moysklad_outbox.WAKE.set();return {'ok':True}
    if path=='/api/moysklad/bind':
        is_manager(u)
        try: sid=moysklad_bridge.bind_shop(d,str(b.get('retail_id','')))
        except moysklad.SyncError as e:raise ApiError(str(e),409)
        audit(d,u,'moysklad.register.bound',{'shop_id':sid})
        return {'shop_id':sid}
    if path=='/api/moysklad/retry':
        is_manager(u)
        d.execute("UPDATE ms_outbox SET next_try=0 WHERE status='retry'")
        moysklad_outbox.WAKE.set();return {'ok':True}
    if path=='/api/moysklad/skip':
        # 0.5.11: операция, которую МойСклад не принимает, больше не держит очередь магазина вечно.
        # Управляющий пропускает её вместе с зависящими от неё операциями и при необходимости вносит их вручную.
        is_manager(u)
        try:ident=int(b.get('id',0))
        except (TypeError,ValueError):raise ApiError('Неверная операция',400)
        job=one(d,'SELECT * FROM ms_outbox WHERE id=?',(ident,))
        require(job and job['status']=='retry','Пропустить можно только операцию, которую МойСклад не принял (есть ошибка в очереди).',409)
        require((job['locked_until'] or 0)<=time.time(),'Эта операция прямо сейчас передаётся в МойСклад. Подождите минуту и обновите очередь.',409)
        chain=moysklad_outbox.skip_chain(d,ident)
        jobs=[{'id':x['id'],'kind':x['kind'],'local_id':x['local_id'],'status':x['status']} for x in
              rows(d,f"SELECT id,kind,local_id,status FROM ms_outbox WHERE id IN ({','.join('?'*len(chain))}) ORDER BY id",chain)]
        if b.get('preview'):return {'jobs':jobs}
        reason=txt(b.get('reason',''),'Причина пропуска',300)
        cancelled=moysklad_outbox.skip(d,chain,u['name'],reason,now())
        audit(d,u,'moysklad.skipped',{'jobs':chain,'reason':reason,'inventories_cancelled':cancelled})
        moysklad_outbox.WAKE.set()
        return {'skipped':len(chain),'inventories_cancelled':cancelled}
    if path=='/api/moysklad/commit':
        is_manager(u)
        try: result=moysklad_bridge.commit(d,u,str(b.get('token','')),now())
        except moysklad.SyncError as e: raise ApiError(str(e),409)
        audit(d,u,'moysklad.catalog',result)
        return result
    if integrated:
        if path.startswith('/api/receipts/'):
            raise ApiError('Эта операция пока выполняется в МоемСкладе. Передача из BeerMag ещё не подключена.',409)
        if path.startswith('/api/inventory/'):
            require(moysklad.configured(),'Нет подключения к МоемСкладу. Обратитесь к управляющему.',409)
        if path in ('/api/sales','/api/sales/refund','/api/cash/move') or path.startswith('/api/shifts/'):
            if path!='/api/shifts/open':
                require(moysklad_bridge.sales_enabled(d),'Сначала откройте смену, чтобы включить передачу продаж',409)
            require(moysklad.configured(),'Нет подключения к сервису. Обратитесь к управляющему.',409)
        if path.startswith('/api/catalog/') or path=='/api/settings':
            raise ApiError('Карточки, цены и магазины изменяются в МоемСкладе. Затем обновите каталог.',409)
    if path=='/api/logout':
        d.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],)); return {'ok':True}
    if path=='/api/catalog/preview':
        is_manager(u)
        try: raw=catalog_import.read_xlsx(b.get('file',''))
        except ValueError as e: raise ApiError(str(e))
        current=rows(d,'SELECT * FROM products ORDER BY id')
        preview=catalog_import.prepare(raw,current)
        fingerprint=hashlib.sha256(dumps(current).encode()).hexdigest()
        token=secrets.token_urlsafe(24)
        d.execute('DELETE FROM catalog_previews WHERE created<?',(int(time.time())-3600,))
        d.execute('INSERT INTO catalog_previews VALUES(?,?,?,?,?)',(token,u['id'],dumps(preview),fingerprint,int(time.time())))
        return {'token':token,'rows':preview}
    if path=='/api/catalog/commit':
        is_manager(u)
        preview=one(d,'SELECT * FROM catalog_previews WHERE token=? AND user_id=?',(str(b.get('token','')),u['id']))
        require(preview and preview['created']>int(time.time())-3600,'Проверка устарела. Выберите файл снова.',409)
        current=rows(d,'SELECT * FROM products ORDER BY id')
        require(hashlib.sha256(dumps(current).encode()).hexdigest()==preview['fingerprint'],'Каталог изменён после проверки. Выберите файл снова.',409)
        plans=json.loads(preview['payload']);created=updated=0;ids={}
        for x in plans:
            if x['state']!='ready': continue
            values=[x[k] for k in ('name','kind','barcode','price','active','source_uuid','source_code','category')]+[dumps(x['barcodes'])]
            if x['target_id']:
                before=one(d,'SELECT * FROM products WHERE id=?',(x['target_id'],))
                d.execute('UPDATE products SET name=?,kind=?,barcode=?,price=?,active=?,source_uuid=?,source_code=?,category=?,barcodes=? WHERE id=?',values+[x['target_id']])
                ident=x['target_id'];updated+=1
                audit(d,u,'catalog.product.updated',{'id':ident,'before':before,'source_code':x['source_code']})
            else:
                ident=d.execute('INSERT INTO products(name,kind,barcode,price,active,source_uuid,source_code,category,barcodes) VALUES(?,?,?,?,?,?,?,?,?)',values).lastrowid;created+=1
            ids[x['source_code']]=ident
        # Only unambiguous bottle volumes; never overwrite an existing rule.
        import re
        candidates={}
        for x in plans:
            if x['state']!='ready' or x['kind']!='packaging' or not x['active']: continue
            match=re.search(r'бутылка?\s*(\d+(?:[,.]\d+)?)\s*л',x['name'],re.I)
            if match:
                volume=int(Decimal(match[1].replace(',','.'))*1000)
                if volume in (500,1000,1500,2000):candidates.setdefault(volume,[]).append(ids[x['source_code']])
        rules_added=0
        for volume,products in candidates.items():
            if len(products)==1:
                rules_added+=d.execute('INSERT OR IGNORE INTO packaging(volume,product_id) VALUES(?,?)',(volume,products[0])).rowcount
        d.execute('DELETE FROM catalog_previews WHERE token=?',(b['token'],))
        result={'created':created,'updated':updated,'skipped':len(plans)-created-updated,'packaging_rules_added':rules_added}
        audit(d,u,'catalog.import',result)
        return result
    if path=='/api/settings':
        is_manager(u); table=b.get('table'); ident=int(b.get('id') or 0)
        allowed={'suppliers':['name','inn','address','contact','bank','active'],'organizations':['name','inn','address','bank','active'],'shops':['name','organization_id','address','active'],'products':['name','kind','barcode','price','active','category']}
        require(table in allowed,'Неизвестный справочник',400)
        fields=allowed[table]; values={}
        before=one(d,f'SELECT * FROM {table} WHERE id=?',(ident,)) if ident else None
        require(not ident or before is not None,'Запись не найдена',404)
        for field in fields:
            v=b.get(field,before.get(field) if before else None)
            if field=='active': values[field]=1 if v is None or v is True or v==1 else 0
            elif field=='organization_id':
                values[field]=int(v or 0); require(one(d,'SELECT id FROM organizations WHERE id=?',(values[field],)) is not None,'Выберите ИП магазина',400)
            elif field=='price': values[field]=scaled(v,100,'Цена',False)
            elif field=='kind': require(v in ('draft','piece','weight','packaging'),'Тип товара неверен',400); values[field]=v
            else: values[field]=txt(v or '',field,1000,field!='name')
        if table=='products':
            for other in rows(d,'SELECT * FROM products WHERE id!=?',(ident,)):
                require(not values['barcode'] or values['barcode'] not in catalog_import.barcodes(other),'Штрихкод уже принадлежит другому товару',409)
        if table=='products' and before:
            require(values['kind']==before['kind'] or not one(d,'SELECT id FROM ledger WHERE product_id=?',(ident,)),'Нельзя менять единицу товара с движениями',409)
            require(values['kind'] in ('packaging','piece') or not packaging_rules.is_pack(d,before),'Товар используется как тара',409)
        if ident: d.execute(f"UPDATE {table} SET "+','.join(k+'=?' for k in fields)+' WHERE id=?',list(values.values())+[ident])
        else:
            ident=d.execute(f"INSERT INTO {table} ("+','.join(fields)+') VALUES('+','.join('?' for _ in fields)+')',list(values.values())).lastrowid
            if table=='shops':
                for m in rows(d,"SELECT * FROM users WHERE role IN ('manager','admin')"):
                    ss=json.loads(m['shops']); ss.append(ident); d.execute('UPDATE users SET shops=? WHERE id=?',(dumps(ss),m['id']))
        audit(d,u,'settings.'+table,{'id':ident,'before':before,'after':values}); return {'id':ident}
    if path=='/api/packaging':
        is_manager(u)
        raise ApiError('Состав тары задан автоматически. Редактирование отключено.',403)
    if path in ('/api/registrations/approve','/api/registrations/reject'):
        is_manager(u)
        ident=int(b.get('id') or 0)
        request=one(d,'SELECT * FROM registration_requests WHERE id=?',(ident,))
        require(request is not None,'Заявка не найдена',404)
        if path.endswith('/reject'):
            d.execute('DELETE FROM registration_requests WHERE id=?',(ident,))
            audit(d,u,'registration.rejected',{'email':request['email']})
            return {'ok':True}
        shops=sorted(set(int(x) for x in b.get('shops',[])))
        require(shops,'Выберите магазин для сотрудника',400)
        for shop_id in shops:access(d,u,shop_id)
        existing=one(d,'SELECT * FROM users WHERE login=?',(request['email'],))
        require(not existing or (not existing['active'] and existing['role']=='seller'), 'Этот email уже занят действующим сотрудником',409)
        if existing:
            linked=one(d,'SELECT * FROM ms_employees WHERE user_id=?',(existing['id'],))
            require(not linked or not linked['remote_archived'],'Сотрудник архивный в МоемСкладе',409)
            ident_user=existing['id']
            d.execute('UPDATE users SET password=?,shops=?,active=1 WHERE id=?',(request['password_hash'],dumps(shops),ident_user))
            if linked:d.execute('UPDATE ms_employees SET needs_password=0 WHERE user_id=?',(ident_user,))
        else:
            ident_user=d.execute("INSERT INTO users(login,name,password,role,shops,active) VALUES(?,?,?,'seller',?,1)",(request['email'],request['name'],request['password_hash'],dumps(shops))).lastrowid
        d.execute('DELETE FROM registration_requests WHERE id=?',(ident,))
        audit(d,u,'registration.approved',{'user_id':ident_user,'email':request['email'],'shops':shops})
        return {'id':ident_user}
    if path=='/api/users':
        is_manager(u); ident=int(b.get('id') or 0); role=b.get('role','seller'); require(role in ROLES,'Неверная роль',400)
        shops=sorted(set(int(x) for x in b.get('shops',[]))) if role=='seller' else [s['id'] for s in available_shops(d,u)]
        require(shops,'Выберите магазины',400)
        for s in shops: require(one(d,'SELECT id FROM shops WHERE id=?',(s,)) is not None,'Магазин не найден',400)
        login=txt(b.get('login',''),'Логин',80).lower(); name=txt(b.get('name',''),'Имя',100); active=1 if b.get('active',True) else 0
        old=one(d,'SELECT * FROM users WHERE id=?',(ident,)) if ident else None
        require(not ident or old is not None,'Пользователь не найден',404)
        linked=one(d,'SELECT * FROM ms_employees WHERE user_id=?',(ident,)) if ident else None
        if linked:
            require(not active or not linked['remote_archived'],'Сотрудник архивный в МоемСкладе',409)
            require(not active or not linked['needs_password'] or bool(b.get('password')) or role=='seller','Задайте пароль БирМаг для расширенной роли',400)
            if b.get('password'):d.execute('UPDATE ms_employees SET needs_password=0 WHERE user_id=?',(ident,))
        if old and old['role']=='manager' and (role!='manager' or not active):
            require(one(d,"SELECT COUNT(*) n FROM users WHERE role='manager' AND active=1")['n']>1,'Нельзя отключить последнего управляющего',409)
        p=password_hash(b['password']) if b.get('password') else (old['password'] if old else password_hash(''))
        if ident:
            d.execute('UPDATE users SET login=?,name=?,password=?,role=?,shops=?,active=? WHERE id=?',(login,name,p,role,dumps(shops),active,ident))
            if b.get('password') or not active: d.execute('DELETE FROM sessions WHERE user_id=?',(ident,))
            if linked and (old['role']!=role or old['active']!=active):
                d.execute('UPDATE ms_employees SET remote_managed=0 WHERE user_id=?',(ident,))
        else: ident=d.execute('INSERT INTO users(login,name,password,role,shops,active) VALUES(?,?,?,?,?,?)',(login,name,p,role,dumps(shops),active)).lastrowid
        audit(d,u,'user.updated',{'id':ident,'role':role,'shops':shops,'active':active}); return {'id':ident}
    shop=access(d,u,b.get('shop_id',0))
    if path in ('/api/shifts/open','/api/cash/move','/api/sales','/api/sales/refund','/api/inventory/start','/api/inventory/zone','/api/inventory/send'):bound_only(d,u,shop)
    if path=='/api/shifts/open':
        if integrated:require(not one(d,'SELECT id FROM shifts WHERE shop_id=? AND closed IS NULL',(shop,)),'В магазине уже есть открытая смена',409)
        require(not one(d,'SELECT id FROM shifts WHERE shop_id=? AND user_id=? AND closed IS NULL',(shop,u['id'])),'Смена уже открыта',409)
        initial=scaled(b.get('cash'),100,'Наличные при открытии',False)
        if integrated and not moysklad_bridge.sales_enabled(d):
            # Opening a shift is the cashier's explicit start of live operations.
            # The shift and activation share one transaction, so an invalid
            # register mapping cannot leave sales enabled on its own.
            d.execute("INSERT INTO ms_options VALUES('sales_enabled','1') ON CONFLICT(key) DO UPDATE SET value='1'")
            audit(d,u,'moysklad.sales.enabled',{'source':'shift.open'})
        # Record opening cash as a movement, including in integrated mode, so
        # both BeerMag and MoySklad have the same cash-in exactly once.
        sid=d.execute('INSERT INTO shifts(shop_id,user_id,opened,opening_cash) VALUES(?,?,?,0)',(shop,u['id'],now())).lastrowid
        if integrated:
            try:moysklad_outbox.open_shift(d,one(d,'SELECT * FROM shifts WHERE id=?',(sid,)),u)
            except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
        if initial:
            cash_id=d.execute('INSERT INTO cash_movements(shop_id,shift_id,user_id,kind,amount,note,created) VALUES(?,?,?,?,?,?,?)',(shop,sid,u['id'],'in',initial,'Наличные при открытии смены',now())).lastrowid
            if integrated:
                try:moysklad_outbox.cash_move(d,one(d,'SELECT * FROM cash_movements WHERE id=?',(cash_id,)),u)
                except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
        audit(d,u,'shift.open',{'shop_id':shop,'opening_cash':initial}); return {'ok':True}
    if path=='/api/shifts/close':
        if b.get('shift_id') not in (None,''):
            # Handover: the next cashier (or a manager) closes a shift left open
            # by another employee of the same shop, after counting the drawer.
            r=one(d,'SELECT * FROM shifts WHERE id=? AND shop_id=? AND closed IS NULL',(int(b['shift_id']),shop))
            require(r,'Эта смена уже закрыта или относится к другому магазину',409)
        else:
            r=one(d,'SELECT * FROM shifts WHERE shop_id=? AND user_id=? AND closed IS NULL',(shop,u['id'])); require(r,'Нет открытой смены',400)
        require('cash' in b and str(b.get('cash')).strip()!='','Пересчитайте наличные и укажите сумму в кассе',400)
        counted=scaled(b.get('cash'),100,'Наличные',False)
        totals,_=shift_finances(d,r)
        d.execute('UPDATE shifts SET closed=?,closing_cash=?,expected_cash=?,closed_by=? WHERE id=?',(now(),counted,totals['cash_on_hand'],u['id'],r['id']))
        if integrated:moysklad_outbox.close_shift(d,one(d,'SELECT * FROM shifts WHERE id=?',(r['id'],)))
        audit(d,u,'shift.close',{'id':r['id'],'owner':r['user_id'],'expected_cash':totals['cash_on_hand'],'counted_cash':counted,
                                 'difference':counted-totals['cash_on_hand']})
        return {'ok':True,'shift_id':r['id'],'expected_cash':totals['cash_on_hand'],'counted_cash':counted,'difference':counted-totals['cash_on_hand']}
    if path=='/api/cash/move':
        shift=one(d,'SELECT * FROM shifts WHERE shop_id=? AND user_id=? AND closed IS NULL',(shop,u['id']))
        require(shift is not None,'Сначала откройте свою смену',409); shift_not_skipped(d,shift['id'])
        kind=b.get('kind');require(kind in ('in','out'),'Укажите внесение или выплату',400)
        cash_amount=scaled(b.get('amount'),100,'Сумма')
        note=txt(b.get('note',''),'Причина',300,kind=='in')
        totals,_=shift_finances(d,shift)
        if kind=='out':require(cash_amount<=totals['cash_on_hand'],'В кассе недостаточно наличных',409)
        ident=d.execute('INSERT INTO cash_movements(shop_id,shift_id,user_id,kind,amount,note,created) VALUES(?,?,?,?,?,?,?)',(shop,shift['id'],u['id'],kind,cash_amount,note,now())).lastrowid
        if integrated:
            try:moysklad_outbox.cash_move(d,one(d,'SELECT * FROM cash_movements WHERE id=?',(ident,)),u)
            except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
        audit(d,u,'cash.'+kind,{'shop_id':shop,'shift_id':shift['id'],'amount':cash_amount,'note':note})
        return {'id':ident,'cash_on_hand':totals['cash_on_hand']+(cash_amount if kind=='in' else -cash_amount),'sync_status':'pending' if integrated else None}
    if path=='/api/sales':
        inventory_lock(d,shop)
        shift=one(d,'SELECT * FROM shifts WHERE shop_id=? AND user_id=? AND closed IS NULL',(shop,u['id'])); require(shift,'Сначала откройте смену',409)
        shift_not_skipped(d,shift['id'])
        require(b.get('payment') in ('cash','card','mixed'),'Выберите оплату',400)
        require(isinstance(b.get('lines'),list) and 0<len(b['lines'])<=300,'Покупка пуста',400)
        lines=[]
        for index,x in enumerate(b['lines']):
            p=product(d,x['product_id']); require(p['active'],'Товар больше не продаётся: '+p['name'],409)
            q=scaled(x['qty'],1000); require(packaging_rules.available(d,p['id']),'Этот вид тары отключён',409)
            require(p['kind'] not in ('piece','packaging') or q%1000==0,'Введите целое количество',400)
            if p['kind']=='draft':
                volume=scaled(x.get('volume'),1000,'Объём бутылки'); count=int(x.get('count',1)); require(1<=count<=1000 and q==volume*count,'Неверное число бутылок',400)
                choices=[r for r in packaging_rules.rules(d) if r['volume']==volume and r['enabled'] and r['product_id'] and product(d,r['product_id'])['active']]
                chosen=x.get('packaging_id')
                if chosen is not None: choices=[r for r in choices if r['product_id']==int(chosen)]
                elif len(choices)>1: choices=[r for r in choices if r['slot'].startswith('bottle-')]
                require(len(choices)==1,'Выберите доступный вид тары для этого объёма',400)
                pack=product(d,choices[0]['product_id'])
                lines.append({'product_id':pack['id'],'name':pack['name'],'kind':'packaging','qty':count*1000,'price':pack['price'],'total':pack['price']*count,'group':index})
            lines.append({'product_id':p['id'],'name':p['name'],'kind':p['kind'],'qty':q,'price':p['price'],'total':amount(p['price'],q),'group':index})
        total=sum(x['total'] for x in lines)
        if integrated:
            require('expected_total' in b,'Обновите страницу кассы перед оплатой',409)
            require(scaled(b['expected_total'],100,'Сумма покупки',False)==total,'Цена в каталоге изменилась. Обновите кассу и проверьте оплату перед повтором.',409)
        split={}
        if b['payment']=='mixed':
            # Сложная оплата: часть наличными, остаток — картой на терминале.
            cash_part=scaled(b.get('cash_amount'),100,'Сумма наличными',False)
            require(0<cash_part<total,'Сложная оплата: наличными больше нуля и меньше итога',400)
            received=scaled(b.get('received',0),100,'Получено',False) if b.get('received') not in (None,'') else cash_part
            require(received>=cash_part,'Получено наличными меньше наличной части',400)
            split={'cash_amount':cash_part,'card_amount':total-cash_part}
            change=received-cash_part
        else:
            received=scaled(b.get('received',0),100,'Получено',False) if b['payment']=='cash' else total
            require(received>=total,'Полученная сумма меньше итога',400)
            change=received-total
        org=one(d,'SELECT o.* FROM organizations o JOIN shops s ON s.organization_id=o.id WHERE s.id=?',(shop,))
        body={'lines':lines,'total':total,'payment':b['payment'],**split,'received':received,'change':change,'shift_id':shift['id'],'organization':org}
        r=newdoc(d,u,'sale',shop,body,'posted')
        if integrated:
            try:moysklad_outbox.sale(d,r,u)
            except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
            r['sync_status']='pending'
        else:
            for x in lines: movement(d,r,x['product_id'],-x['qty'])
        audit(d,u,'sale',{'id':r['id'],'total':total}); return safe_doc(r,u)
    if path=='/api/sales/refund':
        inventory_lock(d,shop); r=doc(d,b['id'],u)
        require(r['shop_id']==shop and r['type']=='sale' and r['status']=='posted','Возврат невозможен',409)
        reason=txt(b.get('reason',''),'Причина возврата',500)
        require(b.get('money_returned') is True,'Подтвердите возврат денег покупателю',400)
        shift=one(d,'SELECT * FROM shifts WHERE shop_id=? AND user_id=? AND closed IS NULL',(shop,u['id']))
        require(shift is not None,'Для возврата откройте свою смену в этом магазине',409); shift_not_skipped(d,shift['id'])
        if 'lines' in b:
            chosen=b['lines'];require(isinstance(chosen,list) and 0<len(chosen)<=len(r['body']['lines']),'Выберите возвращаемые товары',400)
            prior=sale_returns(d,r['id']);used={};paid={}
            for item in prior:
                for line in item['body']['lines']:
                    index=line['line_index'];used[index]=used.get(index,0)+line['qty'];paid[index]=paid.get(index,0)+line['total']
            selected=[];seen=set()
            for x in chosen:
                require(isinstance(x,dict),'Неверная строка возврата',400)
                try:index=int(x['line_index'])
                except (TypeError,ValueError,KeyError):raise ApiError('Неверная строка возврата',400)
                require(0<=index<len(r['body']['lines']) and index not in seen,'Повторяющаяся или неверная строка',400)
                seen.add(index);source=r['body']['lines'][index];qty=scaled(x.get('qty'),1000)
                require(source['kind'] not in ('piece','packaging') or qty%1000==0,'Штучный товар возвращается целым количеством',400)
                remaining=source['qty']-used.get(index,0)
                require(qty<=remaining,'Это количество уже возвращено или превышает покупку',409)
                line_total=amount(source['price'],qty)
                # Disallow splitting a weighed line when separate rounding would
                # make the final refunds differ from the exact original amount.
                remainder_total=source['total']-paid.get(index,0)
                if qty==remaining:line_total=remainder_total   # остаток строки — ровно столько, сколько за него заплачено
                require(qty==remaining or line_total+amount(source['price'],remaining-qty)==remainder_total,
                        'Такое дробное количество даст расхождение в копейках. Верните остаток строки целиком.',409)
                selected.append({**source,'line_index':index,'qty':qty,'total':line_total})
            total=sum(line['total'] for line in selected)
            body={'lines':selected,'total':total,'payment':r['body']['payment'],'reason':reason}
            if r['body']['payment']=='mixed':
                # Сначала возвращаем наличные (без терминала), остаток — на карту.
                paid_cash=r['body']['cash_amount']-sum(pay_split(x['body'])[0] for x in prior)
                cash_back=min(total,max(0,paid_cash))
                body.update(cash_amount=cash_back,card_amount=total-cash_back)
            if pay_split(body)[0]:
                totals,_=shift_finances(d,shift)
                require(pay_split(body)[0]<=totals['cash_on_hand'],'В кассе недостаточно наличных для возврата: нужно '+rub(pay_split(body)[0])+' ₽, в кассе '+rub(totals['cash_on_hand'])+' ₽',409)
            return_id=d.execute('INSERT INTO sale_returns(sale_id,shop_id,shift_id,user_id,body,created) VALUES(?,?,?,?,?,?)',
                                (r['id'],shop,shift['id'],u['id'],dumps(body),now())).lastrowid
            if integrated:
                try:moysklad_outbox.partial_refund(d,r,return_id,body,u,shift)
                except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
            else:
                for line in selected:movement(d,r,line['product_id'],line['qty'])
            if all(used.get(i,0)+next((x['qty'] for x in selected if x['line_index']==i),0)==line['qty'] for i,line in enumerate(r['body']['lines'])):
                r=update_doc(d,u,r,r['body'],'refunded','refund.completed')
            audit(d,u,'sale.partial_refund',{'sale_id':r['id'],'return_id':return_id,'total':total})
            return {'id':return_id,'sale_id':r['id'],'total':total,'status':r['status'],'sync_status':'pending' if integrated else None,
                    'cash_amount':pay_split(body)[0],'card_amount':pay_split(body)[1]}
        require(not sale_returns(d,r['id']),'По этому чеку уже есть частичный возврат. Выберите оставшиеся позиции.',409)
        if pay_split(r['body'])[0]:
            totals,_=shift_finances(d,shift)
            require(pay_split(r['body'])[0]<=totals['cash_on_hand'],'В кассе недостаточно наличных для возврата: нужно '+rub(pay_split(r['body'])[0])+' ₽, в кассе '+rub(totals['cash_on_hand'])+' ₽',409)
        if integrated:
            try:moysklad_outbox.refund(d,r,u,shift,reason)
            except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
        else:reverse(d,r)
        r['body']['refund_shift_id']=shift['id']
        r['body']['refund_reason']=reason
        cash_back,card_back=pay_split(r['body'])
        return {**safe_doc(update_doc(d,u,r,r['body'],'refunded','refund'),u),'cash_amount':cash_back,'card_amount':card_back}
    if path=='/api/receipts/save':
        r=doc(d,b['id'],u) if b.get('id') else None
        if r:
            require(r['shop_id']==shop and r['type']=='receipt','Неверный документ',400)
            require(u['role']=='manager' or (r['author']==u['id'] and r['status']=='draft'))
            require(r['version']==int(b.get('version',0)),'Документ уже изменён. Откройте заново.',409)
        body=lines_receipt(d,b)
        if r and r['status']=='posted':
            is_manager(u); inventory_lock(d,shop); reason=txt(b.get('reason',''),'Причина исправления',500)
            reverse(d,r)
            for x in body['lines']: movement(d,r,x['product_id'],x['qty'],x['total'])
            return safe_doc(update_doc(d,u,r,body,'posted',reason),u)
        return safe_doc(update_doc(d,u,r,body,'draft','draft.saved') if r else newdoc(d,u,'receipt',shop,body),u)
    if path=='/api/receipts/send':
        inventory_lock(d,shop); r=doc(d,b['id'],u)
        require(r['shop_id']==shop and r['type']=='receipt','Неверный документ',400)
        require(u['role']=='manager' or r['author']==u['id'])
        if r['status']=='posted': return safe_doc(r,u)
        require(r['status']=='draft','Документ нельзя отправить',409)
        require(r['version']==int(b.get('version',0)),'Документ изменён. Откройте заново.',409)
        for x in r['body']['lines']: movement(d,r,x['product_id'],x['qty'],x['total'])
        return safe_doc(update_doc(d,u,r,r['body'],'posted','receipt.sent'),u)
    if path=='/api/inventory/start':
        # A confirmed adjustment may have been acknowledged just before the
        # process stopped, leaving the local document in the transitional state.
        # Only confirmed outbox jobs may be reconciled here; never infer success
        # from an inventory deleted or edited in MoySklad.
        for previous in rows(d,"SELECT id FROM documents WHERE shop_id=? AND type='inventory' AND status='adjusting'",(shop,)):
            if (one(d,'SELECT 1 FROM ms_inventory_adjustments WHERE document_id=?',(previous['id'],))
                    and moysklad_outbox.inventory_status(d,previous['id'])=='sent'):
                d.execute("UPDATE documents SET status='exported',version=version+1,updated=? WHERE id=? AND status='adjusting'",(now(),previous['id']))
        for previous in rows(d,"SELECT id FROM documents WHERE shop_id=? AND type='inventory' AND status='submitted'",(shop,)):
            if moysklad_outbox.inventory_status(d,previous['id'])=='sent':
                d.execute("UPDATE documents SET status='exported',version=version+1,updated=? WHERE id=? AND status='submitted'",(now(),previous['id']))
        previous=one(d,"SELECT id,status FROM documents WHERE shop_id=? AND type='inventory' AND status IN ('draft','waiting','submitted','adjusting') ORDER BY id DESC LIMIT 1",(shop,))
        if previous:
            ident=previous['id'];state=previous['status']
            if state=='draft':message=f'Пересчёт № {ident} ещё в работе в БирМаг. Откройте его в разделе «Инвентаризации» и продолжите или отмените.'
            elif state=='waiting':message=f'Пересчёт № {ident} ждёт связи с МоимСкладом и отправится сам. Новый пересчёт можно начать после его отправки.'
            elif state=='submitted' and moysklad_outbox.inventory_status(d,ident)=='sent':
                message=f'Пересчёт № {ident} ожидает решения в БирМаг. Откройте его в разделе «Инвентаризации»: управляющий может утвердить его или отменить без корректировки остатков. Удаление в МоемСкладе не отменяет пересчёт в кассе.'
            elif state=='submitted':message=f'Пересчёт № {ident} ещё передаётся в МойСклад. Проверьте очередь передачи, затем откройте его в разделе «Инвентаризации».'
            else:message=f'По пересчёту № {ident} ещё не подтверждены корректировки остатков. Проверьте очередь передачи в разделе «Данные кассы»; новую инвентаризацию пока начинать нельзя.'
            raise ApiError(message,409)
        baseline={} if integrated else stock(d,shop)
        products=rows(d,"SELECT * FROM products WHERE source_uuid!='' ORDER BY name") if integrated else rows(d,'SELECT * FROM products WHERE active=1 OR id IN (SELECT product_id FROM ledger WHERE shop_id=?) ORDER BY name',(shop,))
        lines=[{'product_id':p['id'],'name':p['name'],'kind':p['kind'],'qty':None} for p in products]
        require(lines,'Сначала добавьте товары',400)
        body={'baseline':baseline,'lines':lines}
        if 'zones' in b:
            names=b['zones'];require(isinstance(names,list) and 1<=len(names)<=50,'Добавьте от 1 до 50 мест пересчёта',400)
            body['zones']=[{'id':secrets.token_hex(12),'name':txt(name,'Название места',80),'items':[]} for name in names]
            require(len({zone['name'].casefold() for zone in body['zones']})==len(names),'Названия мест пересчёта повторяются',400)
        r=newdoc(d,u,'inventory',shop,body)
        return safe_doc(r,u)
    if path=='/api/inventory/settings':
        is_manager(u)
        current=inventory_settings(d,shop)
        places=place_names(b.get('places',current['places']))
        mode=b.get('scan_mode',current['scan_mode']);require(mode in ('plus','ask'),'Неверный режим сканирования',400)
        settings={'places':places,'scan_mode':mode,'require_done':bool(b.get('require_done',current['require_done'])),
                  'learn':bool(b.get('learn',current['learn']))}
        save_inventory_settings(d,shop,settings)
        audit(d,u,'inventory.settings',{'shop_id':shop,**settings})
        return settings
    if path in ('/api/inventory/zone','/api/inventory/zone-delete'):
        # Several sellers may count different places at the same time. Each
        # place is saved on its own with a revision number, so one screen
        # never overwrites another place, and a stale screen is told to reload.
        r=doc(d,b['id'],u);require(r['type']=='inventory' and r['shop_id']==shop,'Неверный документ',400)
        require(r['status']=='draft','Пересчёт уже отправлен. Откройте его заново.',409)
        units=lambda items:[{'product_id':i['product_id'],'qty':str(Decimal(i['qty'])/1000)} for i in items]
        if 'zones' in r['body']:
            zones=[{**z,'items':units(z['items'])} for z in r['body']['zones']]
        else:  # a count started before places existed
            counted=[x for x in r['body']['lines'] if x['qty'] is not None]
            zones=[{'id':'legacy','name':'Ранее внесено','items':units(counted)}] if counted else []
        index={z['id']:i for i,z in enumerate(zones)}
        try:expected=int(b.get('rev',0))
        except (TypeError,ValueError):raise ApiError('Неверная версия места',400)
        if path.endswith('/zone-delete'):
            ident=str(b.get('zone_id',''))
            require(ident in index,'Место уже удалено',409)
            require(zones[index[ident]].get('rev',0)==expected,'Это место изменено на другом экране. Обновите пересчёт.',409)
            require(len(zones)>1,'Оставьте хотя бы одно место пересчёта',409)
            zones.pop(index[ident]);action='inventory.zone.deleted';name=ident;done_now=False
        else:
            zone=b.get('zone');require(isinstance(zone,dict) and isinstance(zone.get('items'),list),'Неверное место пересчёта',400)
            ident=zone.get('id');old=zones[index[ident]] if ident in index else None
            require((old or {}).get('rev',0)==expected,
                    'Это место изменено на другом экране. Обновите пересчёт; числа из этого окна останутся на экране.',409)
            updated={'id':ident,'name':zone.get('name'),'items':[i for i in zone['items'] if isinstance(i,dict)],
                     'done':bool(zone.get('done')),'rev':expected+1,'by':u['name'],'updated':now()}
            if old:zones[index[ident]]=updated
            else:zones.append(updated)
            action='inventory.zone.done';name=updated['name'];done_now=updated['done'] and not (old or {}).get('done')
        inventory_extend(d,r,zones,integrated)
        apply_zones(r,zones)
        d.execute('UPDATE documents SET body=?,version=version+1,updated=? WHERE id=?',(dumps(r['body']),now(),r['id']))
        # Autosave happens often; only meaningful steps go to the history.
        if done_now or action=='inventory.zone.deleted':audit(d,u,action,{'id':r['id'],'zone':name})
        return safe_doc(doc(d,r['id'],u),u)
    if path in ('/api/inventory/save','/api/inventory/send','/api/inventory/cancel','/api/inventory/approve'):
        r=doc(d,b['id'],u); require(r['type']=='inventory' and r['shop_id']==shop,'Неверный документ',400)
        # Any employee of the shop may continue a draft count; cancelling or
        # deciding on a submitted count stays with its author or the manager.
        require(u['role']=='manager' or r['author']==u['id'] or (r['status']=='draft' and not path.endswith('/cancel')))
        require(r['version']==int(b.get('version',0)),'Пересчёт изменён. Откройте заново.',409)
        if path.endswith('/cancel'):
            require(r['status'] in ('draft','waiting','submitted'),'Нельзя отменить утверждённый пересчёт',409)
            require(not integrated or r['status'] in ('draft','waiting') or u['role']=='manager',
                'Отменить отправленный пересчёт может только управляющий. Документы останутся в МоемСкладе.',409)
            if integrated and r['status']=='submitted':
                require(moysklad_outbox.inventory_status(d,r['id'])=='sent',
                    'Сначала дождитесь передачи пересчёта в МойСклад, затем управляющий сможет его отменить.',409)
            if r['status']=='waiting':
                # В МойСклад ещё ничего не ушло: снимаем ожидающее задание, очередь магазина идёт дальше.
                d.execute("DELETE FROM ms_outbox WHERE kind='inventory_send' AND local_id=? AND status NOT IN ('sent','skipped')",(r['id'],))
            return safe_doc(update_doc(d,u,r,r['body'],'cancelled','inventory.cancelled'),u)
        if path.endswith('/approve'):
            is_manager(u)
            # Расхождения проверяет и проводит управляющий в МоемСкладе (документ «Инвентаризация»).
            require(not integrated,'Расхождения проводятся в МоемСкладе: откройте документ «Инвентаризация» и создайте списание или оприходование.',409)
            require(r['status']=='submitted','Пересчёт не отправлен',409); inventory_lock(d,shop)
            if integrated:
                require(moysklad_outbox.inventory_status(d,r['id'])=='sent','Сначала дождитесь передачи всех частей пересчёта в МойСклад',409)
                pending=one(d,QUEUE_OPEN,(shop,))
                require(not pending,'Сначала дождитесь передачи всех операций этого магазина.',409)
                binding=one(d,'SELECT store_id FROM ms_shops WHERE shop_id=?',(shop,))
                require(binding,'Торговая точка не связана со складом МоегоСклада.',409)
                try:
                    client=moysklad.Client()
                    current=client.stock_for_store(binding['store_id'])
                    products={p['source_uuid']:p['id'] for p in rows(d,"SELECT id,source_uuid FROM products WHERE source_uuid!=''")}
                    unknown=[key for key,quantity in current.items() if quantity and key not in products]
                    require(not unknown,'В МоемСкладе появились товары с остатком, которых нет в каталоге кассы. Обновите каталог и проверьте пересчёт.',409)
                    latest={str(products[key]):quantity for key,quantity in current.items() if quantity}
                    require(latest==r['body']['baseline'],
                        'Остатки МоегоСклада изменились после отправки пересчёта. Проверьте продажи и создайте новый пересчёт перед корректировкой.',409)
                    count=moysklad_outbox.inventory_adjust(d,r,u,client)
                except (moysklad.SyncError,ValueError) as e:raise ApiError(str(e),409)
                status='adjusting' if count else 'exported'
                return safe_doc(update_doc(d,u,r,r['body'],status,'inventory.approved'),u)
            for x in r['body']['differences']: movement(d,r,x['product_id'],x['difference'])
            return safe_doc(update_doc(d,u,r,r['body'],'posted','inventory.approved'),u)
        require(r['status']=='draft','Пересчёт уже отправлен',409)
        if 'zones' in b:inventory_extend(d,r,b['zones'],integrated)
        known={line['product_id']:line['kind'] for line in r['body']['lines']}
        if 'zones' in b:
            apply_zones(r,b['zones'])
        elif 'zones' in r['body'] and path.endswith('/send'):
            pass  # places are already saved one by one
        else:
            require('zones' not in r['body'],'Откройте пересчёт заново и сохраните количества по местам',409)
            require(isinstance(b.get('lines'),list),'Неверные строки пересчёта',400)
            provided={}
            for item in b['lines']:
                require(isinstance(item,dict),'Неверная строка пересчёта',400)
                try:pid=int(item['product_id'])
                except (KeyError,TypeError,ValueError):raise ApiError('Неверная строка пересчёта',400)
                require(pid not in provided,'Товар повторяется в пересчёте',400)
                provided[pid]=item.get('qty')
            require(provided.keys()<=known.keys(),'Товар отсутствует в текущем пересчёте',400)
            for x in r['body']['lines']:
                v=provided.get(x['product_id'])
                # A blank is not counted. Explicit 0 is counted as an empty shelf.
                x['qty']=None if v is None or v=='' else scaled(v,1000,'Факт',False)
                require(x['qty'] is None or x['kind'] in ('draft','weight') or x['qty']%1000==0,'Штучный товар: целое количество',400)
        status='draft'
        if path.endswith('/send'):
            settings=inventory_settings(d,shop)
            # The place-by-place screen marks finished places; older screens send all places at once.
            if settings['require_done'] and r['body'].get('zones') and 'zones' not in b:
                open_places=[z['name'] for z in r['body']['zones'] if not z.get('done')]
                require(not open_places,'Отметьте места как посчитанные: '+', '.join(open_places[:5]),409)
            if settings['learn'] and r['body'].get('zones'):
                known_places={x.casefold() for x in settings['places']}
                added=[z['name'] for z in r['body']['zones'] if z['name'].casefold() not in known_places and z['id']!='legacy']
                if added and len(settings['places'])+len(added)<=50:
                    settings['places']=settings['places']+added;save_inventory_settings(d,shop,settings)
            counted=[x for x in r['body']['lines'] if x['qty'] is not None]
            r['body']['lines']=counted
            require(r['body']['lines'],'Заполните хотя бы одну пересчитанную позицию',400)
            status='submitted'
            if integrated:
                binding=one(d,'SELECT store_id FROM ms_shops WHERE shop_id=?',(shop,))
                require(binding,'Торговая точка не связана со складом МоегоСклада.',409)
                # Время конца пересчёта: на него в МоемСкладе считается учётный остаток.
                r['body']['count_moment']=now()
                pre=getattr(PREFETCH,'value',None);PREFETCH.value=None
                reason=(pre or {}).get('error') or 'Нет ответа МоегоСклада.'
                ready=bool(pre and pre.get('shop_id')==shop and 'stock' in pre and not one(d,QUEUE_OPEN,(shop,)))
                if ready:
                    try:inventory_finish(d,r,pre['stock'],pre.get('names'),u)
                    except (moysklad.SyncError,ValueError) as e:ready=False;reason=str(e)
                if not ready:
                    # 0.5.11: нет связи или ещё передаются прежние операции — пересчёт не отклоняется.
                    # Он встаёт в очередь магазина за уже сделанными операциями; продажи сразу открыты.
                    # Когда очередь дойдёт до него, касса прочитает остатки и отправит документ сама.
                    r['body']['wait_reason']=reason[:300]
                    moysklad_outbox.enqueue(d,'inventory_send',r['id'],{'document_id':r['id']},shop)
                    status='waiting'
            else:
                r['body']['differences']=[{'product_id':x['product_id'],'name':x['name'],'expected':r['body']['baseline'].get(str(x['product_id']),0),'actual':x['qty'],'difference':x['qty']-r['body']['baseline'].get(str(x['product_id']),0)} for x in r['body']['lines']]
            if not integrated and os.environ.get('BEERMAG_DEMO')=='1':
                # Demo has no MoySklad: apply the count locally so the flow ends like in live mode.
                for x in r['body']['differences']:
                    if x['difference']:movement(d,r,x['product_id'],x['difference'])
                status='posted'
        return safe_doc(update_doc(d,u,r,r['body'],status,'inventory.'+status),u)
    raise ApiError('Неизвестная операция',404)

class Handler(BaseHTTPRequestHandler):
    server_version='BeerMag/'+VERSION
    def log_message(self, format, *args): pass
    def send(self,obj,status=200,cookie=None,ctype='application/json; charset=utf-8'):
        data=dumps(obj).encode() if ctype.startswith('application/json') else obj
        self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if cookie: self.send_header('Set-Cookie',cookie)
        self.end_headers(); self.wfile.write(data)
    def download_backup(self):
        try:
            saved=backup()
            with connection(True) as d:
                d.execute("INSERT INTO ms_options VALUES('backup_last',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(now(),))
                d.execute("DELETE FROM ms_options WHERE key='backup_error'")
        except (OSError,sqlite3.Error):
            with connection(True) as d:
                d.execute("INSERT INTO ms_options VALUES('backup_error','Не удалось сохранить резервную копию. Проверьте папку копий.') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
            raise ApiError('Не удалось создать резервную копию. Проверьте папку копий.',503)
        self.send_response(200)
        self.send_header('Content-Type','application/octet-stream')
        self.send_header('Content-Disposition','attachment; filename="'+saved.name+'"')
        self.send_header('Content-Length',str(saved.stat().st_size))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        try:
            with saved.open('rb') as source:shutil.copyfileobj(source,self.wfile,1024*1024)
        except (BrokenPipeError,ConnectionResetError):pass  # The verified copy remains on disk.
    def user(self,d):
        token=''
        for part in self.headers.get('Cookie','').split(';'):
            if part.strip().startswith('beerdesk='): token=part.strip().split('=',1)[1]
        r=one(d,'SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.active=1',(hashlib.sha256(token.encode()).hexdigest(),int(time.time())))
        require(r is not None,'Войдите в программу',401); return r
    def do_GET(self):
        try:
            self.local_host()
            path=urlparse(self.path).path; q=parse_qs(urlparse(self.path).query)
            if not path.startswith('/api/'):
                files={'/':'index.html','/app.js':'app.js','/inventory.js':'inventory.js','/style.css':'style.css','/favicon.svg':'favicon.svg','/login-drops.webp':'login-drops.webp'}
                require(path in files,'Не найдено',404)
                ct={'/':'text/html; charset=utf-8','/app.js':'text/javascript; charset=utf-8','/inventory.js':'text/javascript; charset=utf-8','/style.css':'text/css; charset=utf-8','/favicon.svg':'image/svg+xml','/login-drops.webp':'image/webp'}[path]
                return self.send((ROOT/'web'/files[path]).read_bytes(),ctype=ct)
            with connection() as d:
                if path=='/api/status': return self.send({'setup':one(d,'SELECT COUNT(*) n FROM users')['n']==0,'version':VERSION,'demo':os.environ.get('BEERMAG_DEMO')=='1','moysklad_ready':moysklad_bridge.active(d),'token_needed':os.environ.get('BEERMAG_DEMO')!='1' and not moysklad.configured(),'app':bool(os.environ.get('BEERMAG_APP_KEY')),'launch':os.environ.get('BEERMAG_LAUNCH_ID','')})
                u=self.user(d)
                if path=='/api/backup/download':
                    is_manager(u)
                    return self.download_backup()
                if path=='/api/moysklad/queue':
                    is_manager(u)
                    return self.send(rows(d,'SELECT q.id,q.shop_id,q.kind,COALESCE(p.document_id,a.document_id,q.local_id) local_id,COALESCE(p.part_no,a.part_no) part_no,q.status,q.attempts,q.error,q.remote_id FROM ms_outbox q LEFT JOIN ms_inventory_parts p ON p.job_id=q.id LEFT JOIN ms_inventory_adjustments a ON a.job_id=q.id ORDER BY q.id DESC LIMIT 200'))
                if path=='/api/moysklad/progress':
                    allowed={s['id'] for s in available_shops(d,u)}
                    if u['role'] in ('manager','admin'):
                        allowed.update(s['id'] for s in rows(d,'SELECT id FROM shops'))
                    result={'pending':0,'retry':0,'blocked':[],'configured':moysklad.configured(),
                            'worker_error':moysklad_outbox.WORKER_ERROR}
                    seen=set()
                    for item in rows(d,"SELECT q.id,q.kind,COALESCE(p.document_id,a.document_id,q.local_id) local_id,COALESCE(p.part_no,a.part_no) part_no,q.shop_id,q.status,q.attempts,q.error FROM ms_outbox q LEFT JOIN ms_inventory_parts p ON p.job_id=q.id LEFT JOIN ms_inventory_adjustments a ON a.job_id=q.id WHERE q.status NOT IN ('sent','skipped') ORDER BY q.id"):
                        if item['shop_id'] not in allowed:continue
                        result[item['status']]+=1
                        if item['shop_id'] not in seen:
                            seen.add(item['shop_id'])
                            result['blocked'].append(item)
                    result['last_confirmed_by_shop']={str(item['shop_id']):item['last_confirmed'] for item in rows(d,
                        "SELECT shop_id,MAX(sent_at) AS last_confirmed FROM ms_outbox WHERE status='sent' AND sent_at IS NOT NULL GROUP BY shop_id")
                        if item['shop_id'] in allowed}
                    result['backup_warning']=backup_health(d)['warning']
                    return self.send(result)
                if path=='/api/moysklad/status':
                    is_manager(u)
                    return self.send({**moysklad_bridge.status(d),'backup':backup_health(d),
                                      'register_queue':queue_health(d,{s['id'] for s in rows(d,'SELECT id FROM shops')})})
                if path=='/api/moysklad/references':
                    is_manager(u)
                    try: return self.send({'points':moysklad.Client().references()})
                    except moysklad.SyncError as e: raise ApiError(str(e),502)
                if path=='/api/bootstrap':
                    pack_rules=packaging_rules.rules(d); pack_ids={r['product_id'] for r in pack_rules}
                    shops=available_shops(d,u)
                    synced=one(d,'SELECT synced FROM ms_state WHERE id=1')
                    integrated=bool(synced) and os.environ.get('BEERMAG_DEMO')!='1'
                    if integrated:
                        bound=moysklad_bridge.bound_shop(d)
                        assigned=(bound if u['role']!='seller' and any(s['id']==bound for s in shops) else shops[0]['id']) if shops and (u['role']!='seller' or len(shops)==1) else 0
                        reason='' if assigned else 'Проверьте, что сотрудник назначен кассиром ровно одной торговой точки в МоемСкладе.'
                    else:
                        assigned=shops[0]['id'] if shops and not moysklad.configured() else 0
                        reason='' if assigned else 'Ожидаем загрузку торговой точки и товаров из МоегоСклада.'
                    return self.send({'user':public_user(u),'shops':shops,'shop_assignment':{'shop_id':assigned,'reason':reason},'products':[{**p,'barcodes':catalog_import.barcodes(p),'is_packaging':p['kind']=='packaging' or p['id'] in pack_ids,'packaging_enabled':True} for p in rows(d,'SELECT * FROM products ORDER BY name')],'packaging':pack_rules,'suppliers':rows(d,'SELECT * FROM suppliers ORDER BY name'),'organizations':rows(d,'SELECT * FROM organizations'),'version':VERSION,'demo':os.environ.get('BEERMAG_DEMO')=='1','moysklad':moysklad_bridge.active(d),'catalog_synced':synced['synced'] if synced else None,'sales_enabled':moysklad_bridge.sales_enabled(d),'update':update_state(d),'groups':rows(d,'SELECT remote_id AS id,name,path,parent_id FROM ms_folders WHERE archived=0 ORDER BY path')})
                if path=='/api/catalog/status':
                    synced=one(d,'SELECT synced FROM ms_state WHERE id=1')
                    error=one(d,"SELECT value FROM ms_options WHERE key='auto_error'")
                    warning=one(d,"SELECT value FROM ms_options WHERE key='catalog_warning'")
                    progress=moysklad_bridge.progress()
                    return self.send({'synced':synced['synced'] if synced else None,'configured':moysklad.configured(),
                        **progress,'error':progress['error'] or (error['value'] if error and not progress['running'] else ''),
                        'warning':warning['value'] if warning and u['role'] in ('manager','admin') else ''})
                if path=='/api/users':
                    is_manager(u)
                    employees=rows(d,'SELECT u.id,u.login,u.name,u.role,u.shops,u.active,m.needs_password,m.remote_archived FROM users u LEFT JOIN ms_employees m ON m.user_id=u.id ORDER BY u.id')
                    actual=[s['id'] for s in available_shops(d,u)]
                    for employee in employees:
                        if employee['role'] in ('manager','admin'):employee['shops']=dumps(actual)
                    return self.send(employees)
                if path=='/api/registrations':
                    is_manager(u)
                    return self.send(rows(d,'SELECT id,email,name,created FROM registration_requests ORDER BY id'))
                if path=='/api/audit': is_manager(u); return self.send(rows(d,'SELECT a.*,u.name user FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 300'))
                shop=access(d,u,q.get('shop_id',[0])[0])
                if path=='/api/documents':
                    kind=q.get('type',['receipt'])[0]; require(kind in ('receipt','sale','inventory'),'Неверный тип',400)
                    records=rows(d,'SELECT d.*,u.name author_name FROM documents d JOIN users u ON u.id=d.author WHERE shop_id=? AND type=? ORDER BY d.id DESC LIMIT 300',(shop,kind))
                    if u['role']=='seller' and kind!='sale': records=[r for r in records if r['author']==u['id'] or (kind=='inventory' and r['status']=='draft')]
                    for r in records:
                        r['body']=json.loads(r['body'])
                        if r['type']=='sale':
                            r['sync_status']=moysklad_outbox.public_status(d,r['id'])
                            r['refund_sync_status']=moysklad_outbox.refund_status(d,r['id'])
                            r['return_count']=one(d,'SELECT COUNT(*) n FROM sale_returns WHERE sale_id=?',(r['id'],))['n']
                        if r['type']=='inventory':r['sync_status']=moysklad_outbox.inventory_status(d,r['id'])
                    return self.send([safe_doc(r,u) for r in records])
                if path=='/api/inventory/settings':
                    return self.send(inventory_settings(d,shop))
                if path=='/api/document':
                    r=doc(d,q.get('id',[0])[0],u); require(r['shop_id']==shop)
                    if u['role']=='seller' and r['type']!='sale': require(r['author']==u['id'] or (r['type']=='inventory' and r['status']=='draft'))
                    return self.send(safe_doc(r,u))
                if path=='/api/revisions':
                    is_manager(u); r=doc(d,q.get('id',[0])[0],u); require(r['shop_id']==shop)
                    return self.send(rows(d,'SELECT r.*,u.name user FROM revisions r JOIN users u ON u.id=r.user_id WHERE document_id=? ORDER BY r.id DESC',(r['id'],)))
                if path in ('/api/stock','/api/summary') and moysklad_bridge.active(d):
                    can_stock(u); raise ApiError('Остатки и отчёты пока смотрите в МоемСкладе. Локальный журнал не является его остатками.',409)
                if path=='/api/stock':
                    can_stock(u); s=stock(d,shop)
                    return self.send([{'id':p['id'],'name':p['name'],'kind':p['kind'],'qty':s.get(p['id'],0),'price':p['price']} for p in rows(d,'SELECT * FROM products ORDER BY name')])
                if path=='/api/shift':
                    r=one(d,'SELECT * FROM shifts WHERE shop_id=? AND user_id=? AND closed IS NULL',(shop,u['id']))
                    totals,movements=shift_finances(d,r) if r else ({'cash':0,'card':0,'count':0,'refund_count':0,'refund_cash':0,'refund_card':0,'cash_in':0,'cash_out':0,'cash_on_hand':0},[])
                    others=rows(d,'''SELECT s.id,s.opened,s.user_id,u.name user_name FROM shifts s JOIN users u ON u.id=s.user_id
                        WHERE s.shop_id=? AND s.closed IS NULL AND s.user_id!=? ORDER BY s.id''',(shop,u['id']))
                    last=None
                    if not r and not others:
                        # 0.5.4: итоги последней закрытой смены остаются на экране до открытия новой (продавцы их фотографируют).
                        # Новая смена в магазине (любого продавца) убирает итоги прошлой.
                        # Берём последнюю закрытую смену магазина; продавцу показываем её, только если это его смена
                        # или он сам её закрыл — старые смены других продавцов не всплывают.
                        last=one(d,'''SELECT s.*,u.name user_name,c.name closed_by_name FROM shifts s LEFT JOIN users u ON u.id=s.user_id
                            LEFT JOIN users c ON c.id=s.closed_by WHERE s.shop_id=? AND s.closed IS NOT NULL ORDER BY s.closed DESC,s.id DESC LIMIT 1''',(shop,))
                        if last and u['role'] not in ('admin','manager') and u['id'] not in (last['user_id'],last['closed_by']):last=None
                        if last:
                            last_totals,last_movements=shift_finances(d,last)
                            last={**last,'totals':last_totals,'movements':last_movements,
                                  'difference':(last['closing_cash']-last['expected_cash']) if last['expected_cash'] is not None and last['closing_cash'] is not None else None}
                    draft=bool(one(d,"SELECT id FROM documents WHERE shop_id=? AND type='inventory' AND status='draft'",(shop,)))
                    return self.send({'shift':r,'totals':totals,'movements':movements,'others':others,'last_closed':last,'inventory_draft':draft})
                if path=='/api/shifts':
                    # Closed and open shifts with the cash count, for daily control.
                    limit=min(max(int(q.get('limit',[60])[0]),1),500)
                    mine='' if u['role'] in ('manager','admin') else ' AND s.user_id=?'
                    args=(shop,)+(() if not mine else (u['id'],))+(limit,)
                    result=rows(d,'''SELECT s.*,u.name user_name,c.name closed_by_name FROM shifts s
                        LEFT JOIN users u ON u.id=s.user_id LEFT JOIN users c ON c.id=s.closed_by
                        WHERE s.shop_id=?'''+mine+' ORDER BY s.id DESC LIMIT ?',args)
                    for item in result:
                        totals,_=shift_finances(d,item)
                        item['totals']=totals
                        item['difference']=(item['closing_cash']-item['expected_cash']) if item['closed'] and item['expected_cash'] is not None and item['closing_cash'] is not None else None
                    return self.send(result)
                if path=='/api/summary':
                    can_stock(u); result=[]
                    for s in available_shops(d,u):
                        totals={'cash':0,'card':0,'count':0}
                        for x in rows(d,"SELECT id,body FROM documents WHERE shop_id=? AND type='sale' AND status IN ('posted','refunded')",(s['id'],)):
                            b=json.loads(x['body']);cash,card=pay_split(b);totals['count']+=1
                            if not b.get('refund_shift_id'):totals['cash']+=cash;totals['card']+=card
                            for returned in rows(d,'SELECT body FROM sale_returns WHERE sale_id=?',(x['id'],)):
                                rb=json.loads(returned['body']);rb.setdefault('payment',b['payment'])
                                cash,card=pay_split(rb);totals['cash']-=cash;totals['card']-=card
                        result.append({**s,**totals,'negative':sum(v<0 for v in stock(d,s['id']).values()),'pending':one(d,"SELECT COUNT(*) n FROM documents WHERE shop_id=? AND type='inventory' AND status='submitted'",(s['id'],))['n']})
                    return self.send(result)
                raise ApiError('Не найдено',404)
        except ApiError as e: self.send({'error':e.message},e.code)
        except (ValueError,TypeError,KeyError,OverflowError): self.send({'error':'Неверный запрос.'},400)
        except Exception: traceback.print_exc(); self.send({'error':'Ошибка сервера. Данные не изменены.'},500)
    def local_host(self):
        port=self.server.server_address[1]
        require((self.headers.get('Host') or '').lower() in ('127.0.0.1:%d'%port,'localhost:%d'%port),'Запрос с другого сайта запрещён',403)
    def do_POST(self):
        try:
            self.local_host()
            require(self.headers.get('X-BeerDesk')=='1','Неверный запрос',403)
            origin=self.headers.get('Origin')
            if origin: require(urlparse(origin).netloc==self.headers.get('Host'),'Запрос с другого сайта запрещён',403)
            size=int(self.headers.get('Content-Length',0)); require(0<size<=12_000_000,'Размер запроса превышен',413)
            b=json.loads(self.rfile.read(size)); require(isinstance(b,dict),'Неверный запрос',400)
            path=urlparse(self.path).path
            if path=='/api/moysklad/token':
                return self.send(set_token(self,b))
            if path in ('/api/moysklad/preview','/api/moysklad/sync'):
                require(os.environ.get('BEERMAG_DEMO')!='1','Демо не подключается к МоемСкладу.',403)
                with connection() as d:
                    u=self.user(d); is_manager(u)
                    stamp=moysklad_bridge.fingerprint(d)
                    existing=rows(d,'SELECT * FROM products ORDER BY id')
                    shops=rows(d,'SELECT * FROM shops WHERE active=1 ORDER BY id')
                    bindings=rows(d,'SELECT * FROM ms_shops')
                    state=moysklad_bridge.status(d)
                try:
                    if path=='/api/moysklad/sync' or 'mappings' not in b:
                        payload=moysklad_bridge.prepare_auto(existing,shops,bindings,b.get('price_name') or state['price_name'])
                    else:payload=moysklad_bridge.prepare(existing,shops,b.get('mappings'),b.get('price_name'))
                    with connection(True) as d:
                        u=self.user(d); is_manager(u)
                        result=moysklad_bridge.save_preview(d,u,payload,stamp)
                        if path=='/api/moysklad/sync':
                            errors=[x for x in payload['rows'] if x['state']=='error']
                            if errors:raise ApiError('Есть конфликты карточек: '+ '; '.join(x['name']+': '+', '.join(x['errors']) for x in errors[:5]),409)
                            result=moysklad_bridge.commit(d,u,result['token'],now())
                            audit(d,u,'moysklad.sync',result)
                            d.execute("DELETE FROM ms_options WHERE key IN ('auto_error','catalog_warning')")
                except moysklad.SyncError as e: raise ApiError(str(e),409)
                return self.send(result)
            if path=='/api/moysklad/start':
                require(os.environ.get('BEERMAG_DEMO')!='1','Демо не подключается к МоемСкладу.',403)
                with connection() as d:
                    u=self.user(d)
                    require(u['role']=='manager' or moysklad_bridge.active(d),'Первую загрузку запускает управляющий.',403)
                try:started=moysklad_bridge.start_sync(sys.modules[__name__])
                except moysklad.SyncError as e:raise ApiError(str(e),409)
                return self.send({'started':started,**moysklad_bridge.progress()})
            if path=='/api/update/restart':
                # Restart to install a downloaded, signed update. Only between shifts.
                with connection(True) as d:
                    u=self.user(d)
                    require(autoupdate.pending(),'Обновление ещё не загружено',409)
                    require(not one(d,'SELECT 1 FROM shifts WHERE closed IS NULL LIMIT 1'),'Сначала закройте смену. Обновление установится после перезапуска.',409)
                    audit(d,u,'update.restart',{'version':autoupdate.pending()['version']})
                self.send({'ok':True})
                threading.Thread(target=lambda:(time.sleep(1),os._exit(42)),daemon=True).start()
                return
            if path=='/api/login/moysklad':
                require(os.environ.get('BEERMAG_DEMO')!='1','В демо доступен только учебный вход',403)
                with connection() as d:require(moysklad_bridge.active(d),'Сначала подключите МойСклад под управляющим',409)
                login=str(b.get('login','')).strip()
                key='ms:'+login.lower();recent=[x for x in FAILURES.get(key,[]) if x>time.time()-300]
                require(len(recent)<10,'Слишком много неверных попыток для этого логина. Повторите через 5 минут.',429)
                password=b.get('password','')
                # Validate the input before considering the offline verifier.
                offline=False
                try:
                    moysklad.basic_credentials(login,password)
                    verified=moysklad.verify_login(login,password)
                except moysklad.CredentialError as e:
                    FAILURES[key]=recent+[time.time()];raise ApiError(str(e),401)
                except moysklad.ConnectivityError:
                    with connection() as d:
                        cached=one(d,'''SELECT u.*,m.remote_id,m.remote_archived,m.offline_password
                            FROM ms_employees m JOIN users u ON u.id=m.user_id
                            WHERE lower(m.offline_login)=? AND m.offline_login!='' ''',(login.lower(),))
                        valid=(cached and cached['active'] and not cached['remote_archived']
                               and cached['offline_password'] and password_ok(password,cached['offline_password']))
                    if not valid:
                        FAILURES[key]=recent+[time.time()]
                        raise ApiError('Нет связи с МоимСкладом. Вход офлайн доступен только после успешного входа этого сотрудника на этой кассе.',503)
                    verified={'id':cached['remote_id'],'points':None};offline=True
                except moysklad.SyncError as e:raise ApiError(str(e),502)
                with connection(True) as d:
                    linked=one(d,'SELECT u.*,m.remote_archived,m.needs_password,m.remote_managed FROM users u JOIN ms_employees m ON m.user_id=u.id WHERE m.remote_id=?',(verified['id'],))
                    reason=None
                    privilege=verified.get('privilege') if not offline else None
                    revoked=False
                    if linked and not offline and not linked['remote_archived']:
                        if linked['remote_managed'] and privilege not in ('manager','admin'):
                            revoked=True
                            d.execute("UPDATE users SET role='seller',active=0,shops='[]' WHERE id=?",(linked['id'],))
                            d.execute("UPDATE ms_employees SET remote_managed=0,offline_login='',offline_password='' WHERE remote_id=?",(verified['id'],))
                            d.execute('DELETE FROM sessions WHERE user_id=?',(linked['id'],))
                            audit(d,linked,'moysklad.role.revoked',{'remote_id':verified['id']})
                        elif linked['remote_managed'] and (linked['role']!=privilege or not linked['active']):
                            all_shops=[s['id'] for s in available_shops(d,{'role':'manager'})]
                            d.execute('UPDATE users SET role=?,active=1,shops=? WHERE id=?',(privilege,dumps(all_shops),linked['id']))
                            d.execute('DELETE FROM sessions WHERE user_id=?',(linked['id'],))
                            audit(d,linked,'moysklad.role.updated',{'remote_id':verified['id'],'role':privilege})
                        elif (linked['role']=='seller' and linked['needs_password'] and privilege in ('manager','admin')
                              and not moysklad_bridge.locally_configured(d,linked['id'])):
                            all_shops=[s['id'] for s in available_shops(d,{'role':'manager'})]
                            d.execute('UPDATE users SET role=?,active=1,shops=? WHERE id=?',(privilege,dumps(all_shops),linked['id']))
                            d.execute('UPDATE ms_employees SET remote_managed=1 WHERE remote_id=?',(verified['id'],))
                            audit(d,linked,'moysklad.role.verified',{'remote_id':verified['id'],'role':privilege})
                        linked=one(d,'SELECT u.*,m.remote_archived,m.needs_password,m.remote_managed FROM users u JOIN ms_employees m ON m.user_id=u.id WHERE m.remote_id=?',(verified['id'],))
                    if not linked:reason='Сотрудник не найден в синхронизированном списке БирМаг. Управляющему нужно повторить синхронизацию.'
                    elif linked['remote_archived']:reason='Профиль сотрудника находится в архиве МоегоСклада.'
                    elif not linked['active']:
                        if revoked:
                            reason='Административные права МоегоСклада больше не подтверждены. Вход управляющего отключён.'
                        elif linked['role']=='seller' and privilege in ('manager','admin') and moysklad_bridge.locally_configured(d,linked['id']):
                            reason='МойСклад подтвердил вход, но этот профиль меняли вручную в БирМаг. Управляющему нужно проверить его статус в разделе «Сотрудники».'
                        elif linked['role']=='seller' and not json.loads(linked['shops']):
                            reason='МойСклад подтвердил вход, но не подтвердил права владельца или администратора. Продавцу без таких прав нужна назначенная торговая точка.'
                        else:
                            reason='Доступ сотрудника отключён. Проверьте назначение кассира или настройку профиля в БирМаг.'
                    else:
                        u=linked;shops=available_shops(d,u)
                        if u['role']=='seller' and len(shops)!=1:reason='Продавцу нужна ровно одна активная торговая точка. Проверьте назначение кассира в МоемСкладе и повторите синхронизацию.'
                        elif not shops:reason='Нет доступных торговых точек. Повторите синхронизацию.'
                        elif verified['points'] is not None:
                            points={r['shop_id'] for r in rows(d,'SELECT shop_id,retail_id FROM ms_shops') if r['retail_id'] in verified['points']}
                            if not any(s['id'] in points for s in shops):reason='Кассир подтверждён МоимСкладом, но назначенная ему торговая точка не совпадает с данными БирМаг. Повторите синхронизацию.'
                    if not reason:
                        FAILURES.pop(key,None)
                        if not offline:
                            d.execute("UPDATE ms_employees SET offline_login='',offline_password='' WHERE lower(offline_login)=? AND remote_id!=?",
                                      (login.lower(),verified['id']))
                            d.execute('UPDATE ms_employees SET offline_login=?,offline_password=? WHERE remote_id=?',
                                      (login.lower(),offline_password_hash(password),verified['id']))
                        result,cookie=issue_session(d,u)
                        if offline:result['offline']=True
                if reason:raise ApiError(reason,403)
                return self.send(result,cookie=cookie)
            if path=='/api/moysklad/link-self':
                require(os.environ.get('BEERMAG_DEMO')!='1','Демо не подключается к МоемСкладу',403)
                with connection() as d:
                    u=self.user(d);is_manager(u)
                    require(moysklad_bridge.active(d),'Сначала синхронизируйте сотрудников',409)
                key='link:'+str(b.get('login','')).strip().lower();recent=[x for x in FAILURES.get(key,[]) if x>time.time()-300]
                require(len(recent)<10,'Слишком много неверных попыток для этого логина. Повторите через 5 минут.',429)
                try:verified=moysklad.verify_login(str(b.get('login','')).strip(),b.get('password',''))
                except moysklad.CredentialError as e:
                    FAILURES[key]=recent+[time.time()];raise ApiError(str(e),401)
                except moysklad.SyncError as e:raise ApiError(str(e),502)
                with connection(True) as d:
                    u=self.user(d);is_manager(u)
                    remote_id=verified['id']
                    if verified['points'] is not None:
                        mapped={r['retail_id'] for r in rows(d,'SELECT ms.retail_id FROM ms_shops ms JOIN shops s ON s.id=ms.shop_id WHERE s.active=1')}
                        require(bool(mapped.intersection(verified['points'])),'Профиль кассира относится к другой торговой точке. Повторите синхронизацию.',409)
                    linked=one(d,'SELECT * FROM ms_employees WHERE remote_id=?',(remote_id,))
                    require(linked is not None and not linked['remote_archived'],'Этот профиль не найден среди активных сотрудников вашего МоегоСклада',409)
                    own=one(d,'SELECT remote_id FROM ms_employees WHERE user_id=?',(u['id'],))
                    require(not own or own['remote_id']==remote_id,'Управляющий уже привязан к другому профилю',409)
                    if linked['user_id']!=u['id']:
                        duplicate=one(d,'SELECT * FROM users WHERE id=?',(linked['user_id'],))
                        require(duplicate is not None and duplicate['role']=='seller' and linked['needs_password'] and not one(d,'SELECT 1 FROM sessions WHERE user_id=?',(duplicate['id'],)),'Профиль уже используется другим сотрудником',409)
                        require(not one(d,'SELECT 1 FROM documents WHERE author=?',(duplicate['id'],)) and not one(d,'SELECT 1 FROM shifts WHERE user_id=?',(duplicate['id'],)),'У профиля есть история операций. Обратитесь к разработчику.',409)
                        d.execute('UPDATE users SET active=0 WHERE id=?',(duplicate['id'],))
                        d.execute('DELETE FROM ms_employees WHERE remote_id=?',(remote_id,))
                        d.execute('INSERT INTO ms_employees(remote_id,user_id,remote_archived,needs_password) VALUES(?,?,0,0)',(remote_id,u['id']))
                    audit(d,u,'moysklad.login.linked',{'remote_id':remote_id})
                    result={'ok':True}
                FAILURES.pop(key,None)
                return self.send(result)
            if path=='/api/inventory/send':
                with connection() as d:self.user(d)   # остатки читаем только для вошедшего сотрудника
                prefetch_inventory_stock(b)
            with connection(True) as d:
                if path=='/api/register':
                    require(one(d,'SELECT COUNT(*) n FROM users')['n']>0,'Сначала настройте управляющего',409)
                    key=self.client_address[0];recent=[x for x in SIGNUP_ATTEMPTS.get(key,[]) if x>time.time()-300]
                    require(len(recent)<5,'Слишком много заявок. Повторите через 5 минут.',429)
                    email=email_login(b.get('email'));name=txt(b.get('name'),'Имя',100)
                    hashed=password_hash(b.get('password'))
                    old=one(d,'SELECT active FROM users WHERE login=?',(email,))
                    require(not old or not old['active'],'Этот адрес уже зарегистрирован. Войдите или обратитесь к управляющему.',409)
                    require(not one(d,'SELECT id FROM registration_requests WHERE email=?',(email,)),'Заявка с таким email уже ожидает решения',409)
                    d.execute('INSERT INTO registration_requests(email,name,password_hash,created) VALUES(?,?,?,?)',(email,name,hashed,now()))
                    SIGNUP_ATTEMPTS[key]=recent+[time.time()]
                    result={'ok':True,'message':'Заявка отправлена управляющему. После одобрения войдите с этим email и паролем.'};cookie=None
                elif path in ('/api/setup','/api/login'):
                    if path=='/api/setup':
                        require(one(d,'SELECT COUNT(*) n FROM users')['n']==0,'Настройка уже выполнена',409)
                        require(hmac.compare_digest(str(b.get('token','')),SETUP_TOKEN),'Неверный код из окна запуска',403)
                        ph=password_hash(b.get('password','')); login=txt(b.get('login',''),'Логин',80).lower(); name=txt(b.get('name',''),'Имя',100)
                        org=d.execute("INSERT INTO organizations(name) VALUES('ИП — заполните реквизиты')").lastrowid
                        for i in range(1,12): d.execute('INSERT INTO shops(name,organization_id) VALUES(?,?)',(f'Магазин {i:02d}',org))
                        d.execute('INSERT INTO users(login,name,password,role,shops) VALUES(?,?,?,?,?)',(login,name,ph,'manager',dumps(list(range(1,12)))))
                        if b.get('examples'):
                            for name,kind,price in [('Жигулёвское','draft',18000),('Пшеничное','draft',24000),('Тёмное','draft',26000),('Лимонад','draft',12000),('Фисташки','weight',160000),('Сухарики','piece',6500)]: d.execute('INSERT INTO products(name,kind,price) VALUES(?,?,?)',(name,kind,price))
                            for v,p in [(500,1000),(1000,1200),(1500,1500),(2000,1800)]:
                                pid=d.execute('INSERT INTO products(name,kind,price) VALUES(?,?,?)',(f'Бутылка {v/1000:g} л','packaging',p)).lastrowid
                                d.execute('INSERT INTO packaging VALUES(?,?)',(v,pid))
                            d.execute("INSERT INTO suppliers(name) VALUES('Центральный склад')")
                        audit(d,None,'setup',{'examples':bool(b.get('examples'))})
                    key='local:'+str(b.get('login','')).strip().lower(); recent=[x for x in FAILURES.get(key,[]) if x>time.time()-300]
                    require(len(recent)<10,'Слишком много неверных попыток для этого логина. Повторите через 5 минут.',429)
                    u=one(d,'SELECT * FROM users WHERE login=? AND active=1',(str(b.get('login','')).strip().lower(),))
                    if not u or not password_ok(b.get('password',''),u['password']):
                        FAILURES[key]=recent+[time.time()]; raise ApiError('Неверный логин или пароль',401)
                    FAILURES.pop(key,None)
                    result,cookie=issue_session(d,u)
                else:
                    u=self.user(d); key=txt(self.headers.get('Idempotency-Key',''),'Ключ операции',100)
                    fingerprint=hashlib.sha256((path+dumps(b)).encode()).hexdigest()
                    prior=one(d,'SELECT response FROM requests WHERE user_id=? AND key=?',(u['id'],key))
                    if prior:
                        cached=json.loads(prior['response']); require(cached['fingerprint']==fingerprint,'Ключ уже использован другой операцией',409)
                        # Return only a marker: do not replay privileged payload after a role change.
                        result={'duplicate':True}; cookie=None
                    else:
                        result=mutation(d,u,path,b); cookie=None
                        d.execute('INSERT INTO requests(user_id,key,response,created) VALUES(?,?,?,?)',(u['id'],key,dumps({'fingerprint':fingerprint}),int(time.time())))
            if path=='/api/setup':
                try:
                    backup()
                    with connection(True) as d:
                        d.execute("INSERT INTO ms_options VALUES('backup_last',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(now(),))
                except (OSError,sqlite3.Error):
                    with connection(True) as d:
                        d.execute("INSERT INTO ms_options VALUES('backup_error','Не удалось сохранить резервную копию. Проверьте папку копий.') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
            self.send(result,cookie=cookie)
        except ApiError as e: self.send({'error':e.message},e.code)
        except sqlite3.IntegrityError: self.send({'error':'Запись уже существует или связана с другими данными. Проверьте логин и штрихкод.'},409)
        except (ValueError,TypeError,KeyError,OverflowError): self.send({'error':'Проверьте заполнение полей.'},400)
        except Exception: traceback.print_exc(); self.send({'error':'Ошибка сервера. Операция отменена.'},500)

def update_state(d):
    ready=autoupdate.pending()
    return {'ready':ready['version'] if ready else None,'notes':ready.get('notes','') if ready else '',
            'error':autoupdate.STATE['error'],'source':bool(autoupdate.source() if not os.environ.get('BEERMAG_DEMO') else ''),
            'open_shift':bool(one(d,'SELECT 1 FROM shifts WHERE closed IS NULL LIMIT 1'))}

def backup():
    # The optional destination should be a separately backed-up volume or folder.
    target=Path(os.environ.get('BEERMAG_BACKUP_DIR','')).expanduser() if os.environ.get('BEERMAG_BACKUP_DIR') else DB.parent/'backups'
    target.mkdir(parents=True,exist_ok=True)
    filename='beerdesk-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')+'.sqlite3'
    out=target/filename
    temporary=target/(filename+'.tmp')
    try:
        with closing(sqlite3.connect(DB)) as src, closing(sqlite3.connect(temporary)) as dst:
            src.backup(dst)
        # A completed copy must be readable before it becomes a recovery point.
        # immutable=1: проверка только читает готовый файл и не создаёт рядом служебные -wal/-shm
        # (раньше после каждой копии в папке оставались два лишних файла).
        with closing(sqlite3.connect(temporary.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)) as check:
            if check.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                raise sqlite3.DatabaseError('Backup integrity check failed')
        os.replace(temporary,out)
    finally:
        for leftover in (temporary,Path(str(temporary)+'-wal'),Path(str(temporary)+'-shm')):
            if leftover.exists():
                try:leftover.unlink()
                except OSError:pass  # Preserve the original backup error if another process holds the file.
    return out

BACKUP_NAME=re.compile(r'beerdesk-(\d{8})-(\d{6})-\d{6}\.sqlite3$')
BACKUP_LEFTOVER=re.compile(r'beerdesk-\d{8}-\d{6}-\d{6}\.sqlite3\.tmp(-wal|-shm)?$')

def prune_backups(target=None,now_time=None):
    """Keep every copy of the last 48 hours, then one copy per day for 60 days.

    Hourly copies used to accumulate forever and eventually fill the disk.
    Only files created by backup() are considered; copies made before an
    update and anything the user saved by hand are never removed.
    """
    target=Path(target) if target else (Path(os.environ['BEERMAG_BACKUP_DIR']).expanduser() if os.environ.get('BEERMAG_BACKUP_DIR') else DB.parent/'backups')
    if not target.is_dir():return 0
    current=now_time or datetime.now(timezone.utc)
    copies=[]
    for path in target.iterdir():
        # Служебные файлы, оставшиеся от копий прежних версий (до 0.5.7). Свежие не трогаем: копия может ещё создаваться.
        if BACKUP_LEFTOVER.fullmatch(path.name) and path.is_file():
            try:
                if current.timestamp()-path.stat().st_mtime>3600:path.unlink()
            except OSError:pass
            continue
        match=BACKUP_NAME.fullmatch(path.name)
        if not match or not path.is_file():continue
        try:stamp=datetime.strptime(match[1]+match[2],'%Y%m%d%H%M%S').replace(tzinfo=timezone.utc)
        except ValueError:continue
        copies.append((stamp,path))
    copies.sort(reverse=True)
    # 0.5.14: часы компьютера могли уйти вперёд (не тот год) — тогда все копии кажутся старыми. Ничего не удаляем.
    if copies and ((copies[0][0]-current).total_seconds()>86400 or (len(copies)>3 and (copies[0][0]-copies[3][0]).total_seconds()>30*86400)):return 0
    kept_days=set();removed=0
    for index,(stamp,path) in enumerate(copies):
        age=(current-stamp).total_seconds()
        if index<3 or age<=48*3600:continue  # always keep the newest copies
        day=stamp.date()
        if age<=60*86400 and day not in kept_days:
            kept_days.add(day);continue
        try:path.unlink();removed+=1
        except OSError:pass
    return removed

def housekeeping():
    prune_backups()
    with connection(True) as d:
        # Idempotency keys only protect against retries of recent operations.
        d.execute('DELETE FROM requests WHERE created>0 AND created<?',(int(time.time())-45*86400,))
        d.execute('DELETE FROM sessions WHERE expires<?',(int(time.time()),))

def database_ok():
    """Быстрая проверка рабочей базы (только чтение)."""
    try:
        with closing(sqlite3.connect(DB.resolve().as_uri()+'?mode=ro',uri=True,timeout=20)) as d:return d.execute('PRAGMA quick_check').fetchone()[0]=='ok'
    except sqlite3.Error:return False

def backup_problem():
    """0.5.14: понятная причина, почему копия не создалась."""
    if not database_ok():return 'Рабочая база кассы повреждена. Не закрывайте кассу и сразу сообщите управляющему: нужна помощь с восстановлением из резервной копии.'
    try:
        if shutil.disk_usage(DB.parent).free<200*1024*1024:return 'На диске кассы закончилось место. Освободите место на диске — иначе продажи остановятся.'
    except OSError:pass
    return 'Не удалось сохранить резервную копию. Проверьте папку копий.'

def run_backup():
    ok=True
    try:
        backup()
        with connection(True) as d:
            d.execute("INSERT INTO ms_options VALUES('backup_last',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(now(),))
            d.execute("DELETE FROM ms_options WHERE key='backup_error'")
    except (OSError,sqlite3.Error):
        ok=False
        try:
            with connection(True) as d:
                d.execute("INSERT INTO ms_options VALUES('backup_error',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(backup_problem(),))
        except sqlite3.Error:pass  # Try again at the next interval.
    try:housekeeping()   # чистка идёт и тогда, когда копия не удалась (например, кончилось место)
    except (OSError,sqlite3.Error):pass
    return ok

def periodic_backup():
    # sqlite3.backup snapshots a live WAL database without pausing point of sale.
    while True:
        time.sleep(3600)
        run_backup()

if __name__=='__main__':
    for stream in (sys.stdout,sys.stderr):   # вывод в журнал с любой кодировкой Windows не должен ронять кассу
        try:stream.reconfigure(errors='replace')
        except (AttributeError,ValueError):pass
    ap=argparse.ArgumentParser(); ap.add_argument('--host',default='127.0.0.1'); ap.add_argument('--port',type=int,default=8765); ap.add_argument('--no-browser',action='store_true'); ap.add_argument('--backup',action='store_true'); args=ap.parse_args()
    try:
        with app_lock.exclusive(DB.parent/'beermag.lock'):
            init()
            if args.backup: print(backup()); raise SystemExit
            with connection() as d: empty=one(d,'SELECT COUNT(*) n FROM users')['n']==0
            if not empty and not run_backup():
                print('Внимание: резервная копия не создана. '+backup_problem(),flush=True)
            print('\nBeerMag '+VERSION+' | http://127.0.0.1:'+str(args.port),flush=True)
            if empty: print('SETUP CODE / КОД ПЕРВОЙ НАСТРОЙКИ: '+SETUP_TOKEN,flush=True)
            print('Keep this window open / Не закрывайте это окно. Ctrl+C — остановка.\n',flush=True)
            server=KassaHTTPServer((args.host,args.port),Handler)
            threading.Thread(target=moysklad_outbox.run,args=(sys.modules[__name__],),daemon=True).start()
            if os.environ.get('BEERMAG_DEMO')!='1':threading.Thread(target=periodic_backup,daemon=True).start()
            if os.environ.get('BEERMAG_DEMO')!='1':
                threading.Thread(target=moysklad_bridge.run_auto_sync,args=(sys.modules[__name__],),daemon=True).start()
                threading.Thread(target=autoupdate.run,daemon=True).start()
            if not args.no_browser: webbrowser.open('http://127.0.0.1:'+str(args.port))
            try: server.serve_forever()
            except KeyboardInterrupt: server.server_close()
    except RuntimeError as error:
        raise SystemExit(str(error)) from None

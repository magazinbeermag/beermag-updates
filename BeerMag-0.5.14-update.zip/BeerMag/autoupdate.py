"""Автообновление BeerMag: проверка подписанного манифеста, загрузка и установка при запуске.

Касса ставит только обновления, подписанные ключом владельца (RSA-3072, SHA-256).
Скачанное обновление устанавливается при следующем запуске программы, когда
смена ещё не открыта, через тот же update.install, что и ручное обновление.

После установки новая версия «на испытании» (data/update-probation.json), пока её
сервер впервые не ответит значку со своим номером запуска. Если она так и не запустилась,
значок кассы (beermag_app.py) вызывает rollback_failed(): возвращаются прежние файлы
(и база — только если в новой версии не было продаж), а версия отзывается на этой кассе
(data/update-blocked.json) и больше не скачивается. Установка, прерванная выключением
компьютера, завершается или отменяется при следующем запуске (recover_install).

Пробная касса (data/update-channel.txt со словом pilot) берёт обновления из
pilot-manifest.json: так новая версия сначала проверяется на одной кассе,
а остальные получают её, когда владелец опубликует тот же манифест как manifest.json.
"""
import base64, hashlib, json, os, re, time, urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PENDING=ROOT/'updates'/'pending'
LOG=ROOT/'data'/'update-log.txt'
# Обновления лежат в репозитории владельца на GitHub. Другой адрес (например, для проверки на одной кассе)
# можно задать в data/update-source.txt — одна строка https://…/manifest.json
DEFAULT_SOURCE='https://raw.githubusercontent.com/magazinbeermag/beermag-updates/main/manifest.json'
PILOT_SOURCE='https://raw.githubusercontent.com/magazinbeermag/beermag-updates/main/pilot-manifest.json'
def probation_file():return ROOT/'data'/'update-probation.json'
# Сколько раз подряд новая версия может не запуститься, прежде чем касса вернёт прежнюю.
PROBATION_FAILS=3
# Сколько ждать первого ответа новой версии (первый запуск может обновлять базу).
PROBATION_WAIT=600
# Открытый ключ владельца (owner/ОТКРЫТЫЙ-КЛЮЧ.txt). Закрытый ключ есть только у владельца.
PUBLIC_N=int('0xf5d994f10bcb7da5b16fa93db75532c07225768ab0b83793fd572e94bc34e1df4b8d578dafa37d364626da127fb9cea030f74cc62a135fa3567a2fe8ebf7c1a22410acddc4b7d833f9ec1504a38ba188bc99965ad50a06c184a87adfa9d977011f575a37511ac6933a8beb30e039071639762ddbcbac0d8d8afdf2ca5aec89f26a9b537ff941ce459355ec5288a88e9a5fe8903470eda62ac8c6bae481e5aeb42181f95bbc9b8c38ff53d86c2936f6beecfb3201e04293e011e1137fd6eb99355afa4390a1007a91ed941c409d493ac6fd06dbb252e44b939031877015960c524d9ec6f2361705ca99a70670e72ca1eae4d9cc33ab01086c743c3e46e022f52f601471351332a8ef4bca4a7058abe637f718fe6fe4692f7d575846f7e10101499f9ce6c50829ffa85b03bdccafd1976516e84513269004c5e4e64b4b59e6990b0bf5144a4d7a4a864b08595c55c7f8dc836c5c2fcb2a45e74d2c695f6198d0d4afb33ebe142121a2e8b5393fc501349ad97f5bf2df88890d2d2525a5ef2912bd',16)
PUBLIC_E=65537
DIGEST_INFO=bytes.fromhex('3031300d060960864801650304020105000420')  # SHA-256, PKCS#1 v1.5
STATE={'checked':None,'available':None,'ready':None,'error':'','published':None}
LOGGED={'line':''}

def version_tuple(v):
    if not isinstance(v,str) or not re.fullmatch(r'\d+(\.\d+){1,3}',v):raise ValueError('Неверный номер версии')
    return tuple(int(x) for x in v.split('.'))

def current_version():
    m=re.search(r'BeerMag (\d+\.\d+\.\d+)',(ROOT/'server.py').read_text(encoding='utf-8')[:200])
    return m.group(1) if m else '0.0.0'

def channel():
    try:return 'pilot' if (ROOT/'data'/'update-channel.txt').read_text(encoding='utf-8').strip().lower()=='pilot' else ''
    except OSError:return ''

def source():
    url=os.environ.get('BEERMAG_UPDATE_URL','').strip()
    try:url=url or (ROOT/'data'/'update-source.txt').read_text(encoding='utf-8').strip()
    except OSError:pass
    url=url or (PILOT_SOURCE if channel()=='pilot' else DEFAULT_SOURCE)
    if url and not url.startswith('https://'):raise ValueError('Адрес обновлений должен начинаться с https://')
    return url

def verify(data,signature):
    """RSA PKCS#1 v1.5 SHA-256 verification without third-party libraries."""
    k=(PUBLIC_N.bit_length()+7)//8
    try:s=int.from_bytes(base64.b64decode(signature,validate=True),'big')
    except (ValueError,TypeError):return False
    if s>=PUBLIC_N:return False
    em=pow(s,PUBLIC_E,PUBLIC_N).to_bytes(k,'big')
    expected=b'\x00\x01'+b'\xff'*(k-3-len(DIGEST_INFO)-32)+b'\x00'+DIGEST_INFO+hashlib.sha256(data).digest()
    return em==expected

def fetch(url,limit):
    request=urllib.request.Request(url,headers={'User-Agent':'BeerMag-updater'})
    with urllib.request.urlopen(request,timeout=30) as r:
        data=r.read(limit+1)
    if len(data)>limit:raise ValueError('Файл обновления слишком большой')
    return data

def log_once(message):
    """То же сообщение подряд в журнал не повторяется (проверка идёт каждые несколько часов)."""
    if LOGGED['line']!=message:LOGGED['line']=message;log(message)

def log(message):
    try:
        LOG.parent.mkdir(parents=True,exist_ok=True)
        with LOG.open('a',encoding='utf-8') as f:f.write(time.strftime('%Y-%m-%d %H:%M:%S ')+message+'\n')
    except OSError:pass

def check():
    """Download and verify a newer release. Nothing is installed here."""
    url=source()
    if not url:STATE.update(error='',checked=time.time());return None
    raw=fetch(url,64_000)
    signature=fetch(url+'.sig',4_000).decode('ascii','replace').strip()
    if not verify(raw,signature):raise ValueError('Подпись обновления неверна — обновление отклонено')
    manifest=json.loads(raw)
    version=manifest['version'];version_tuple(version)
    STATE.update(checked=time.time(),error='',published=version)
    if version in blocked():
        STATE.update(available=None)
        log_once('Проверка обновлений: версия '+version+' отозвана на этой кассе после отката, ждём следующую')
        return None
    if version_tuple(version)<=version_tuple(current_version()):
        STATE.update(available=None)
        log_once('Проверка обновлений: подпись верна, новых версий нет (на сервере '+version+', на кассе '+current_version()+')')
        return None
    STATE['available']=version
    if not re.fullmatch(r'[0-9a-f]{64}',manifest.get('sha256','')) or not str(manifest.get('url','')).startswith('https://'):
        raise ValueError('Манифест обновления неполный')
    ready=PENDING/'ready.json'
    try:
        if json.loads(ready.read_text(encoding='utf-8'))['version']==version:
            STATE['ready']=version;return version
    except (OSError,ValueError,KeyError):pass
    data=fetch(manifest['url'],80_000_000)
    if hashlib.sha256(data).hexdigest()!=manifest['sha256']:raise ValueError('Контрольная сумма обновления не совпала')
    PENDING.mkdir(parents=True,exist_ok=True)
    archive=PENDING/('BeerMag-'+version+'.zip')
    temporary=archive.with_suffix('.tmp');temporary.write_bytes(data);os.replace(temporary,archive)
    import update
    update.members(archive)  # structure and paths are checked before it is ever offered
    ready.write_text(json.dumps({'version':version,'file':archive.name,'sha256':manifest['sha256'],
                                 'notes':str(manifest.get('notes',''))[:2000]},ensure_ascii=False),encoding='utf-8')
    STATE['ready']=version;log('Загружено обновление '+version)
    return version

def blocked():
    import update
    return update.blocked_versions(ROOT)

def pending():
    try:
        info=json.loads((PENDING/'ready.json').read_text(encoding='utf-8'))
        version_tuple(info['version'])
        if info['version'] in blocked():return None
        return info if version_tuple(info['version'])>version_tuple(current_version()) else None
    except (OSError,ValueError,KeyError):return None

def recover_install():
    """Установка, прерванная выключением компьютера или сбоем, завершается (или отменяется) до запуска кассы."""
    import update, app_lock
    updates=ROOT/'updates'
    if not (updates/update.INSTALLING).is_file() and not any(updates.glob('staging-*')) and not any(updates.glob('partial-*')):return None
    with app_lock.exclusive(ROOT/'data'/'beermag.lock'):
        update.register_closed()
        result=update.recover(ROOT)
    if result and result['result']=='finished':
        log('Прерванная установка обновления '+result['to']+' завершена')
        # Новая версия ещё ни разу не запускалась: она на испытании, как после обычной установки.
        write_probation({'version':result['to'],'previous':result['from'],'installed':time.time(),'fails':0})
        try:
            if json.loads((PENDING/'ready.json').read_text(encoding='utf-8'))['version']==result['to']:_clear()
        except (OSError,ValueError,KeyError):pass
    elif result:log('Прерванная установка обновления '+result['from']+' отменена: касса осталась на версии '+result['to'])
    return result

def apply_pending(database=None):
    """Called by the launcher before the server starts. Never installs during an open shift."""
    try:recovered=recover_install()
    except Exception as error:log('Прерванная установка обновления не исправлена: '+str(error));recovered=None
    info=pending()
    if not info:return recovered['to'] if recovered and recovered['result']=='finished' else None
    archive=PENDING/info['file']
    if not archive.is_file() or hashlib.sha256(archive.read_bytes()).hexdigest()!=info['sha256']:
        log('Обновление '+info['version']+' повреждено, будет скачано снова');_clear();return None
    import sqlite3
    from contextlib import closing
    db=Path(database) if database else ROOT/'data'/'beerdesk.sqlite3'
    if db.exists():
        with closing(sqlite3.connect(db)) as d:
            try:
                if d.execute('SELECT 1 FROM shifts WHERE closed IS NULL LIMIT 1').fetchone():
                    log('Обновление '+info['version']+' отложено: открыта смена');return None
            except sqlite3.Error:pass
    import update
    previous=current_version()
    # The running START_*.bat must not be rewritten under cmd.exe.
    try:update.install(archive,ROOT,keep=('START_WINDOWS.bat','START_MOYSKLAD_WINDOWS.bat'))
    except Exception as error:
        log('Обновление '+info['version']+' не установлено: '+str(error));return None
    write_probation({'version':info['version'],'previous':previous,'installed':time.time(),'fails':0})
    log('Установлено обновление '+info['version']);_clear()
    return info['version']

def write_probation(data):
    try:
        probation_file().parent.mkdir(parents=True,exist_ok=True)
        temporary=probation_file().with_suffix('.tmp')
        temporary.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');os.replace(temporary,probation_file())
    except OSError:pass

def probation():
    """Версия, которая установлена, но ещё ни разу не ответила (или None)."""
    try:
        data=json.loads(probation_file().read_text(encoding='utf-8'))
        return data if data.get('version')==current_version() else None
    except (OSError,ValueError,AttributeError):return None

def probation_passed(version='',answered=False):
    """Испытание пройдено: сервер этого запуска ответил (answered — значок узнал его по номеру запуска).

    Номер версии в ответе сервера не обязателен: если в выпуске забыли поменять его в одном из мест,
    испытание всё равно снимается, иначе через дни простой сбой запуска откатил бы и программу, и базу.
    """
    data=probation()
    if data and (answered or version in (data['version'],current_version())):
        probation_file().unlink(missing_ok=True);log('Обновление '+data['version']+' запустилось успешно')

def probation_failed():
    """Новая версия не запустилась ещё раз. True — пора возвращать прежнюю."""
    data=probation()
    if not data:return False
    data['fails']=int(data.get('fails',0))+1;write_probation(data)
    log('Обновление '+data['version']+' не запустилось (попытка '+str(data['fails'])+' из '+str(PROBATION_FAILS)+')')
    return data['fails']>=PROBATION_FAILS

def rollback_failed():
    """Автооткат: возвращаем файлы; базу — только если в новой версии не было продаж (см. update.rollback)."""
    import update
    data=probation() or {}
    result=update.rollback(ROOT,restore_db=True)
    probation_file().unlink(missing_ok=True);_clear()
    log('Обновление '+result['from']+' не запустилось: касса возвращена к версии '+(result['to'] or data.get('previous','')) +
        ('; база возвращена к копии перед обновлением, база неудачного запуска сохранена: '+result['failed_database'] if result['database_restored'] else '') +
        ('; база оставлена как есть: в новой версии уже были продажи или смены' if result.get('database_kept') else ''))
    return result

def _clear():
    for path in PENDING.glob('*'):
        try:path.unlink()
        except OSError:pass

def explain(error):
    """Понятный текст ошибки проверки для журнала и окна «Состояние»."""
    import urllib.error
    if isinstance(error,urllib.error.HTTPError):
        if error.code==404:return 'файл обновления не найден на сервере (в репозитории ещё нет manifest.json или подписи)'
        return 'сервер обновлений ответил ошибкой HTTP '+str(error.code)
    if isinstance(error,(urllib.error.URLError,TimeoutError,ConnectionError)):return 'нет связи с сервером обновлений'
    if isinstance(error,(json.JSONDecodeError,KeyError)):return 'файл manifest.json повреждён или неполный'
    return str(error)[:300]

def run(interval_hours=3,retry_minutes=15):
    """Проверка при запуске и далее раз в несколько часов; после неудачи — повтор через 15 минут."""
    while True:
        try:check();pause=max(1,interval_hours)*3600
        except Exception as error:
            STATE['error']=explain(error);log_once('Проверка обновлений: '+STATE['error'])
            pause=max(1,retry_minutes)*60
        time.sleep(pause)

def set_pilot(on):
    """ПРОБНАЯ_КАССА.bat: эта касса первой получает новые версии (pilot-manifest.json)."""
    path=ROOT/'data'/'update-channel.txt'
    if on:path.parent.mkdir(parents=True,exist_ok=True);path.write_text('pilot\n',encoding='utf-8')
    else:path.unlink(missing_ok=True)

if __name__=='__main__':
    import sys
    if len(sys.argv)==2 and sys.argv[1] in ('--pilot-on','--pilot-off'):
        set_pilot(sys.argv[1]=='--pilot-on')
    print('Эта касса: '+('ПРОБНАЯ — получает новые версии первой' if channel()=='pilot' else 'обычная — получает версии после проверки на пробной кассе'))

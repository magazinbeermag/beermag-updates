"""Read-only validation and identification of a BeerMag recovery copy.

  check_backup.py <файл.sqlite3>        — проверить копию перед восстановлением
  check_backup.py --make [папка]        — сделать проверенную копию базы сейчас (BACKUP_WINDOWS.bat);
                                          работает и при открытой кассе: копия снимается так же, как
                                          это делает сама касса каждый час, продажи не останавливаются
"""
import argparse
import os
import shutil
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

REQUIRED = {'users', 'shops', 'documents', 'shifts', 'ms_options', 'ms_outbox'}
ROOT = Path(__file__).resolve().parent


def inspect(path):
    path = Path(path).resolve(strict=True)
    if not path.is_file():
        raise ValueError('Укажите файл резервной копии .sqlite3.')
    # immutable=1: копия только читается, рядом не появляются служебные -wal/-shm (как в server.backup).
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)) as db:
        db.row_factory = sqlite3.Row
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('Нарушена целостность базы.')
        tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED.issubset(tables):
            raise ValueError('Это не полная резервная копия BeerMag.')
        opts = dict(db.execute("SELECT key,value FROM ms_options WHERE key IN ('register_id','register_retail_id')"))
        return {
            'register': opts.get('register_id', 'не присвоен'),
            'retail_point': opts.get('register_retail_id', 'не закреплена'),
            'documents': db.execute('SELECT COUNT(*) FROM documents').fetchone()[0],
            'unsent': db.execute("SELECT COUNT(*) FROM ms_outbox WHERE status NOT IN ('sent','skipped')").fetchone()[0],
        }


def make(database=None, folder=None, extra=None):
    """Проверенная копия рабочей базы — в папку копий кассы (и, если указано, ещё в extra).

    Блокировку кассы не берёт: sqlite3.backup читает базу в режиме WAL, не мешая продажам,
    точно так же, как ежечасная копия внутри работающей кассы. Имя копии — как у кассы,
    поэтому её чистка по сроку хранения работает и для этих копий.
    """
    database = Path(database or os.environ.get('BEERDESK_DB') or ROOT / 'data' / 'beerdesk.sqlite3')
    if not database.is_file():
        raise ValueError('База кассы не найдена: ' + str(database))
    if folder is None:
        folder = Path(os.environ['BEERMAG_BACKUP_DIR']).expanduser() if os.environ.get('BEERMAG_BACKUP_DIR') else database.parent / 'backups'
    folder = Path(folder);folder.mkdir(parents=True, exist_ok=True)
    name = 'beerdesk-' + datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f') + '.sqlite3'
    out = folder / name;temporary = folder / (name + '.tmp')
    try:
        with closing(sqlite3.connect(database, timeout=30)) as source, \
             closing(sqlite3.connect(temporary)) as target:
            source.backup(target)
        with closing(sqlite3.connect(temporary.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)) as check:
            if check.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                raise sqlite3.DatabaseError('копия не прошла проверку целостности (возможно, повреждена сама база кассы)')
        os.replace(temporary, out)
    finally:
        for leftover in (temporary, Path(str(temporary) + '-wal'), Path(str(temporary) + '-shm')):
            try:leftover.unlink(missing_ok=True)
            except OSError:pass
    copies = [out]
    if extra:
        extra = Path(extra)
        if extra.is_dir():
            copies.append(Path(shutil.copy2(out, extra / name)))
        else:
            raise ValueError('Папка для копии не найдена: ' + str(extra))
    return copies


def main():
    parser = argparse.ArgumentParser(description='Проверить копию BeerMag перед восстановлением или сделать новую копию')
    parser.add_argument('file', nargs='?', help='Путь к файлу .sqlite3 (проверка) или папка для копии (с --make)')
    parser.add_argument('--make', action='store_true', help='Сделать проверенную копию базы кассы сейчас')
    args = parser.parse_args()
    if args.make:
        try:
            copies = make(extra=args.file)
        except (OSError, sqlite3.Error, ValueError) as error:
            parser.exit(1, 'Копия не сделана: ' + str(error) + '\n')
        print('Копия базы сделана и проверена:')
        for path in copies:print('  ' + str(path))
        print('Касса может продолжать работу. Чтобы унести копию, скопируйте этот файл на флешку.')
        return
    if not args.file:
        parser.exit(1, 'Укажите файл копии .sqlite3.\n')
    try:
        result = inspect(args.file)
    except (OSError, sqlite3.Error, ValueError) as error:
        parser.exit(1, 'Копия не прошла проверку: ' + str(error) + '\n')
    print('Копия целая. Код кассы: {register}; точка МойСклад: {retail_point}; '
          'документов: {documents}; неотправленных операций: {unsent}.'.format(**result))
    print('Восстанавливайте только на место этой кассы после остановки старой установки.')


if __name__ == '__main__':
    main()

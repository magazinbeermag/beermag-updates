"""Полная живая проверка продаж на настоящем МоемСкладе (запускается на кассе, 3–5 минут).

Отличие от ПРОВЕРКА_БЕЗ_ИНТЕРНЕТА: здесь обычный рабочий день при нормальной связи и глубокая сверка.
 1. Берёт КОПИЮ базы кассы — рабочая база, её смены и очередь не меняются.
 2. Через настоящий сервер кассы (те же запросы, что делает окно продавца) открывает смену и пробивает
    чеки: разливное с тарой, весовой, штучный; наличные со сдачей, карта, сложная оплата; повтор чека;
    внесение и выплату; частичный и полные возвраты; закрывает смену. Очередь передаёт штатный
    обработчик кассы в настоящий МойСклад.
 3. Сверяет каждый документ в МоемСкладе: один раз, точка, склад, организация, смена, позиции
    (товар, количество, цена), сумма, наличные/безнал, связь возврата с продажей.
 4. Сверяет остатки склада точки: изменились ровно на проданное минус возвращённое.
 5. Удаляет все свои документы (номера BM-TEST…) и проверяет, что остатки вернулись.
Отчёт: data/live-full-report.txt.
"""
import hashlib, json, os, re, secrets, shutil, sqlite3, sys, tempfile, threading, time, uuid
import urllib.request, urllib.error
from contextlib import closing
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPORT=ROOT/'data'/'live-full-report.txt'
LINES=[];STATE={};PROBLEMS=[];STOP=threading.Event()
ENTITY={'shift_open':'retailshift','sale':'retaildemand','refund':'retailsalesreturn','partial_refund':'retailsalesreturn',
        'cash_in':'retaildrawercashin','cash_out':'retaildrawercashout'}

def say(text=''):
    print(text,flush=True);LINES.append(text)
def check(ok,text):
    say('   '+('✓ ' if ok else '✗ ')+text)
    if not ok:PROBLEMS.append(text)
    return ok
def rub(kopecks):return f'{kopecks/100:.2f}'.replace('.',',')
def line_total(price,qty):
    """Независимый от кассы расчёт: цена (коп.) × количество (тысячные), половина копейки — вверх."""
    return int((Decimal(price)*Decimal(qty)/1000).quantize(Decimal(1),rounding=ROUND_HALF_UP))

def token():
    t=os.environ.get('BEERMAG_MOYSKLAD_TOKEN','').strip()
    if t:return t
    import start_moysklad
    return start_moysklad.saved_token()

class Fresh:
    """Клиент МоегоСклада без общего ограничения по времени: на каждый запрос — новый Client."""
    def _retry(self,method,*a,**k):
        # Чтение для сверки повторяем: МойСклад иногда отвечает 429/5xx или связь моргает.
        for attempt in range(8):
            try:return getattr(STATE['moysklad'].Client(),method)(*a,**k)
            except STATE['moysklad'].SyncError:
                if attempt==7:raise
                time.sleep(2+attempt)
    def get(self,*a,**k):return self._retry('get',*a,**k)
    def all(self,*a,**k):return self._retry('all',*a,**k)
    def stock_for_store(self,*a):return self._retry('stock_for_store',*a)

def delete(kind,remote_id):
    moysklad=STATE['moysklad']
    req=urllib.request.Request(moysklad.BASE+'entity/'+kind+'/'+remote_id,method='DELETE',
        headers={'Authorization':'Bearer '+STATE['tok'],'Accept-Encoding':'gzip'})
    for attempt in range(5):
        try:return urllib.request.urlopen(req,timeout=20).read()
        except urllib.error.HTTPError as e:
            if e.code==404:return b''          # уже удалён
            if attempt==4:raise
        except (urllib.error.URLError,OSError):
            if attempt==4:raise
        time.sleep(2+attempt)

def cleanup():
    """Удалить из МоегоСклада всё, что создала проверка — и при успехе, и при сбое."""
    if not STATE.get('app'):
        if STATE.get('work'):shutil.rmtree(STATE['work'],ignore_errors=True)
        return True
    app,moysklad=STATE['app'],STATE['moysklad'];client=Fresh();clean=True
    say('\n6) Удаляем тестовые документы из МоегоСклада')
    # Сначала останавливаем передачу: иначе документ мог бы появиться в МоемСкладе уже после удаления.
    STOP.set()
    pump=STATE.get('pump')
    if pump:
        pump.join(120)
        if pump.is_alive():clean=False;say('   ✗ передача очереди не остановилась за 2 минуты — проверьте МойСклад на документы '+STATE['tag'])
    with app.connection(True) as d:
        cancelled=d.execute("UPDATE ms_outbox SET status='sent',error='отменено проверкой' WHERE id>=? AND status!='sent'",(STATE['first'],)).rowcount
    if cancelled:say(f'   неотправленных операций отменено: {cancelled}')
    with app.connection() as d:
        jobs=[dict(r) for r in d.execute('SELECT kind,remote_id,sync_id,payload FROM ms_outbox WHERE id>=? ORDER BY id',(STATE['first'],))]
    found=[]
    for job in jobs:
        kind=ENTITY.get(job['kind'])
        if not kind:continue
        name=json.loads(job['payload']).get('name')
        ids={job['remote_id']} if job['remote_id'] else set()
        try:   # документ мог быть создан, а ответ потерян — ищем и по номеру
            ids|={r['id'] for r in client.get('entity/'+kind,filter='name='+name,limit=10).get('rows',[]) if r.get('syncId')==job['sync_id']}
        except moysklad.SyncError:pass
        found+=[(kind,i,name) for i in ids]
    for kind in ('retailsalesreturn','retaildemand','retaildrawercashin','retaildrawercashout','retailshift'):
        for k,ident,name in found:
            if k!=kind:continue
            try:delete(kind,ident);time.sleep(.15)
            except (urllib.error.URLError,OSError) as e:
                clean=False;say(f'   ✗ НЕ удалён {kind} {name} ({ident}) — удалите вручную')
    left=0
    for kind,ident,name in found:
        try:left+=len(client.get('entity/'+kind,filter='name='+name,limit=10).get('rows',[]))
        except moysklad.SyncError:left+=1
    clean&=check(left==0,f'удалено документов: {len(found)}, осталось в МоемСкладе: {left}')
    if STATE.get('stock_before') is not None:
        ok=False
        for _ in range(12):
            now=client.stock_for_store(STATE['store'])
            ok=all(now.get(k,0)==STATE['stock_before'].get(k,0) for k in STATE['watch'])
            if ok:break
            time.sleep(5)
        clean&=check(ok,'остатки проверяемых товаров на складе вернулись к значениям до проверки')
    shutil.rmtree(STATE['work'],ignore_errors=True);STATE.clear()
    return clean

def main():
    tok=token()
    if not tok:raise SystemExit('Нет сохранённого API-токена. Сначала запустите кассу и введите токен.')
    os.environ['BEERMAG_MOYSKLAD_TOKEN']=tok
    source=ROOT/'data'/'beerdesk.sqlite3'
    if not source.exists():raise SystemExit('База кассы не найдена.')
    with closing(sqlite3.connect(source)) as real:   # как в live_test.py: при открытой смене проверка не идёт
        if real.execute('SELECT 1 FROM shifts WHERE closed IS NULL LIMIT 1').fetchone():
            raise SystemExit('На этой кассе открыта смена. Запустите проверку после закрытия смены (или до открытия).')
    work=Path(tempfile.mkdtemp(prefix='beermag-live-full-'));STATE['work']=work
    copy=work/'copy.sqlite3'
    with closing(sqlite3.connect(source)) as a,closing(sqlite3.connect(copy)) as b:a.backup(b)
    os.environ['BEERDESK_DB']=str(copy)
    sys.path.insert(0,str(ROOT))
    import server as app, moysklad, moysklad_outbox as outbox
    app.DB=copy;app.init()
    version=re.search(r'BeerMag (\d+\.\d+\.\d+)',(ROOT/'server.py').read_text(encoding='utf-8')[:200])
    say('БирМаг · полная живая проверка продаж · '+time.strftime('%d.%m.%Y %H:%M')+' · версия '+(version.group(1) if version else '?'))
    say('Папка кассы: '+str(ROOT))
    say('Рабочая база не меняется: используется копия '+str(copy))
    with app.connection(True) as d:
        d.execute("UPDATE ms_outbox SET status='sent' WHERE status!='sent'")   # чужая очередь копии не отправляется
        tag='TEST'+secrets.token_hex(3).upper()
        d.execute("INSERT INTO ms_options(key,value) VALUES('register_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(tag,))
        d.execute("UPDATE shifts SET closed=COALESCE(closed,?) WHERE closed IS NULL",(app.now(),))
        d.execute("UPDATE documents SET status='cancelled' WHERE type='inventory' AND status='draft'")
        # Точка проверки: точка этой кассы; если касса ещё не привязана — первая точка из МоегоСклада.
        # Другую точку можно задать по названию в переменной BEERMAG_TEST_SHOP.
        point=d.execute("SELECT m.* FROM ms_shops m JOIN shops s ON s.id=m.shop_id WHERE s.name=?",(os.environ.get('BEERMAG_TEST_SHOP',''),)).fetchone()
        shop=point['shop_id'] if point else (app.moysklad_bridge.bound_shop(d) or (d.execute('SELECT shop_id FROM ms_shops ORDER BY shop_id LIMIT 1').fetchone() or [None])[0])
        if not shop:raise SystemExit('Касса не связана с точкой продаж: торговые точки из МоегоСклада ещё не загружены.')
        point=dict(d.execute('SELECT * FROM ms_shops WHERE shop_id=?',(shop,)).fetchone())
        user=d.execute('''SELECT u.* FROM users u JOIN ms_employees m ON m.user_id=u.id
            WHERE u.active=1 AND m.remote_archived=0 ORDER BY (u.role='manager') DESC,u.id LIMIT 1''').fetchone()
        if not user:raise SystemExit('Нет сотрудника, связанного с МоимСкладом. Войдите в кассу через МойСклад и повторите.')
        employee=d.execute('SELECT remote_id FROM ms_employees WHERE user_id=?',(user['id'],)).fetchone()['remote_id']
        if user['role']=='seller' and shop not in json.loads(user['shops']):
            d.execute('UPDATE users SET shops=? WHERE id=?',(json.dumps([shop]),user['id']))
        session=secrets.token_urlsafe(24)
        d.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(session.encode()).hexdigest(),user['id'],int(time.time())+3600))
        d.execute("INSERT INTO ms_options VALUES('sales_enabled','1') ON CONFLICT(key) DO UPDATE SET value='1'")
        usable="active=1 AND price>0 AND source_uuid!=''"
        bag=d.execute("SELECT * FROM products WHERE "+usable+" AND source_code='01872'").fetchone() or \
            d.execute("SELECT * FROM products WHERE "+usable+" AND kind='piece' ORDER BY price,id LIMIT 1").fetchone()
        piece=d.execute("SELECT * FROM products WHERE "+usable+" AND kind='piece' AND id!=? ORDER BY price,id LIMIT 1",(bag['id'] if bag else 0,)).fetchone()
        weights=d.execute("SELECT * FROM products WHERE "+usable+" AND kind='weight' ORDER BY price,id").fetchall()
        drafts=d.execute("SELECT * FROM products WHERE "+usable+" AND kind='draft' ORDER BY price,id").fetchall()
        beers=[x for x in drafts if 'пиво' in x['name'].lower()]
        drafts=(beers if len(beers)>=2 else drafts)[:2]
        packs={r['volume']:dict(d.execute('SELECT * FROM products WHERE id=?',(r['product_id'],)).fetchone()) for r in d.execute('SELECT * FROM packaging')}
        shop_name=d.execute('SELECT name FROM shops WHERE id=?',(shop,)).fetchone()[0]
    if not (bag and piece and weights and drafts):raise SystemExit('В каталоге кассы не хватает товаров для проверки (нужны штучный, весовой и разливной с ценой).')
    for volume in (500,1000,1500):
        if volume not in packs or not packs[volume]['source_uuid']:raise SystemExit(f'Не настроена тара {volume/1000:g} л — проверка разливного невозможна.')
    weight=weights[0]
    # Весовой товар и вес, при которых выходит ровно полкопейки: проверка округления «как в МоемСкладе».
    half=next(((w,q) for w in weights for q in (285,345,155,415)+tuple(range(5,1000,5)) if (w['price']*q)%1000==500),None)
    odd=next((w for w in weights if w['price']%1000),None) or weights[min(1,len(weights)-1)]   # цена не кратна 10 ₽
    draft,draft2=drafts[0],drafts[-1]
    bag,piece,weight,draft,draft2=map(dict,(bag,piece,weight,draft,draft2))
    say(f'Точка: {shop_name} · сотрудник: {user["name"]} · номер проверки: {tag}')
    say('Товары: '+'; '.join(f'{p["name"]} — {rub(p["price"])} ₽' for p in (draft,draft2,weight,piece,bag))+
        (f'; полкопейки: {half[0]["name"]} {half[1]/1000:g} кг по {rub(half[0]["price"])} ₽' if half else ''))
    if not half:say('Случай «полкопейки» в этом каталоге невозможен: у весовых товаров нет цен, дающих дробную копейку при весе в граммах.')

    http=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
    threading.Thread(target=http.serve_forever,daemon=True).start()
    url='http://127.0.0.1:%d'%http.server_port
    def call(path,body=None,key=None,expect_error=False):
        req=urllib.request.Request(url+path,data=json.dumps(body).encode() if body is not None else None,
            headers={'X-BeerDesk':'1','Content-Type':'application/json','Idempotency-Key':key or str(uuid.uuid4()),'Cookie':'beerdesk='+session})
        try:
            with urllib.request.urlopen(req) as r:result=json.load(r)
        except urllib.error.HTTPError as e:
            message=json.load(e).get('error','')
            if expect_error:return {'refused':message}
            raise SystemExit('Касса отказала: '+path+' · '+message)
        if expect_error:return {'accepted':result}
        return result
    def queue():
        with app.connection() as d:
            return [dict(r) for r in d.execute('SELECT id,kind,status,error,attempts FROM ms_outbox WHERE id>=? ORDER BY id',(STATE.get('first',0),))]

    STATE['moysklad']=moysklad;client=Fresh()
    store=point['store_id']
    stock_before=client.stock_for_store(store)
    with app.connection() as d:
        first=(d.execute('SELECT COALESCE(MAX(id),0)+1 FROM ms_outbox').fetchone()[0])
    STATE.update(app=app,first=first,tok=tok,moysklad=moysklad,tag=tag,store=store)

    # ---------------------------------------------------------------- рабочий день
    say('\n1) Рабочий день через сервер кассы (те же запросы, что делает окно продавца)')
    def pump():
        # Та же функция, что крутится в настоящей кассе (moysklad_outbox.process_one), но с возможностью остановки.
        while not STOP.is_set():
            try:
                if outbox.process_one(app):continue
            except Exception:pass
            STOP.wait(1)
    STATE['pump']=threading.Thread(target=pump,daemon=True);STATE['pump'].start()
    opening=100000
    call('/api/shifts/open',{'shop_id':shop,'cash':rub(opening).replace(',','.')})
    expected_docs=[];sold={}
    def item(p,qty):return {'uuid':p['source_uuid'],'qty':qty,'price':p['price'],'name':p['name']}
    def receipt(title,payment,parts,cash_part=None,received=None,key=None):
        """parts: ('draft',товар,объём мл,бутылок) | ('qty',товар,количество в тысячных)."""
        lines=[];expect=[]
        for part in parts:
            if part[0]=='draft':
                _,p,volume,count=part
                lines.append({'product_id':p['id'],'qty':volume*count/1000,'volume':volume/1000,'count':count,'packaging_id':packs[volume]['id']})
                expect+=[item(packs[volume],count*1000),item(p,volume*count)]
            else:
                _,p,qty=part
                lines.append({'product_id':p['id'],'qty':qty/1000});expect.append(item(p,qty))
        total=sum(line_total(x['price'],x['qty']) for x in expect)
        body={'shop_id':shop,'payment':payment,'expected_total':total/100,'lines':lines}
        if payment=='cash':body['received']=str((received or total)/100)
        if payment=='mixed':
            cash_part=max(1,(total//2)//100*100);body['cash_amount']=f'{cash_part/100:.2f}'
        r=call('/api/sales',body,key)
        STATE['last_body']=body
        cash,card=(total,0) if payment=='cash' else (0,total) if payment=='card' else (cash_part,total-cash_part)
        same=r['body']['total']==total
        change=r['body'].get('change',0)
        check(same,f'{title}: {len(expect)} поз., итог кассы {rub(r["body"]["total"])} ₽ = независимый расчёт {rub(total)} ₽'+
              (f', сдача {rub(change)} ₽' if change else '')+(f' (нал {rub(cash)} + карта {rub(card)})' if payment=='mixed' else ''))
        doc={'id':r['id'],'title':title,'lines':expect,'total':total,'cash':cash,'card':card}
        expected_docs.append(('sale',r['id'],doc))
        for x in expect:sold[x['uuid']]=sold.get(x['uuid'],0)+x['qty']
        return doc
    s1=receipt('Чек 1, наличные со сдачей','cash',[('draft',draft,1000,2),('qty',bag,1000)],received=None)
    s2=receipt('Чек 2, карта','card',[('qty',weight,345),('qty',piece,3000)])
    half_part=[('qty',half[0],half[1])] if half else [('qty',weight,285)]
    s3=receipt('Чек 3, сложная оплата','mixed',[('draft',draft2,500,1),('draft',draft,1500,1)]+half_part)
    if os.environ.get('BEERMAG_TEST_ABORT'):
        time.sleep(float(os.environ['BEERMAG_TEST_ABORT']));raise SystemExit('проверочная остановка посреди дня (проверка уборки)')
    key=str(uuid.uuid4())
    s4=receipt('Чек 4, наличные без сдачи','cash',[('qty',bag,2000)],key=key)
    dup=call('/api/sales',STATE['last_body'],key)
    check(bool(dup.get('duplicate')),'повтор чека 4 тем же ключом (двойное нажатие): второй чек не создан')
    s5=receipt('Чек 5, карта','card',[('qty',dict(odd),1005),('qty',piece,1000)])
    # касса обязана отказать
    r=call('/api/sales',{'shop_id':shop,'payment':'card','expected_total':(piece['price']+100)/100,'lines':[{'product_id':piece['id'],'qty':1}]},expect_error=True)
    check('refused' in r,'чек с устаревшей ценой касса не провела: «'+r.get('refused','ПРОВЕЛА')[:70]+'»')
    r=call('/api/sales',{'shop_id':shop,'payment':'cash','expected_total':piece['price']/100,'received':str((piece['price']-100)/100),'lines':[{'product_id':piece['id'],'qty':1}]},expect_error=True)
    check('refused' in r,'чек, где получено меньше итога, касса не провела')
    r=call('/api/sales',{'shop_id':shop,'payment':'card','expected_total':piece['price']*1.5/100,'lines':[{'product_id':piece['id'],'qty':1.5}]},expect_error=True)
    check('refused' in r,'дробное количество штучного товара касса не приняла')
    # деньги
    call('/api/cash/move',{'shop_id':shop,'kind':'in','amount':'500','note':'проверка: размен'})
    call('/api/cash/move',{'shop_id':shop,'kind':'out','amount':'300','note':'проверка: инкассация'})
    r=call('/api/cash/move',{'shop_id':shop,'kind':'out','amount':'9999999','note':'проверка'},expect_error=True)
    check('refused' in r,'выдачу больше, чем есть в кассе, касса не провела')
    # возвраты
    returns=[]
    call('/api/sales/refund',{'shop_id':shop,'id':s2['id'],'reason':'проверка: частичный','money_returned':True,'lines':[{'line_index':1,'qty':1}]})
    returns.append(('partial',s2,[item(piece,1000)],0,line_total(piece['price'],1000)))
    r=call('/api/sales/refund',{'shop_id':shop,'id':s2['id'],'reason':'проверка: сверх купленного','money_returned':True,'lines':[{'line_index':1,'qty':3}]},expect_error=True)
    check('refused' in r,'возврат больше оставшегося количества касса не провела')
    call('/api/sales/refund',{'shop_id':shop,'id':s4['id'],'reason':'проверка: полный наличными','money_returned':True})
    returns.append(('full',s4,s4['lines'],s4['cash'],s4['card']))
    call('/api/sales/refund',{'shop_id':shop,'id':s3['id'],'reason':'проверка: полный, сложная оплата','money_returned':True})
    returns.append(('full',s3,s3['lines'],s3['cash'],s3['card']))
    r=call('/api/sales/refund',{'shop_id':shop,'id':s4['id'],'reason':'проверка: повторный','money_returned':True},expect_error=True)
    check('refused' in r,'повторный возврат уже возвращённого чека касса не провела')
    returned={}
    for _,_,lines,_,_ in returns:
        for x in lines:returned[x['uuid']]=returned.get(x['uuid'],0)+x['qty']
    # итоги смены
    sales=[s1,s2,s3,s4,s5]
    cash_sales=sum(s['cash'] for s in sales);card_sales=sum(s['card'] for s in sales)
    refund_cash=sum(r[3] for r in returns);refund_card=sum(r[4] for r in returns)
    on_hand=opening+cash_sales-refund_cash+50000-30000
    totals=call('/api/shift?shop_id='+str(shop))['totals']
    check(totals['cash_on_hand']==on_hand,f'наличные в кассе по расчёту кассы {rub(totals["cash_on_hand"])} ₽ = независимый расчёт {rub(on_hand)} ₽')
    check(totals['cash']==cash_sales-refund_cash and totals['card']==card_sales-refund_card and totals['refund_cash']==refund_cash and totals['refund_card']==refund_card,
          f'итоги смены: наличные {rub(totals["cash"])}, карта {rub(totals["card"])}, возвраты нал {rub(totals["refund_cash"])} / карта {rub(totals["refund_card"])} ₽ — совпали с расчётом')
    closed=call('/api/shifts/close',{'shop_id':shop,'cash':f'{on_hand/100:.2f}'})
    check(closed.get('difference')==0,'смена закрыта, разница 0')

    # ---------------------------------------------------------------- передача
    say('\n2) Передача в МойСклад штатным обработчиком кассы')
    started=time.time();shown=set()
    while True:
        jobs=queue();left=[j for j in jobs if j['status']!='sent']
        for j in left:
            if j['error'] and (j['id'],j['error']) not in shown:
                shown.add((j['id'],j['error']));say(f'   … {j["kind"]}: {j["error"]}')
        if not left:break
        if time.time()-started>300:
            PROBLEMS.append('очередь не передана за 5 минут')
            say('   ✗ за 5 минут не передано операций: '+str(len(left))+' (первая: '+left[0]['kind']+')');break
        time.sleep(1)
    jobs=queue()
    check(all(j['status']=='sent' for j in jobs),f'передано операций: {sum(j["status"]=="sent" for j in jobs)} из {len(jobs)} за {int(time.time()-started)} с'+
          (f'; повторных попыток: {sum(j["attempts"]-1 for j in jobs)}' if any(j['attempts']>1 for j in jobs) else ''))
    kinds={}
    for j in jobs:kinds[j['kind']]=kinds.get(j['kind'],0)+1
    check(kinds=={'shift_open':1,'sale':5,'cash_in':2,'cash_out':1,'partial_refund':1,'refund':2,'shift_close':1},
          'в очереди ровно: смена, 5 продаж, 2 внесения (деньги на начало смены и размен), выплата, 3 возврата, закрытие смены')

    # ---------------------------------------------------------------- сверка
    say('\n3) Сверка документов в МоемСкладе')
    with app.connection() as d:
        done=[dict(r) for r in d.execute('SELECT * FROM ms_outbox WHERE id>=? ORDER BY id',(first,))]
    ident=moysklad.ident
    by_kind={}
    for job in done:by_kind.setdefault(job['kind'],[]).append(job)
    def remote(job):
        kind=ENTITY[job['kind']];name=json.loads(job['payload'])['name']
        rows=client.get('entity/'+kind,filter='name='+name,limit=10).get('rows',[])
        mine=[r for r in rows if r.get('syncId')==job['sync_id']]
        once=len(rows)==1 and len(mine)==1 and mine[0]['id']==job['remote_id']
        return kind,name,(client.get('entity/'+kind+'/'+job['remote_id']) if job['remote_id'] else {}),once
    def positions(kind,remote_id):
        return sorted((ident(p.get('assortment',{})),round(Decimal(str(p['quantity']))*1000),int(Decimal(str(p['price']))),float(p.get('discount',0)))
                      for p in client.all('entity/'+kind+'/'+remote_id+'/positions'))
    shift_job=by_kind['shift_open'][0]
    kind,name,shift_doc,once=remote(shift_job)
    check(once and ident(shift_doc.get('retailStore',{}))==point['retail_id'] and ident(shift_doc.get('store',{}))==store
          and ident(shift_doc.get('organization',{}))==point['organization_uuid'] and bool(shift_doc.get('closeDate')),
          f'смена {name}: одна, точка «{shop_name}», склад и организация верные, закрыта {shift_doc.get("closeDate","—")[:16]}')
    sale_remote={}
    for job,doc in zip(by_kind['sale'],sales):
        kind,name,r,once=remote(job);sale_remote[doc['id']]=job['remote_id']
        want=sorted((x['uuid'],x['qty'],x['price'],0.0) for x in doc['lines'])
        got=positions(kind,job['remote_id']) if job['remote_id'] else []
        links=ident(r.get('retailStore',{}))==point['retail_id'] and ident(r.get('store',{}))==store and ident(r.get('organization',{}))==point['organization_uuid'] and ident(r.get('retailShift',{}))==shift_job['remote_id']
        money=r.get('sum')==doc['total'] and r.get('cashSum',0)==doc['cash'] and r.get('noCashSum',0)==doc['card']
        check(once and links and money and got==want and r.get('applicable') is True,
              f'{doc["title"]} → {name}: один, проведён, точка/склад/смена верные, позиций {len(got)} из {len(want)} совпали, сумма {rub(int(r.get("sum",0)))} ₽ (нал {rub(int(r.get("cashSum",0)))} + безнал {rub(int(r.get("noCashSum",0)))})'
              +('' if money else f' ✗ ожидалось {rub(doc["total"])} = {rub(doc["cash"])} + {rub(doc["card"])}')+('' if got==want else ' ✗ позиции отличаются'))
    for job,(mode,sale_doc,lines,cash,card) in zip(by_kind.get('partial_refund',[])+by_kind.get('refund',[]),returns):
        kind,name,r,once=remote(job)
        want=sorted((x['uuid'],x['qty'],x['price'],0.0) for x in lines);got=positions(kind,job['remote_id']) if job['remote_id'] else []
        total=sum(line_total(x['price'],x['qty']) for x in lines)
        linked=ident(r.get('demand',{}))==sale_remote[sale_doc['id']] and ident(r.get('retailShift',{}))==shift_job['remote_id'] and ident(r.get('store',{}))==store
        money=r.get('sum')==total and r.get('cashSum',0)==cash and r.get('noCashSum',0)==card
        check(once and linked and money and got==want and r.get('applicable') is True,
              f'возврат ({"частичный" if mode=="partial" else "полный"}) по «{sale_doc["title"]}» → {name}: один, связан с продажей и сменой, позиций {len(got)}, сумма {rub(int(r.get("sum",0)))} ₽ (нал {rub(int(r.get("cashSum",0)))} + безнал {rub(int(r.get("noCashSum",0)))})'
              +('' if money else f' ✗ ожидалось {rub(total)} = {rub(cash)} + {rub(card)}')+('' if got==want else ' ✗ позиции отличаются'))
    for job_kind,index,amount,label in (('cash_in',0,opening,'деньги на начало смены'),('cash_in',1,50000,'внесение (размен)'),('cash_out',0,30000,'выплата (инкассация)')):
        job=by_kind[job_kind][index];kind,name,r,once=remote(job)
        check(once and r.get('sum')==amount and ident(r.get('agent',{}))==employee and ident(r.get('retailShift',{}))==shift_job['remote_id'] and r.get('applicable') is True,
              f'{label} → {name}: один документ, сумма {rub(int(r.get("sum",0)))} ₽, сотрудник и смена верные')

    say('\n4) Сверка денег: касса ↔ МойСклад')
    ms_sales=[remote(j)[2] for j in by_kind['sale']];ms_returns=[remote(j)[2] for j in by_kind.get('partial_refund',[])+by_kind.get('refund',[])]
    ms_cash=sum(x.get('cashSum',0) for x in ms_sales)-sum(x.get('cashSum',0) for x in ms_returns)
    ms_card=sum(x.get('noCashSum',0) for x in ms_sales)-sum(x.get('noCashSum',0) for x in ms_returns)
    check(ms_cash==totals['cash'] and ms_card==totals['card'],
          f'выручка смены за вычетом возвратов: МойСклад — нал {rub(int(ms_cash))}, безнал {rub(int(ms_card))} ₽; касса — нал {rub(totals["cash"])}, безнал {rub(totals["card"])} ₽')

    say('\n5) Сверка остатков склада «'+shop_name+'»')
    watch=sorted(set(sold));STATE.update(stock_before=stock_before,watch=watch)
    names={x['uuid']:x['name'] for s in sales for x in s['lines']}
    good=False
    for _ in range(12):
        stock_after=client.stock_for_store(store)
        good=all(stock_after.get(k,0)-stock_before.get(k,0)==returned.get(k,0)-sold[k] for k in watch)
        if good:break
        time.sleep(5)
    for k in watch:
        delta=stock_after.get(k,0)-stock_before.get(k,0);want=returned.get(k,0)-sold[k]
        check(delta==want,f'{names[k][:44]}: было {stock_before.get(k,0)/1000:g}, стало {stock_after.get(k,0)/1000:g} (изменение {delta/1000:+g}; продано {sold[k]/1000:g}, возвращено {returned.get(k,0)/1000:g})')
    http.shutdown()
    return not PROBLEMS

if __name__=='__main__':
    try:result=main()
    except SystemExit as e:say('\nПроверка остановлена: '+str(e));result=False
    except Exception as e:
        import traceback
        say('\nПроверка остановлена из-за ошибки: '+type(e).__name__+': '+str(e));say(traceback.format_exc()[-1500:]);result=False
    try:clean=cleanup()
    except Exception as e:say('Удаление тестовых документов не завершено: '+type(e).__name__+': '+str(e));clean=False
    say('\nИТОГ: '+('все проверки пройдены, тестовые документы удалены ✓' if result and clean and not PROBLEMS else
                    'НАЙДЕНЫ ПРОБЛЕМЫ ('+str(len(PROBLEMS))+') — см. строки с ✗ выше'))
    REPORT.parent.mkdir(exist_ok=True);REPORT.write_text('\n'.join(LINES),encoding='utf-8')
    print('\nОтчёт сохранён: '+str(REPORT))

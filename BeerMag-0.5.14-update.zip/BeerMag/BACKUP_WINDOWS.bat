@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
echo Резервная копия базы кассы. Кассу закрывать не нужно: продажи не останавливаются.
echo Чтобы сразу положить копию ещё и на флешку, перетащите папку флешки на этот файл.
echo.
"%~dp0runtime\python.exe" check_backup.py --make %1
pause

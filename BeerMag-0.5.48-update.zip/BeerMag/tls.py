"""0.5.46: доверенные сертификаты HTTPS для МоегоСклада и обновлений.

На двух магазинах касса писала «Windows не доверяет сертификату HTTPS», хотя интернет и время в порядке.
Причина: Python берёт корневые сертификаты только из хранилища Windows, а старая Windows (часто 7) не
докачивает новые корневые сертификаты, пока ими не воспользуется браузер. Теперь касса доверяет тем же
сертификатам Windows (в том числе антивируса и прокси организации) и вдобавок — встроенному набору
cacert.pem (список Mozilla, пакет certifi). Проверка подлинности сервера при этом не отключается:
адрес сервера и цепочка сертификатов проверяются всегда.
"""
import os, ssl, threading, urllib.request

BUNDLE=os.path.join(os.path.dirname(os.path.abspath(__file__)),'cacert.pem')
_LOCK=threading.Lock()
_STATE={'context':None,'bundle':False,'system':False}

def _build():
    try:
        context=ssl.create_default_context();system=True   # хранилище Windows
    except (ssl.SSLError,OSError,ValueError):
        # Испорченная запись в хранилище Windows не должна оставить кассу без связи: тогда — только свой набор.
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);system=False
    context.check_hostname=True;context.verify_mode=ssl.CERT_REQUIRED
    try:context.load_verify_locations(cafile=BUNDLE);bundle=True
    except (ssl.SSLError,OSError,ValueError):bundle=False
    if not system and not bundle:context.load_default_certs()
    return context,system,bundle

def context():
    """Один общий контекст на всю кассу (собирается один раз, ~20 мс)."""
    with _LOCK:
        if _STATE['context'] is None:
            _STATE['context'],_STATE['system'],_STATE['bundle']=_build()
        return _STATE['context']

def handler():return urllib.request.HTTPSHandler(context=context())

def info():
    context();return {'system':_STATE['system'],'bundle':_STATE['bundle']}

def presented_issuer(host,port=443,timeout=6):
    """Кто выдал сертификат, который видит этот компьютер (для проверки: антивирус или прокси подменяют
    сертификат). Только читает сертификат при соединении — никаких данных не отправляет."""
    import socket
    probe=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);probe.check_hostname=False;probe.verify_mode=ssl.CERT_NONE
    with socket.create_connection((host,port),timeout=timeout) as raw:
        with probe.wrap_socket(raw,server_hostname=host) as s:der=s.getpeercert(True)
    import tempfile
    pem=ssl.DER_cert_to_PEM_cert(der)
    handle,path=tempfile.mkstemp(suffix='.pem')
    try:
        with os.fdopen(handle,'w') as f:f.write(pem)
        decoded=ssl._ssl._test_decode_cert(path)
    finally:
        try:os.remove(path)
        except OSError:pass
    names=dict(x for part in decoded.get('issuer',()) for x in part)
    return names.get('commonName') or names.get('organizationName') or ', '.join(names.values())

_ISSUER={}
def issuer_note(url):
    """« Сертификат выдал: …» для сообщения об ошибке (раз в 10 минут, не дольше 4 с; через прокси не проверяем)."""
    import time
    from urllib.parse import urlparse
    parsed=urlparse(url);host=parsed.hostname;key=(host,parsed.port)
    cached=_ISSUER.get(key)
    if cached and time.monotonic()-cached[0]<600:return cached[1]
    try:
        if urllib.request.getproxies().get('https') and not urllib.request.proxy_bypass(host):note=''
        else:note=' Сертификат выдал: «'+presented_issuer(host,parsed.port or 443,timeout=4)[:80]+'».'
    except Exception:note=''
    _ISSUER[key]=(time.monotonic(),note);return note

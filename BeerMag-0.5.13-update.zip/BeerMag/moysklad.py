"""REMAP 1.2 adapter. No credential or raw response leaves this module."""
import gzip
import base64
import http.client
import json
import os
import re
import socket
import ssl
import time
import uuid
from decimal import Decimal, InvalidOperation
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse

BASE = 'https://api.moysklad.ru/api/remap/1.2/'
POS_LOGIN_URL = 'https://online.moysklad.ru/api/posap/1.0/admin/retailstore'
class SyncError(ValueError): pass
class CredentialError(SyncError): pass
class ConnectivityError(SyncError): pass
class TemporaryError(SyncError):
    """Сбой, который проходит сам: МойСклад ответил 5xx или «лимит запросов», связь оборвалась или не ответила вовремя.

    again — запрос стоит повторить сразу (через паузу); pause — пауза, которую назвал сам МойСклад."""
    def __init__(self,message,again=False,pause=None):
        super().__init__(message);self.again=again;self.pause=pause
# МойСклад не смог ответить: это не отказ, а временная неисправность на его стороне.
BUSY_STATUS=(429,500,502,503,504)
# Паузы перед повторами одного запроса чтения. Больше двух повторов не делаем: продавец не должен ждать.
RETRY_PAUSES=(1.5,4.0)
class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl): return None

def configured(): return bool(os.environ.get('BEERMAG_MOYSKLAD_TOKEN', '').strip())
def ident(obj):
    return obj.get('id') or obj.get('meta', {}).get('href', '').rstrip('/').split('/')[-1]

RESOURCE_NAMES={
    'organization':'организации','store':'склады','retailstore':'торговые точки',
    'uom':'единицы измерения','currency':'валюты','product':'товары',
    'employee':'сотрудники','productfolder':'группы товаров',
}

def resource_name(path):
    parts=path.split('/')
    return RESOURCE_NAMES.get(parts[1],parts[1]) if len(parts)>1 else 'справочники'

def network_problem(error):
    reason=error.reason if isinstance(error,URLError) else error
    if isinstance(reason,ssl.SSLCertVerificationError):
        return 'Windows не доверяет сертификату HTTPS. Проверьте дату и время компьютера, сертификаты и настройки прокси.'
    if isinstance(reason,ssl.SSLError):
        return 'Ошибка защищённого соединения HTTPS. Проверьте настройки сети и прокси.'
    if isinstance(reason,socket.gaierror):
        return 'Не найден адрес api.moysklad.ru (DNS). Проверьте соединение и настройки DNS.'
    if isinstance(reason,(socket.timeout,TimeoutError)):
        return 'Истекло время ожидания api.moysklad.ru. Проверьте соединение и повторите.'
    if isinstance(reason,ConnectionRefusedError):
        return 'Соединение с api.moysklad.ru отклонено. Проверьте сеть, прокси и защиту компьютера.'
    if isinstance(reason,(ConnectionResetError,http.client.IncompleteRead)):
        return 'Соединение оборвалось до получения полного ответа. Повторите попытку.'
    code=getattr(reason,'winerror',None) or getattr(reason,'errno',None)
    if code in (10060,110):return 'Истекло время ожидания api.moysklad.ru. Проверьте соединение и повторите.'
    if code in (11001,-2):return 'Не найден адрес api.moysklad.ru (DNS). Проверьте соединение и настройки DNS.'
    if code in (10054,104):return 'Соединение оборвалось до получения полного ответа. Повторите попытку.'
    if isinstance(reason,str):
        lower=reason.lower()
        if 'certificate verify failed' in lower:return 'Windows не доверяет сертификату HTTPS. Проверьте дату и время и настройки прокси.'
        if 'timed out' in lower:return 'Истекло время ожидания api.moysklad.ru. Повторите попытку.'
    return 'Сетевая ошибка при обращении к api.moysklad.ru. Проверьте подключение, DNS или прокси.'

def retry_after(headers):
    """Сколько секунд МойСклад просит подождать при «лимите запросов» (не дольше пяти)."""
    try:
        value=headers.get('X-Lognex-Retry-After') if headers else None
        if value is not None:return max(0.2,min(5.0,int(value)/1000))
        value=headers.get('Retry-After') if headers else None
        if value is not None:return max(0.2,min(5.0,float(value)))
    except (ValueError,TypeError,AttributeError):pass
    return None

def api_error_detail(response):
    """Keep only a bounded, redacted API error message; never expose raw bodies."""
    try:
        data=response.read(8193)
        if len(data)>8192:return ''
        if response.headers.get('Content-Encoding')=='gzip':
            data=gzip.decompress(data)
            if len(data)>8192:return ''
        parsed=json.loads(data)
        errors=parsed.get('errors',[]) if isinstance(parsed,dict) else []
        if not isinstance(errors,list) or not errors or not isinstance(errors[0],dict):return ''
        item=errors[0]
        message=item.get('error','')
        if not isinstance(message,str):return ''
        message=re.sub(r'https?://\S+|Bearer\s+\S+|access_token[=:]\S+','[скрыто]',message,flags=re.I)
        message=re.sub(r'[\x00-\x1f\x7f]+',' ',message).strip()[:240]
        code=item.get('code')
        return (message+(' (код '+str(code)+')' if isinstance(code,int) else '')) if message else ''
    except (OSError,UnicodeError,ValueError,EOFError,TypeError):return ''

def basic_credentials(login,password):
    if not isinstance(login,str) or not isinstance(password,str) or not 1<=len(login)<=100 or not 1<=len(password)<=200 or ':' in login or '\n' in login:
        raise CredentialError('Неверный логин или пароль МоегоСклада.')
    return 'Basic '+base64.b64encode((login+':'+password).encode('utf-8')).decode('ascii')

def employee_privilege(employee):
    """Only explicit MoySklad account administration rights grant elevated POS access."""
    permissions=employee.get('permissions') if isinstance(employee,dict) else None
    if not isinstance(permissions,dict):return None
    admin=permissions.get('admin')
    if not isinstance(admin,dict) or admin.get('view')!='ALL':return None
    owner=permissions.get('ownerAssign')
    return 'manager' if isinstance(owner,dict) and owner.get('view')=='ALL' else 'admin'

def verify_employee_login(login,password,include_role=False):
    """Authenticate through REMAP and return the employee ID; never store a password."""
    basic=basic_credentials(login,password)
    request=Request(BASE+'context/employee',headers={
        'Authorization':basic,
        'Accept':'application/json;charset=utf-8',
        'Accept-Encoding':'gzip',
    })
    try:
        with build_opener(NoRedirect()).open(request,timeout=15) as response:
            data=response.read(1_000_001)
            if len(data)>1_000_000:raise SyncError('Слишком большой ответ при входе в МойСклад.')
            if response.headers.get('Content-Encoding')=='gzip':
                try:data=gzip.decompress(data)
                except (OSError,EOFError):raise SyncError('МойСклад вернул повреждённый ответ при входе.') from None
                if len(data)>1_000_000:raise SyncError('Слишком большой ответ при входе в МойСклад.')
            try:employee=json.loads(data)
            except (ValueError,UnicodeError):raise SyncError('МойСклад вернул некорректный ответ при входе.') from None
            if isinstance(employee,dict):
                context=employee.get('context')
                person=employee.get('employee') or (context.get('employee') if isinstance(context,dict) else None) or employee
            else:person=None
            remote_id=ident(person) if isinstance(person,dict) else ''
            try:uuid.UUID(remote_id)
            except (ValueError,TypeError,AttributeError):raise SyncError('МойСклад не вернул идентификатор сотрудника.') from None
            if person.get('archived'):raise CredentialError('Профиль сотрудника архивирован в МоемСкладе.')
            return {'id':remote_id,'points':None,'privilege':employee_privilege(person)} if include_role else remote_id
    except HTTPError as error:
        if error.code==401:
            raise CredentialError('JSON API отклонил логин или пароль (HTTP 401). Проверьте логин из карточки сотрудника, а не адрес для восстановления пароля.') from None
        if error.code==403:
            raise CredentialError('JSON API запретил вход (HTTP 403). Проверьте разрешение «Доступ по API» для этого сотрудника.') from None
        if error.code in BUSY_STATUS:
            busy=ConnectivityError('МойСклад временно не отвечает (ответ '+str(error.code)+'). Повторите вход через минуту.');busy.status=error.code
            raise busy from None
        raise SyncError('МойСклад не подтвердил вход: HTTP '+str(error.code)+'.') from None
    except (URLError,TimeoutError,OSError,http.client.IncompleteRead) as error:
        raise ConnectivityError('Не удалось проверить вход в МойСклад: '+network_problem(error)) from None

def verify_pos_cashier_login(login,password):
    """Read-only POS authentication for cashiers without REMAP access."""
    request=Request(POS_LOGIN_URL,headers={
        'Authorization':basic_credentials(login,password),
        'Accept':'application/json;charset=utf-8',
    })
    try:
        with build_opener(NoRedirect()).open(request,timeout=15) as response:
            data=response.read(8_000_001)
            if len(data)>8_000_000:raise SyncError('Слишком большой ответ кассового API МоегоСклада.')
            if response.headers.get('Content-Encoding')=='gzip':
                try:data=gzip.decompress(data)
                except (OSError,EOFError):raise SyncError('Повреждённый ответ кассового API МоегоСклада.') from None
                if len(data)>8_000_000:raise SyncError('Слишком большой ответ кассового API МоегоСклада.')
            try:body=json.loads(data)
            except (ValueError,UnicodeError):raise SyncError('Не удалось прочитать ответ кассового API МоегоСклада.') from None
            if not isinstance(body,dict) or not isinstance(body.get('rows'),list):
                raise SyncError('МойСклад вернул неожиданный список торговых точек.')
            matches={}
            for point in body['rows']:
                if not isinstance(point,dict):continue
                try:point_id=str(uuid.UUID(point.get('id','')))
                except (ValueError,TypeError,AttributeError):continue
                cashiers=point.get('cashiers',{})
                for cashier in cashiers.get('rows',[]) if isinstance(cashiers,dict) and isinstance(cashiers.get('rows'),list) else []:
                    if not isinstance(cashier,dict) or str(cashier.get('uid','')).casefold()!=login.casefold():continue
                    try:employee_id=str(uuid.UUID(cashier.get('id') or cashier.get('meta',{}).get('id','')))
                    except (ValueError,TypeError,AttributeError):continue
                    matches.setdefault(employee_id,set()).add(point_id)
            if len(matches)!=1:
                raise CredentialError('Логин подтверждён МоимСкладом, но кассир не найден на одной торговой точке. Введите логин сотрудника из МоегоСклада и проверьте назначение кассира.')
            employee_id,points=next(iter(matches.items()))
            return {'id':employee_id,'points':sorted(points)}
    except HTTPError as error:
        if error.code==401:raise CredentialError('МойСклад отклонил логин или пароль кассира (HTTP 401). Проверьте вход в МойСклад и полный логин сотрудника.') from None
        if error.code==403:raise CredentialError('МойСклад запретил кассиру доступ к торговой точке (HTTP 403). Проверьте назначение кассира и права сотрудника.') from None
        if error.code in BUSY_STATUS:
            busy=ConnectivityError('Кассовый API МоегоСклада временно не отвечает (ответ '+str(error.code)+'). Повторите вход через минуту.');busy.status=error.code
            raise busy from None
        raise SyncError('Кассовый API МоегоСклада не подтвердил вход: HTTP '+str(error.code)+'.') from None
    except (URLError,TimeoutError,OSError,http.client.IncompleteRead) as error:
        raise ConnectivityError('Не удалось проверить вход кассира: '+network_problem(error)) from None

def verify_login(login,password):
    """Return verified employee identity and POS points, if POS was used.

    МойСклад иногда отвечает 503 на секунду-другую: один раз повторяем, и только потом считаем его недоступным
    (тогда касса пускает сотрудника по сохранённому входу, как без интернета)."""
    try:return _verify_login(login,password)
    except ConnectivityError as busy:
        if not getattr(busy,'status',0):raise
        time.sleep(RETRY_PAUSES[0])
        return _verify_login(login,password)

def _verify_login(login,password):
    try:
        verified=verify_employee_login(login,password,include_role=True)
        return verified if isinstance(verified,dict) else {'id':verified,'points':None}
    except CredentialError as primary:
        try:return verify_pos_cashier_login(login,password)
        except CredentialError as cashier:
            # The POS endpoint only returns points where the user is a cashier.
            # For an administrator it can fail even when the relevant problem
            # is the JSON API login. Do not hide that first rejection.
            raise CredentialError('Вход не подтверждён. '+str(primary)+' Кассовый API: '+str(cashier)) from None
        except ConnectivityError:
            # REMAP explicitly rejected these credentials. An unavailable POS
            # endpoint cannot turn that denial into an offline login.
            raise SyncError('МойСклад отклонил вход, а кассовый API недоступен. Повторите при восстановлении связи.') from None

class Client:
    def __init__(self, token=None, retries=len(RETRY_PAUSES)):
        # retries — сколько раз повторить запрос чтения после временного сбоя. Очередь передачи операций
        # (moysklad_outbox) повторяет сама и передаёт 0.
        self.retries = max(0, min(int(retries), len(RETRY_PAUSES)))
        self.token = (token or os.environ.get('BEERMAG_MOYSKLAD_TOKEN', '')).strip()
        if not self.token: raise SyncError('Нет API-токена МоегоСклада. Введите его в окне кассы.')
        self.opener = build_opener(NoRedirect())
        self.deadline = time.monotonic() + 180
    def get(self, path, **params):
        """Чтение с повтором: секундный сбой МоегоСклада не должен срывать загрузку каталога или отправку пересчёта."""
        attempt=0
        while True:
            try:return self._get(path, params)
            except TemporaryError as error:
                if not error.again or attempt>=self.retries:raise
                pause=RETRY_PAUSES[attempt] if error.pause is None else error.pause
                attempt+=1
                if time.monotonic()+pause >= self.deadline:raise
                time.sleep(pause)
    def _get(self, path, params):
        section=resource_name(path)
        if time.monotonic() >= self.deadline: raise SyncError('Загрузка заняла слишком много времени (раздел «'+section+'»). Повторите позже.')
        # Path is always a code constant. Never follow URLs from API metadata.
        url = BASE + path + ('?' + urlencode(params) if params else '')
        req = Request(url, headers={'Authorization':'Bearer '+self.token, 'Accept':'application/json;charset=utf-8', 'Accept-Encoding':'gzip'})
        try:
            with self.opener.open(req, timeout=min(20, max(1, self.deadline-time.monotonic()))) as response:
                data = response.read(16_000_001)
                if len(data)>16_000_000: raise SyncError('Ответ МоегоСклада слишком большой (раздел «'+section+'»).')
                declared=str(response.headers.get('Content-Length') or '')
                if declared.isdigit() and len(data)<int(declared):   # ответ оборван посреди передачи — стоит спросить ещё раз
                    raise TemporaryError('МойСклад («'+section+'»): Соединение оборвалось до получения полного ответа. Повторите попытку.',again=True)
                try:
                    if response.headers.get('Content-Encoding')=='gzip': data=gzip.decompress(data)
                except (OSError,EOFError):
                    raise SyncError('Повреждён сжатый ответ МоегоСклада (раздел «'+section+'»). Проверьте сеть или прокси.') from None
                if len(data)>16_000_000:raise SyncError('Ответ МоегоСклада слишком большой (раздел «'+section+'»).')
                try:result=json.loads(data)
                except (ValueError,UnicodeError):
                    raise SyncError('МойСклад вернул некорректный JSON (раздел «'+section+'»). Проверьте сеть или прокси.') from None
                if not isinstance(result,dict):raise SyncError('МойСклад вернул неожиданный формат (раздел «'+section+'»).')
                return result
        except HTTPError as e:
            messages={401:'API-токен не принят.',403:'У токена недостаточно прав.'}
            if 300<=e.code<400:raise SyncError('МойСклад («'+section+'»): API перенаправил запрос (HTTP '+str(e.code)+'). Проверьте сеть или прокси.') from None
            if e.code==429:
                raise TemporaryError('МойСклад («'+section+'»): слишком много запросов подряд. Данные не изменены.',again=True,pause=retry_after(e.headers)) from None
            if e.code in BUSY_STATUS:
                raise TemporaryError('МойСклад («'+section+'»): сервис временно не отвечает (ответ '+str(e.code)+'). Данные не изменены.',again=True) from None
            raise SyncError('МойСклад («'+section+'»): '+messages.get(e.code, 'HTTP '+str(e.code)+'. Данные не изменены.')) from None
        except (URLError, TimeoutError, OSError, http.client.IncompleteRead) as e:
            # Обрыв посреди ответа стоит повторить сразу; «нет интернета» и «не дождались ответа» — нет:
            # продавец не должен ждать ещё минуту, каталог касса перечитает сама чуть позже.
            reason=e.reason if isinstance(e,URLError) else e
            again=isinstance(reason,(ConnectionResetError,ConnectionAbortedError,http.client.IncompleteRead)) or getattr(reason,'winerror',None)==10054 or getattr(reason,'errno',None)==104
            raise TemporaryError('МойСклад («'+section+'»): '+network_problem(e),again=again) from None
    def write(self, method, path, payload):
        kinds=('retailshift','retaildemand','retailsalesreturn','inventory','loss','enter','retaildrawercashin','retaildrawercashout')
        parts=path.split('/')
        if method not in ('POST','PUT') or len(parts) not in (2,3) or parts[0]!='entity' or parts[1] not in kinds or (len(parts)==3 and (parts[1]!='retailshift' or method!='PUT')):
            raise SyncError('Недопустимый тип операции.')
        request=Request(BASE+path,data=json.dumps(payload,ensure_ascii=False).encode(),method=method,
            headers={'Authorization':'Bearer '+self.token,'Accept':'application/json;charset=utf-8','Content-Type':'application/json;charset=utf-8','Accept-Encoding':'gzip'})
        try:
            with self.opener.open(request,timeout=20) as response:
                data=response.read(16_000_001)
                if len(data)>16_000_000:raise SyncError('Ответ слишком большой. Подтверждение будет проверено повторно.')
                if response.headers.get('Content-Encoding')=='gzip':data=gzip.decompress(data)
                return json.loads(data) if data else {}
        except HTTPError as e:
            detail=api_error_detail(e)
            if e.code==401:  # 0.5.4: понятная причина для продавца и управляющего
                raise SyncError('МойСклад не принял API-токен (HTTP 401): токен удалён, заменён или истёк. Управляющему нужно ввести новый токен в «Настройка кассы» → «Сменить API-токен». Операции сохранены и уйдут после этого.') from None
            raise SyncError('Отправка не подтверждена: HTTP '+str(e.code)+((' · '+detail) if detail else '. Проверьте доступ API и настройки торговой точки.')) from None
        except (URLError,TimeoutError,OSError,ValueError):
            raise SyncError('Нет подтверждения от МоегоСклада. Очередь проверит документ повторно.') from None

    def all(self, path, **params):
        result=[]; seen=set()
        for offset in range(0, 10001, 100):
            data=self.get(path, limit=100, offset=offset, **params)
            batch=data.get('rows')
            if not isinstance(batch,list): raise SyncError('Неожиданный формат ответа МоегоСклада.')
            for x in batch:
                uid=ident(x)
                if not uid or uid in seen: raise SyncError('Каталог изменился во время загрузки. Повторите проверку.')
                seen.add(uid)
            result.extend(batch)
            if len(result)>10000: raise SyncError('Превышен лимит этой версии: 10 000 записей.')
            if len(batch)<100: return result
        raise SyncError('Не удалось закончить загрузку.')
    def stock_for_store(self, store_id):
        """Read the complete on-hand stock for one store; never substitute an empty snapshot on failure."""
        store=str(uuid.UUID(str(store_id)))
        result={};names={}
        for row in self.all('report/stock/bystore',filter='store='+BASE+'entity/store/'+store+';stockMode=nonEmpty'):
            per_store=row.get('stockByStore')
            if not isinstance(per_store,list):
                raise SyncError('МойСклад вернул неполный отчёт об остатках. Пересчёт не отправлен.')
            for entry in per_store:
                try:
                    location=str(uuid.UUID(urlparse(entry['meta']['href']).path.rsplit('/',1)[-1]))
                except (KeyError,TypeError,ValueError,AttributeError):
                    raise SyncError('МойСклад вернул склад без идентификатора. Пересчёт не отправлен.') from None
                if location!=store:continue
                try:
                    key=str(uuid.UUID(str(row.get('id') or urlparse(row['meta']['href']).path.rsplit('/',1)[-1])))
                    quantity=Decimal(str(entry['stock']))*1000
                    if not quantity.is_finite() or quantity!=quantity.to_integral_value() or abs(quantity)>10**12:
                        raise ValueError()
                except (KeyError,ValueError,InvalidOperation,TypeError,AttributeError):
                    raise SyncError('МойСклад вернул некорректный остаток. Пересчёт не отправлен.') from None
                if key in result:raise SyncError('Повторяющийся товар в отчёте об остатках. Пересчёт не отправлен.')
                if quantity:result[key]=int(quantity);names[key]=str(row.get('name') or '')[:120]
        self.stock_names=names   # названия — только для понятного сообщения о товарах не из каталога кассы
        return result
    def purchase_price(self, product_id):
        product=self.get('entity/product/'+str(uuid.UUID(str(product_id))))
        price=product.get('buyPrice')
        if not isinstance(price,dict) or price.get('value') is None:
            raise SyncError('У товара нет закупочной цены в МоемСкладе. Управляющий должен указать её перед корректировкой.')
        try:
            currency=ident(price.get('currency') or {})
            if currency:
                if not hasattr(self,'_inventory_currencies'):self._inventory_currencies={}
                if currency not in self._inventory_currencies:
                    self._inventory_currencies[currency]=self.get('entity/currency/'+str(uuid.UUID(currency))).get('isoCode')
                if self._inventory_currencies[currency]!='RUB':
                    raise SyncError('Закупочная цена товара указана не в рублях. Проверьте валюту перед корректировкой остатков.')
            value=Decimal(str(price['value']))
            if not value.is_finite() or value<0 or value!=value.to_integral_value():raise ValueError()
            return int(value)
        except SyncError:
            raise
        except (ValueError,InvalidOperation,TypeError):
            raise SyncError('Закупочная цена товара в МоемСкладе некорректна.') from None
    def references(self):
        orgs={ident(x):x for x in self.all('entity/organization')}
        stores={ident(x):x for x in self.all('entity/store')}
        remote_points=self.all('entity/retailstore')
        if not remote_points:
            raise SyncError('Токен принят, но API МоегоСклада не показал ни одной торговой точки. Проверьте аккаунт, в котором создан токен, и доступ к точкам продаж. Данные кассы сохранены.')
        points=[]
        active=0
        for x in remote_points:
            if not x.get('active',True): continue
            active+=1
            org=orgs.get(ident(x.get('organization',{})))
            store=stores.get(ident(x.get('store',{})))
            if not org or not store or org.get('archived') or store.get('archived'): continue
            points.append({'id':ident(x),'name':x['name'],'store_id':ident(store),'store_name':store['name'],
                           'organization_id':ident(org),'organization_name':org['name'],
                           'inn':org.get('inn',''),'address':x.get('address','')})
        if not points:
            if not active:
                raise SyncError('API МоегоСклада показал торговые точки, но все они выключены. Включите нужную точку в разделе «Розница → Точки продаж». Данные кассы сохранены.')
            raise SyncError('API МоегоСклада показал активные точки, но не вернул доступные склад и организацию для них. Проверьте привязки точки и права токена на склады и организации. Данные кассы сохранены.')
        return points
    def catalog(self, price_name):
        units={ident(x):x.get('name','') for x in self.all('entity/uom')}
        currencies={ident(x):x.get('isoCode','') for x in self.all('entity/currency')}
        raw=[]
        products=self.all('entity/product',filter='archived=false')+self.all('entity/product',filter='archived=true')
        products=list({p['id']:p for p in products}.values())
        for i,p in enumerate(products,2):
            prices=[x for x in p.get('salePrices',[]) if x.get('priceType',{}).get('name')==price_name]
            price=prices[0] if len(prices)==1 else {}
            value=str(Decimal(str(price['value']))/100) if 'value' in price else ''
            currency=currencies.get(ident(price.get('currency',{})),'UNKNOWN')
            codes=[str(v) for code in p.get('barcodes',[]) for v in code.values()]
            raw.append({'_row':i,'UUID':p['id'],'Код':p.get('code',''),'Наименование':p['name'],
                '_folder_uuid':ident(p.get('productFolder',{})) if p.get('productFolder') else '',
                'Единица измерения':units.get(ident(p.get('uom',{})),''),'Цена: Цена продажи':value,
                'Валюта (Цена продажи)':currency,'Штрихкод EAN13':';'.join(codes),
                'Группы':p.get('pathName',''),'Архивный':'да' if p.get('archived') else 'нет',
                'Разливной товар':'да' if p.get('onTap') else 'нет','Весовой товар':'да' if p.get('soldByWeight') else 'нет'})
        if not raw: raise SyncError('Нет доступных активных товаров. Каталог не изменён.')
        return raw

    def employees(self):
        result=[]
        for x in self.all('entity/employee'):
            points=[]
            for cashier in x.get('cashiers',[]):
                # REMAP returns an unexpanded cashier link: /retailstore/{id}/cashiers/{id}.
                # An expanded cashier may instead contain retailStore metadata.
                store=cashier.get('retailStore',{})
                point=ident(store) if isinstance(store,dict) and store else ''
                if not point:
                    href=cashier.get('meta',{}).get('href','')
                    match=re.fullmatch(r'https://api\.moysklad\.ru/api/remap/1\.2/entity/retailstore/([0-9a-fA-F-]{36})/cashiers/[0-9a-fA-F-]{36}',href)
                    point=match.group(1) if match else ''
                try:point=str(uuid.UUID(point))
                except (ValueError,TypeError,AttributeError):continue
                points.append(point)
            result.append({'id':x['id'],'name':x.get('name') or x.get('lastName') or x.get('uid') or x['id'],
                           'uid':x.get('uid',''),'archived':bool(x.get('archived')),
                           'points':sorted(set(points)),'privilege':employee_privilege(x),
                           # Список сотрудников REMAP прав не возвращает (их даёт только вход сотрудника):
                           # без них синхронизация не должна считать, что права отозваны.
                           'privilege_known':isinstance(x.get('permissions'),dict)})
        return result

    def folders(self):
        return [{'id':x['id'],'name':x['name'],'path':'/'.join(filter(None,[x.get('pathName',''),x['name']])),
                 'parent_id':ident(x.get('productFolder',{})) if x.get('productFolder') else '',
                 'archived':bool(x.get('archived'))} for x in self.all('entity/productfolder')]

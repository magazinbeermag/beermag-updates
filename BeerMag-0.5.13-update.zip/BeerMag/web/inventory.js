'use strict';
// Пересчёт магазина по местам хранения (0.4.46).
// Продавец видит только то, что сам нашёл и посчитал: учётные остатки,
// расчётное количество и разница сюда не приходят и нигде не показываются.
const C={selected:new Set(),doc:null,zones:[],zoneId:null,view:'count',settings:null,results:[],hit:0,prompt:null,undo:[],
  timer:null,poll:null,status:'saved',savedAt:null,catalog:false,catalogGroup:'',filter:''};
const countSound=()=>{try{return localStorage.getItem('beermag:inv:sound')!=='off'}catch{return true}};
const countModeKey=()=>`beermag:inv:mode:${S.boot?.user?.id}:${S.shop}`;
function countMode(){try{return localStorage.getItem(countModeKey())||C.settings?.scan_mode||'plus'}catch{return C.settings?.scan_mode||'plus'}}
function beep(ok=true){
  if(!countSound())return;
  try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;C.audio=C.audio||new A();const o=C.audio.createOscillator(),g=C.audio.createGain();
    o.frequency.value=ok?1320:220;o.type=ok?'sine':'square';g.gain.value=.08;o.connect(g);g.connect(C.audio.destination);o.start();o.stop(C.audio.currentTime+(ok?.07:.25))}catch{}
}
const numberText=v=>String(v??'').trim().replace(',','.');
const validQty=(v,kind)=>{const t=numberText(v);if(!/^\d+(\.\d{1,3})?$/.test(t))return false;const n=Number(t);return n>=0&&n<1e9&&(['draft','weight'].includes(kind)||Number.isInteger(n))};
const showQty=v=>String(v).replace('.',',');
// «Ожидает количества»: товар выбран, но число ещё не введено (для весового — «0.»).
const isPending=v=>['','0.','0,'].includes(String(v??'').trim());
// Количество, как его набрал продавец: «2,» и «2.» — это 2 (ожидающее «0,» не трогаем).
const qtyText=v=>isPending(v)?numberText(v):numberText(v).replace(/\.$/,'');
// В поле количества попал скан штрихкода (8+ цифр подряд, возможно после готового «0,»).
const looksLikeBarcode=v=>/^(0[.,])?\d{8,}$/.test(String(v??'').trim());
// Весовой товар: поле начинается с «0,» — продавец дописывает граммы (0,250). Если он набирает
// килограммы («3,65»), получается «0,3,65»: вторую запятую понимаем как «это были килограммы» → «3,65».
function weightTyping(field){
  const m=/^0[.,](\d+)[.,](\d*)$/.exec(field.value);if(!m)return;
  field.value=String(Number(m[1]))+','+m[2];const end=field.value.length;field.setSelectionRange?.(end,end);
}
const pendingItems=zone=>[...zone.items.entries()].filter(([,v])=>isPending(v));
const addQty=(a,b)=>String(Math.round((Number(numberText(a)||0)+Number(numberText(b)))*1000)/1000);
function countProducts(){const byId=new Map(S.boot.products.map(p=>[p.id,p]));const list=C.doc.body.lines.map(l=>({...byId.get(l.product_id),...l,id:l.product_id,category:byId.get(l.product_id)?.category||''}));
  // 0.5.11: товар, заведённый после начала пересчёта, тоже можно найти и посчитать (раньше он уходил с фактом 0).
  const inDoc=new Set(list.map(p=>p.id));
  for(const p of S.boot.products)if(!inDoc.has(p.id)&&(S.boot.moysklad?p.source_uuid:p.active))list.push({...p,product_id:p.id,qty:null,category:p.category||''});
  return list}
function countProduct(id){const n=Number(id);if(!C.byId?.has(n)&&C.doc)C.byId=new Map(countProducts().map(p=>[p.id,p]));return C.byId?.get(n)}
function countZone(){return C.zones.find(z=>z.id===C.zoneId)}
function backupKey(zone){return `beermag:inv:v2:${S.demo?'demo':'live'}:${C.doc.id}:${zone.id}`}
function backupZone(zone){try{localStorage.setItem(backupKey(zone),JSON.stringify({rev:zone.rev,name:zone.name,done:zone.done,items:[...zone.items]}))}catch{}}
function dropBackup(zone){try{localStorage.removeItem(backupKey(zone))}catch{}}
function zoneFromServer(z){return {id:z.id,name:z.name,done:!!z.done,rev:z.rev||0,by:z.by||'',updated:z.updated||'',
  items:new Map(z.items.map(i=>[i.product_id,String(i.qty/1000)])),dirty:0,sent:0,conflict:false}}

async function openCount(id){S.countId=Number(id);S.page='count';C.view='count';C.zoneId=null;C.undo=[];if($('#modal')?.open)close();return render()}
async function countPage(){
  const [r,settings]=await Promise.all([api('/api/document?'+shopArgs()+'&id='+S.countId),api('/api/inventory/settings?'+shopArgs())]);
  if(r.type!=='inventory'||r.status!=='draft'){S.page='inventory';await page();return inventoryForm(r)}
  C.doc=r;C.settings=settings;C.byId=new Map(countProducts().map(p=>[p.id,p]));
  const previous=new Map(C.zones.map(z=>[z.id,z]));
  C.zones=(r.body.zones||[]).map(zoneFromServer);
  if(!r.body.zones){const old=r.body.lines.filter(x=>x.qty!==null);if(old.length)C.zones=[zoneFromServer({id:'legacy',name:'Ранее внесено',items:old.map(x=>({product_id:x.product_id,qty:x.qty}))})]}
  let restored=0;
  for(const z of C.zones){
    const mine=previous.get(z.id);
    if(mine?.dirty&&mine.rev===z.rev){Object.assign(z,{items:mine.items,name:mine.name,done:mine.done,dirty:1});continue}
    try{const saved=JSON.parse(localStorage.getItem(backupKey(z))||'null');
      if(saved&&saved.rev===z.rev&&JSON.stringify(saved.items)!==JSON.stringify([...z.items])){z.items=new Map(saved.items);z.name=saved.name;z.done=saved.done;z.dirty=1;restored++}
      else if(saved)dropBackup(z)}catch{}
  }
  if(!C.zones.some(z=>z.id===C.zoneId))C.zoneId=(C.zones.find(z=>!z.done)||C.zones[0])?.id||null;
  countLayout();
  if(restored){toast('Восстановлены несохранённые числа ('+restored+' мест). Сохраняю…');C.zones.filter(z=>z.dirty).forEach(countQueue)}
  clearInterval(C.poll);C.poll=setInterval(countRefreshOthers,15000);
}
function countLayout(){
  const shop=S.boot.shops.find(x=>x.id===S.shop);
  $('#content').innerHTML=`<div class="count">
  <div class="count-head"><div><h1>Пересчёт № ${C.doc.id}</h1><div class="muted small">${esc(shop?.name||'')} · начат ${shortDate(C.doc.created)}</div></div>
   <div class="count-head-actions"><span id="countSaved" class="count-saved" role="status" aria-live="polite"></span>
   ${btn(countSound()?'🔊 Звук':'🔇 Без звука','count-sound','small ghost')}${(manager()||C.doc.author===S.boot.user.id)?btn('Отменить пересчёт','count-cancel','small ghost danger-text'):''}
   ${C.view==='count'?btn('Итог и отправка →','count-review','primary'):btn('← Вернуться к подсчёту','count-back','')}</div></div>
  <div class="count-body"><aside class="count-places"><div class="count-places-title">Места пересчёта</div><div id="countPlaceList"></div>
   <div class="count-add"><input id="countNewPlace" placeholder="Новое место, например «Витрина 3»" maxlength="80" autocomplete="off" aria-label="Название нового места">${btn('＋','count-place-add','small primary','aria-label="Добавить место"')}</div>
   <div id="countSuggest" class="count-suggest"></div></aside>
   <section class="count-work" id="countWork"></section></div></div>`;
  countSavedLabel();countPlaces();C.view==='count'?countWork():countReview();
}
function countPlaces(){
  const list=$('#countPlaceList');if(!list)return;
  list.innerHTML=C.zones.map(z=>{const n=[...z.items.values()].length;return `<button class="count-place ${z.id===C.zoneId&&C.view==='count'?'active':''} ${z.done?'done':''}" data-action="count-place" data-id="${esc(z.id)}">
    <span class="count-place-mark" aria-hidden="true">${z.done?'✓':z.conflict?'!':n?'●':'○'}</span><span class="count-place-name">${esc(z.name)}</span>
    <span class="count-place-meta">${n} поз.${z.by?' · '+esc(z.by):''}</span></button>`}).join('')||'<div class="muted small">Добавьте первое место</div>';
  const used=new Set(C.zones.map(z=>z.name.toLocaleLowerCase('ru-RU')));
  const free=(C.settings?.places||[]).filter(n=>!used.has(n.toLocaleLowerCase('ru-RU')));
  $('#countSuggest').innerHTML=free.length?`<div class="muted small">Места этого магазина:</div>${free.map(n=>btn('＋ '+esc(n),'count-place-quick','chip',`data-name="${esc(n)}"`)).join('')}`:'';
}
function countSavedLabel(){
  const el=$('#countSaved');if(!el)return;
  const dirty=C.zones.some(z=>z.dirty),conflict=C.zones.some(z=>z.conflict);
  el.className='count-saved '+(conflict||C.status==='error'?'bad':dirty?'wait':'ok');
  el.textContent=conflict?'Есть конфликт — см. место с «!»':C.status==='error'?'Нет связи · числа сохранены на этом компьютере':dirty?'Сохранение…':'✓ Всё сохранено'+(C.savedAt?' · '+C.savedAt:'');
}
function countWork(){
  const work=$('#countWork'),zone=countZone();if(!work)return;
  if(!zone){work.innerHTML=empty('Добавьте место слева — например «Витрина 1» или «Подсобка» — и начинайте сканировать.');return}
  const mode=countMode(),n=zone.items.size;
  work.innerHTML=`<div class="count-zone-head"><div><h2>${esc(zone.name)}</h2><div class="muted small"><span id="countZoneCount">${n} поз.</span>${zone.by?' · последним сохранял(а) '+esc(zone.by):''}</div></div>
   <div class="count-zone-actions">${btn('Переименовать','count-place-rename','small ghost')}${btn('Удалить место','count-place-delete','small ghost danger-text')}
   ${zone.done?btn('Продолжить считать','count-place-reopen','small'):btn('✓ Место посчитано','count-place-done','small green')}</div></div>
   ${zone.conflict?`<div class="notice error"><strong>Это место изменили на другом экране.</strong> Ваши числа остались здесь. ${btn('Загрузить с сервера','count-conflict-load','small')} ${btn('Сохранить мои числа','count-conflict-keep','small primary')}</div>`:''}
   ${zone.done?`<div class="notice ok">Место отмечено как посчитанное. Чтобы что-то исправить, нажмите «Продолжить считать».</div>`:`
   <div class="count-scan"><input id="countScan" placeholder="Сканируйте штрихкод или начните вводить название" autocomplete="off" spellcheck="false" aria-label="Сканер или поиск товара">
    <div class="count-mode" role="group" aria-label="Что делать при скане штучного товара">${btn('+1 за скан','count-mode',mode==='plus'?'active':'','data-mode="plus"')}${btn('Спрашивать кол-во','count-mode',mode==='ask'?'active':'','data-mode="ask"')}</div></div>
   <div id="countResults" class="count-results"></div><div id="countPrompt"></div>`}
   <div id="countLast" class="count-last" role="status" aria-live="polite"></div>
   <div id="countItems"></div>`;
  countItems();countLast();
  $('#countScan')?.focus();
}
function otherPlaces(pid,except){return C.zones.filter(z=>z.id!==except&&z.items.has(pid)).map(z=>esc(z.name)+': '+showQty(z.items.get(pid)))}
function countItems(){
  const box=$('#countItems'),zone=countZone();if(!box||!zone)return;
  const counter=$('#countZoneCount');if(counter)counter.textContent=zone.items.size+' поз.';
  const rows=[...zone.items.entries()].reverse().map(([pid,value])=>{const p=countProduct(pid);if(!p)return '';const also=otherPlaces(pid,zone.id);
    const step=p.kind==='piece'||p.kind==='packaging';
    const wait=isPending(value);
    return `<tr class="${C.flash===pid?'flash':''} ${wait?'pending':''}"><td><strong>${esc(p.name)}</strong><div class="muted small">${esc(p.category||'Без группы')}${also.length?' · также: '+also.join(', '):''}</div></td>
     <td class="count-qty">${!zone.done&&step?btn('−','count-minus','small','data-id="'+pid+'" aria-label="Минус один"'):''}<input class="count-input ${wait?'pending':''}" data-id="${pid}" value="${esc(showQty(value))}" placeholder="${p.kind==='weight'?'0,250':p.kind==='draft'?'л':'шт.'}" inputmode="decimal" autocomplete="off" ${zone.done?'disabled':''} aria-label="Количество ${esc(p.name)}">${!zone.done&&step?btn('+','count-plus','small','data-id="'+pid+'" aria-label="Плюс один"'):''}<span class="unit">${unit(p.kind)}</span></td>
     <td class="right">${zone.done?'':btn('✕','count-remove','small ghost','data-id="'+pid+'" aria-label="Убрать из места"')}</td></tr>`}).join('');
  const waiting=pendingItems(zone).length;
  box.innerHTML=rows?`${waiting?`<div class="notice amber">Введите количество: осталось <strong>${waiting}</strong> ${waiting===1?'товар':'товара(ов)'}. Enter — следующий.</div>`:''}<div class="count-list-head"><strong>Найдено в «${esc(zone.name)}»</strong><span class="muted small">сверху — последние</span></div><div class="tablewrap"><table class="count-table"><tbody>${rows}</tbody></table></div>`:
    (zone.done?empty('В этом месте ничего не найдено'):'<div class="count-hint"><strong>Как считать:</strong><br>1. Сканируйте штрихкод — штучный товар прибавится по 1 шт.<br>2. Много одинаковых? Переключите «Спрашивать кол-во» и введите число.<br>3. Весовой и разливной товар — после выбора введите кг или литры. У весового уже стоит «0,»: граммы допишите (0,350), килограммы набирайте как есть (3,65).<br>4. Товар без штрихкода — наберите часть названия (например «вобла»). По одному: Enter — подсвеченный товар (стрелками ↑↓ можно выбрать другой), впишите количество, Enter — вернётесь к списку. Сразу несколько: отметьте щелчком или Пробелом, затем Enter и впишите количества по очереди.<br>5. Посчитали место — нажмите «✓ Место посчитано».</div>');
  C.flash=null;
}
function countLast(){
  const box=$('#countLast');if(!box)return;const last=C.undo.at(-1);
  if(!last||last.zone!==C.zoneId){box.innerHTML='';box.className='count-last';return}
  const p=countProduct(last.pid);box.className='count-last show';
  box.innerHTML=`<div><div class="count-last-name">${esc(p?.name||'')}</div><div class="count-last-qty">${esc(last.label)}</div></div>${btn('Отменить','count-undo','small')}`;
}
function countSearch(value){
  const q=fold(String(value||'').trim());if(!q)return [];
  const words=q.split(/\s+/);
  return countProducts().filter(p=>{const hay=fold([p.name,p.barcode,p.source_code,...(p.barcodes||[])].join(' '));return words.every(w=>hay.includes(w))}).slice(0,30);
}
function countResults(){
  const box=$('#countResults');if(!box)return;const zone=countZone();
  if(!C.results.length){box.innerHTML='';return}
  // Панель «Выбрать все / Добавить выбранные» стоит над списком и не прокручивается вместе с ним;
  // позиция прокрутки списка сохраняется после каждой отметки.
  const keep=box.querySelector?.('.count-results-list')?.scrollTop||0;
  const n=C.selected.size;
  box.innerHTML=`<div class="count-results-bar"><span class="muted small"><b>По одному:</b> Enter — подсвеченный товар, ↑↓ — выбрать другой. <b>Несколько:</b> отметьте щелчком или Пробелом, затем Enter</span>
    <span>${btn('Выбрать все','count-select-all','small ghost')}${btn(n?`Добавить выбранные (${n})`:'Добавить выбранные','count-add-selected','small primary',n?'':'disabled')}</span></div>
   <div class="count-results-list">`+
   C.results.map((p,i)=>`<button class="count-result ${i===C.hit?'hit':''} ${C.selected.has(p.id)?'picked':''}" data-action="count-pick" data-id="${p.id}" title="Щелчок — отметить, двойной щелчок — добавить сразу"><span><span class="count-check" aria-hidden="true">${C.selected.has(p.id)?'☑':'☐'}</span> ${esc(p.name)}</span><span class="muted small">${zone?.items.has(p.id)&&!isPending(zone.items.get(p.id))?'здесь: '+showQty(zone.items.get(p.id))+' '+unit(p.kind):unit(p.kind)}</span></button>`).join('')+'</div>';
  const list=box.querySelector?.('.count-results-list');if(list){list.scrollTop=keep;if(C.moved)list.querySelector('.count-result.hit')?.scrollIntoView?.({block:'nearest'})}
}
function countToggle(id){id=Number(id);if(C.selected.has(id))C.selected.delete(id);else C.selected.add(id);countResults();$('#countScan')?.focus({preventScroll:true})}
function countAddSelected(ids){
  const zone=countZone();if(!zone||zone.done)return;ids=[...new Set([...C.selected,...ids])].filter(id=>countProduct(id));if(!ids.length)return;
  let first=null;
  for(const id of ids){if(!zone.items.has(id)){zone.items.set(id,countProduct(id).kind==='weight'?'0.':'');first??=id}else first??=id}
  C.selected.clear();C.results=[];C.moved=false;const input=$('#countScan');if(input)input.value='';
  countResults();beep(true);countQueue(zone);countItems();countLast();countPlaces();countFocusPending();   // сверху вниз, как в списке
}
function countFocusPending(prefer=null){
  const inputs=$$('.count-input');const target=(prefer!=null&&inputs.find(x=>Number(x.dataset.id)===Number(prefer)&&x.classList.contains('pending')))||inputs.find(x=>x.classList.contains('pending'));
  if(!target){
    const back=C.returnQuery,input=$('#countScan');C.returnQuery=null;
    if(back&&input&&back.query){input.value=back.query;C.lastQuery=back.query;C.results=countSearch(back.query);C.hit=Math.min(back.hit+1,Math.max(C.results.length-1,0));C.moved=true;C.live=null;countResults();
      input.focus();input.select?.();return false}   // слово выделено: следующий скан или набор заменит его, а не допишется
    input?.focus();return false}
  target.focus();const v=target.value;target.setSelectionRange?.(v.length,v.length);return true;
}
function countScanEnter(){
  const input=$('#countScan');if(!input)return;const value=input.value.trim();
  // Два способа: отметить несколько (щелчок или Пробел) и Enter — добавить отмеченные;
  // ничего не отмечено — стрелками выбрать один и Enter — сразу ввести его количество.
  if(C.results.length&&C.selected.size&&(C.moved||!value||C.lastQuery===value||C.live===value)){C.moved=false;C.live=null;return countAddSelected([...C.selected])}
  const pickHit=()=>{const p=C.results[C.hit];C.returnQuery=C.results.length>1?{query:value,hit:C.hit}:null;C.moved=false;C.live=null;return countPick(p.id,false)};
  if(C.results.length&&C.moved&&C.results[C.hit])return pickHit();
  if(!value)return;
  const all=countProducts();const scanned=all.filter(p=>p.barcode===value||(p.barcodes||[]).includes(value));
  if(scanned.length===1)return countPick(scanned[0].id,true);
  // Один штрихкод у нескольких товаров: ни один не подсвечен — выбрать нужно явно (стрелками или щелчком).
  if(scanned.length>1){C.results=scanned;C.hit=-1;C.live=null;C.lastQuery=value;countResults();beep(false);return countMessage('Штрихкод есть у нескольких товаров — выберите нужный стрелками ↑↓ и Enter или щелчком.',true)}
  // Список по названию уже на экране, первый товар подсвечен: Enter берёт подсвеченный, как в окне продаж.
  if(C.live===value&&C.results[C.hit])return pickHit();
  const found=countSearch(value);C.lastQuery=value;
  if(found.length===1)return countPick(found[0].id,false);
  C.results=found;C.hit=0;C.live=found.length?value:null;countResults();
  if(found.length>1)return countMessage('Найдено '+found.length+'. Enter — взять подсвеченный, ↑↓ — выбрать другой; несколько — отметьте и нажмите «Добавить выбранные».');
  beep(false);input.select();countMessage(/^\d{6,}$/.test(value)?'Штрихкод '+value+' не найден в каталоге. Найдите товар по названию и сообщите управляющему.':'Ничего не найдено. Попробуйте другое слово.',true);
}
function countMessage(text,bad=false){const box=$('#countLast');if(!box)return;box.className='count-last show '+(bad?'bad':'');box.innerHTML=`<div class="count-last-qty">${esc(text)}</div>`}
function countPick(id,scanned){
  const zone=countZone(),p=countProduct(id);if(!zone||!p||zone.done)return;
  C.results=[];countResults();const input=$('#countScan');if(input)input.value='';
  if((p.kind==='piece'||p.kind==='packaging')&&scanned&&countMode()==='plus')return countSet(zone,p.id,addQty(zone.items.get(p.id)||0,1),'+1');
  const had0=zone.items.get(p.id);
  if(had0==null||isPending(had0))return countAddSelected([p.id]);
  C.prompt={pid:p.id};beep(true);
  const had=zone.items.get(p.id);
  $('#countPrompt').innerHTML=`<div class="count-prompt"><div><strong>${esc(p.name)}</strong><div class="muted small">${had!=null?'Уже посчитано здесь: '+showQty(had)+' '+unit(p.kind).replace(/\.$/,'')+'. Введённое число прибавится.':'Сколько найдено в «'+esc(zone.name)+'»?'}</div></div>
   <div class="count-prompt-row"><input id="countPromptQty" inputmode="decimal" autocomplete="off" value="${p.kind==='weight'?'0,':''}" placeholder="${p.kind==='weight'?'0,250':p.kind==='draft'?'литры':'шт.'}" aria-label="Количество"><span class="unit">${unit(p.kind)}</span>
   ${btn(had!=null?'Прибавить':'Добавить','count-prompt-add','primary')}${had!=null?btn('Заменить','count-prompt-set',''):''}${btn('Отмена','count-prompt-cancel','ghost')}</div><div id="countPromptError" class="change-info error"></div></div>`;
  // Весовой товар: «0,» уже введено — продавец дописывает граммы (0,250); килограммы набирает как есть (см. weightTyping).
  const field=$('#countPromptQty');field?.focus();if(p.kind==='weight')field?.setSelectionRange?.(2,2);
}
function countPromptApply(replace){
  const zone=countZone(),p=countProduct(C.prompt?.pid),input=$('#countPromptQty');if(!zone||!p||!input)return;
  if(looksLikeBarcode(input.value)){$('#countPromptError').textContent='Это штрихкод, а не количество. Сначала введите количество для «'+p.name+'» или нажмите «Отмена».';beep(false);input.value=p.kind==='weight'?'0,':'';input.focus();return}
  const v=qtyText(input.value);
  if(!validQty(v,p.kind)){$('#countPromptError').textContent=p.kind==='piece'||p.kind==='packaging'?'Введите целое число штук':'Введите число, например 1,25';beep(false);input.select();return}
  const had=zone.items.get(p.id);const next=replace||had==null?v:addQty(had,v);
  C.prompt=null;$('#countPrompt').innerHTML='';
  countSet(zone,p.id,next,replace||had==null?'= '+showQty(v):'+'+showQty(v));
}
function countSet(zone,pid,value,how){
  const p=countProduct(pid);const before=zone.items.has(pid)?zone.items.get(pid):null;
  if(value===null)zone.items.delete(pid);
  else if(before!==null&&isPending(before))zone.items.set(pid,String(value));   // keep the row in place while filling a list
  else{zone.items.delete(pid);zone.items.set(pid,String(value))}
  C.undo.push({zone:zone.id,pid,before,label:value===null?'убрано из места':how==='='?`${showQty(value)} ${unit(p?.kind)}`:`${how} → ${showQty(value)} ${unit(p?.kind)}`});if(C.undo.length>50)C.undo.shift();
  C.flash=pid;beep(true);countQueue(zone);countItems();countLast();countPlaces();$('#countScan')?.focus();
}
function countQueue(zone){zone.dirty++;backupZone(zone);countSavedLabel();clearTimeout(zone.timer);zone.timer=setTimeout(()=>countSave(zone),600)}
async function countSave(zone,force=false){
  if(zone.saving){zone.again=true;return}
  if(zone.conflict&&!force)return;
  const bad=[...zone.items.entries()].find(([pid,v])=>!isPending(v)&&!validQty(v,countProduct(pid)?.kind));
  if(bad){C.status='error';countSavedLabel();return countMessage('Проверьте количество: «'+(countProduct(bad[0])?.name||'')+'». Место не сохранено.',true)}
  zone.saving=true;const sending=zone.dirty;
  try{
    const r=await api('/api/inventory/zone',{shop_id:S.shop,id:C.doc.id,rev:zone.rev,zone:{id:zone.id,name:zone.name,done:zone.done,items:[...zone.items.entries()].filter(([,qty])=>!isPending(qty)).map(([product_id,qty])=>({product_id,qty:numberText(qty)}))}});
    const fresh=r.body.zones.find(z=>z.id===zone.id);zone.rev=fresh.rev;zone.by=fresh.by;zone.conflict=false;C.doc.version=r.version;
    if(zone.dirty===sending){zone.dirty=0;if(pendingItems(zone).length)backupZone(zone);else dropBackup(zone)}else backupZone(zone);
    C.status='saved';C.savedAt=new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});
  }catch(e){
    if(e.status===409&&/другом экране/.test(e.message)){zone.conflict=true;if(zone.id===C.zoneId&&C.view==='count')countWork();countPlaces()}
    else if(e.status===409||e.status===400){toast(e.message,true)}
    else{C.status='error';setTimeout(()=>countSave(zone),5000)}
  }finally{zone.saving=false;countSavedLabel();if(zone.again){zone.again=false;if(zone.dirty)countSave(zone)}}
}
async function countFlush(){for(const z of C.zones){clearTimeout(z.timer);if(z.dirty&&!z.conflict)await countSave(z)}
  if(C.zones.some(z=>z.dirty||z.conflict))throw Error('Не все места сохранены. Проверьте связь или конфликт и повторите.')}
async function countRefreshOthers(){
  if(S.page!=='count'||!C.doc||document.hidden)return;
  try{const r=await api('/api/document?'+shopArgs()+'&id='+C.doc.id);if(r.status!=='draft'){clearInterval(C.poll);toast('Пересчёт уже отправлен или отменён на другом экране.');return page()}
    C.doc.version=r.version;let changed=false;
    for(const z of r.body.zones||[]){const mine=C.zones.find(x=>x.id===z.id);
      if(!mine){C.zones.push(zoneFromServer(z));changed=true;continue}
      if(!mine.dirty&&!mine.saving&&mine.rev!==(z.rev||0)){Object.assign(mine,zoneFromServer(z));changed=true}}
    const ids=new Set((r.body.zones||[]).map(z=>z.id));const before=C.zones.length;C.zones=C.zones.filter(z=>ids.has(z.id)||z.dirty);if(C.zones.length!==before)changed=true;
    if(changed){if(!C.zones.some(z=>z.id===C.zoneId))C.zoneId=C.zones[0]?.id||null;countPlaces();if(C.view==='count'&&!C.prompt&&!document.activeElement?.classList?.contains('count-input'))countWork();else if(C.view==='review')countReview()}
  }catch{}
}
async function countAddPlace(name){
  name=String(name||'').trim();if(!name||name.length>80)throw Error('Введите название места (до 80 символов)');
  if(C.zones.some(z=>z.name.toLocaleLowerCase('ru-RU')===name.toLocaleLowerCase('ru-RU')))throw Error('Такое место уже есть');
  const zone={id:crypto.randomUUID(),name,done:false,rev:0,by:'',items:new Map(),dirty:1,sent:0,conflict:false};
  await countSave(zone);
  if(zone.rev===0)throw Error('Место не сохранено. Проверьте связь и повторите.');
  C.zones.push(zone);C.zoneId=zone.id;C.view='count';countLayout();
}
function countReview(){
  C.view='review';const work=$('#countWork');if(!work)return;
  const totals=new Map();for(const z of C.zones)for(const [pid,v] of z.items){const t=totals.get(pid)||{sum:0,where:[]};t.sum=Math.round((t.sum+Number(numberText(v)))*1000)/1000;t.where.push(esc(z.name)+': '+showQty(v));totals.set(pid,t)}
  const open=C.zones.filter(z=>!z.done),need=C.settings?.require_done;
  const filter=fold(C.filter);
  const rows=[...totals.entries()].map(([pid,t])=>({p:countProduct(pid),t})).filter(x=>x.p&&(!filter||fold(x.p.name).includes(filter))).sort((a,b)=>a.p.name.localeCompare(b.p.name,'ru'));
  work.innerHTML=`<div class="count-zone-head"><div><h2>Итог пересчёта</h2><div class="muted small">${C.zones.length} мест · ${totals.size} товаров найдено</div></div></div>
   <div class="count-review-places">${C.zones.map(z=>`<button class="count-review-place ${z.done?'done':''}" data-action="count-place" data-id="${esc(z.id)}"><strong>${z.done?'✓':'○'} ${esc(z.name)}</strong><span class="muted small">${z.items.size} поз.${z.by?' · '+esc(z.by):''}</span></button>`).join('')}</div>
   ${open.length?`<div class="notice ${need?'error':'amber'}">${need?'Перед отправкой отметьте места как посчитанные: ':'Не отмечены как посчитанные: '}<strong>${open.map(z=>esc(z.name)).join(', ')}</strong></div>`:'<div class="notice ok">Все места отмечены как посчитанные.</div>'}
   <div class="notice amber">Проверьте, что пересчитан <strong>весь магазин</strong>: витрины, холодильники, подсобка, кеги. Товары, которые не внесены ни в одно место, будут считаться отсутствующими.</div>
   <div class="toolbar"><input id="countFilter" placeholder="Найти товар в итоге" value="${esc(C.filter)}" aria-label="Фильтр итога"></div>
   ${rows.length?`<div class="tablewrap"><table><thead><tr><th>Товар</th><th class="num">Всего</th><th>Где найдено</th></tr></thead><tbody>${rows.map(({p,t})=>`<tr><td>${esc(p.name)}</td><td class="num"><strong>${showQty(t.sum)}</strong> ${unit(p.kind)}</td><td class="small">${t.where.join(' · ')}</td></tr>`).join('')}</tbody></table></div>`:empty('Пока ничего не посчитано')}
   <div class="count-review-actions">${(manager()||C.doc.author===S.boot.user.id)?btn('Отменить пересчёт','count-cancel','ghost danger-text'):''}${btn('Напечатать итог','count-print','')}${btn('Отправить в МойСклад','count-send','primary',(need&&open.length)||!totals.size?'disabled':'')}</div>`;
  countPlaces();
}
async function countStartDialog(){
  const blocker=S.docs.find(r=>['draft','waiting','submitted'].includes(r.status));if(blocker)return openDoc(blocker.id);
  const settings=await api('/api/inventory/settings?'+shopArgs());const places=settings.places.length?settings.places:['Витрина 1','Витрина 2','Холодильник','Подсобка'];
  modal('Начать пересчёт',`<div class="notice amber">Пока идёт пересчёт, продажи и приходы в этом магазине приостановлены.</div>
   <p>Отметьте места, которые будете считать. Места можно добавить и позже.</p>
   <div class="count-start-places">${places.map((n,i)=>`<label class="checklabel"><input type="checkbox" class="count-start-place" value="${esc(n)}" ${settings.places.length||i<places.length?'checked':''}> ${esc(n)}</label>`).join('')}</div>
   ${field('Ещё место (необязательно)','countStartExtra','','text','maxlength="80" autocomplete="off" placeholder="Например: Кеги"')}`,
   btn('Отмена','close')+btn('Начать пересчёт','count-start','primary'));
}
function countSettingsDialog(){
  api('/api/inventory/settings?'+shopArgs()).then(s=>modal('Настройки пересчёта · '+esc(S.boot.shops.find(x=>x.id===S.shop)?.name||''),
   `<label>Места хранения магазина — по одному на строку, в порядке обхода<textarea id="countSetPlaces" rows="8">${esc(s.places.join('\n'))}</textarea></label>
   <label>Скан штучного товара<select id="countSetMode"><option value="plus" ${s.scan_mode==='plus'?'selected':''}>Каждый скан прибавляет 1 шт.</option><option value="ask" ${s.scan_mode==='ask'?'selected':''}>Спрашивать количество</option></select></label>
   <label class="checklabel"><input type="checkbox" id="countSetDone" ${s.require_done?'checked':''}> Отправлять только когда все места отмечены «посчитано»</label>
   <label class="checklabel"><input type="checkbox" id="countSetLearn" ${s.learn?'checked':''}> Запоминать новые места, которые добавили продавцы</label>
   <p class="muted small">Продавцы никогда не видят учётные остатки и разницу — только то, что сами посчитали.</p>`,
   btn('Отмена','close')+btn('Сохранить','count-settings-save','primary'))).catch(e=>toast(e.message,true));
}
function countPrint(){
  const totals=new Map();for(const z of C.zones)for(const [pid,v] of z.items)totals.set(pid,Math.round(((totals.get(pid)||0)+Number(numberText(v)))*1000)/1000);
  $('#printArea').innerHTML=`<h3>Пересчёт № ${C.doc.id}</h3><p>${esc(S.boot.shops.find(x=>x.id===S.shop)?.name||'')} · ${new Date().toLocaleString('ru-RU')}</p>`+
   C.zones.map(z=>`<h4>${esc(z.name)}${z.done?' ✓':''}</h4><table>${[...z.items.entries()].map(([pid,v])=>`<tr><td>${esc(countProduct(pid)?.name||'')}</td><td>${showQty(v)} ${unit(countProduct(pid)?.kind)}</td></tr>`).join('')}</table>`).join('')+
   `<h4>Итого</h4><table>${[...totals.entries()].map(([pid,v])=>`<tr><td>${esc(countProduct(pid)?.name||'')}</td><td>${showQty(v)} ${unit(countProduct(pid)?.kind)}</td></tr>`).join('')}</table>`;
  print();
}
async function countAction(a,el){
  const zone=countZone(),id=el.dataset.id;
  if(a==='count-sound'){try{localStorage.setItem('beermag:inv:sound',countSound()?'off':'on')}catch{}el.textContent=countSound()?'🔊 Звук':'🔇 Без звука';return}
  if(a==='count-review'){await countFlush().catch(e=>toast(e.message,true));C.view='review';return countLayout()}
  if(a==='count-back'){C.view='count';return countLayout()}
  if(a==='count-place'){C.zoneId=id;C.view='count';C.prompt=null;C.results=[];return countLayout()}
  if(a==='count-place-add'){await countAddPlace($('#countNewPlace').value);return}
  if(a==='count-place-quick')return countAddPlace(el.dataset.name);
  if(a==='count-mode'){try{localStorage.setItem(countModeKey(),el.dataset.mode)}catch{}return countWork()}
  if(a==='count-pick'){if(C.results.length)return countToggle(id);return countPick(id,false)}
  if(a==='count-pick-one'){C.returnQuery={query:$('#countScan')?.value.trim()||'',hit:Math.max(0,C.results.findIndex(p=>p.id===Number(id)))};C.selected.delete(Number(id));return countPick(id,false)}
  if(a==='count-select-all'){const all=C.results.every(p=>C.selected.has(p.id));C.results.forEach(p=>all?C.selected.delete(p.id):C.selected.add(p.id));return countResults()}
  if(a==='count-add-selected')return countAddSelected([...C.selected]);
  if(a==='count-prompt-add')return countPromptApply(false);
  if(a==='count-prompt-set')return countPromptApply(true);
  if(a==='count-prompt-cancel'){C.prompt=null;$('#countPrompt').innerHTML='';return $('#countScan')?.focus()}
  if(a==='count-undo'){const last=C.undo.pop();const z=C.zones.find(x=>x.id===last?.zone);if(!last||!z)return;
    if(z.done)throw Error('Место уже отмечено как посчитанное. Нажмите «Продолжить считать».');
    if(last.before===null)z.items.delete(last.pid);else z.items.set(last.pid,last.before);countQueue(z);countItems();countLast();countPlaces();toast('Последнее действие отменено');return $('#countScan')?.focus()}
  if(!zone)return;
  if(a==='count-plus'||a==='count-minus'){const cur=Number(numberText(zone.items.get(Number(id))||0)),next=Math.max(0,cur+(a==='count-plus'?1:-1));return countSet(zone,Number(id),String(next),a==='count-plus'?'+1':'−1')}
  if(a==='count-remove'){const p=countProduct(id);if(Number(numberText(zone.items.get(Number(id))))>0&&!await ask('Убрать «'+p.name+'» из места «'+zone.name+'»?',{ok:'Убрать',danger:true}))return;return countSet(zone,Number(id),null,'')}
  if(a==='count-place-done'||a==='count-place-reopen'){
    if(a==='count-place-done'&&pendingItems(zone).length){countFocusPending();throw Error('Впишите количество для всех выбранных товаров или уберите лишние ✕')}
    if(a==='count-place-done'&&!zone.items.size&&!await ask('В месте «'+zone.name+'» ничего не найдено. Отметить его как пустое и посчитанное?',{ok:'Отметить пустым'}))return;
    zone.done=a==='count-place-done';countQueue(zone);await countSave(zone);
    if(zone.done){const next=C.zones.find(z=>!z.done);if(next){C.zoneId=next.id;toast('«'+zone.name+'» посчитано. Следующее место: '+next.name)}else{toast('Все места посчитаны. Проверьте итог и отправьте.');C.view='review'}}
    return countLayout()}
  if(a==='count-place-rename'){const entered=await ask('Новое название места:',{title:'Переименовать место',value:zone.name,ok:'Сохранить'});if(entered===null)return;const name=entered.trim();
    if(!name||name.length>80)throw Error('Введите название места (до 80 символов)');
    if(C.zones.some(z=>z!==zone&&z.name.toLocaleLowerCase('ru-RU')===name.toLocaleLowerCase('ru-RU')))throw Error('Такое место уже есть');
    zone.name=name;countQueue(zone);return countLayout()}
  if(a==='count-place-delete'){if(C.zones.length===1)throw Error('Оставьте хотя бы одно место');
    if(zone.items.size&&!await ask('Удалить место «'+zone.name+'» вместе с '+zone.items.size+' посчитанными позициями?',{ok:'Удалить',danger:true}))return;
    clearTimeout(zone.timer);if(zone.dirty)await countSave(zone);
    await api('/api/inventory/zone-delete',{shop_id:S.shop,id:C.doc.id,zone_id:zone.id,rev:zone.rev});dropBackup(zone);
    C.zones=C.zones.filter(z=>z!==zone);C.zoneId=C.zones[0]?.id||null;return countLayout()}
  if(a==='count-conflict-load'){if(!await ask('Загрузить место с сервера? Числа, внесённые в этом окне для «'+zone.name+'», пропадут.'))return;zone.dirty=0;dropBackup(zone);const r=await api('/api/document?'+shopArgs()+'&id='+C.doc.id);
    const fresh=r.body.zones.find(z=>z.id===zone.id);if(fresh)Object.assign(zone,zoneFromServer(fresh));else C.zones=C.zones.filter(z=>z!==zone);return countLayout()}
  if(a==='count-conflict-keep'){const r=await api('/api/document?'+shopArgs()+'&id='+C.doc.id);const fresh=r.body.zones.find(z=>z.id===zone.id);zone.rev=fresh?.rev||0;zone.conflict=false;await countSave(zone,true);return countLayout()}
}
async function countTopAction(a,el){
  if(a==='count-start'){const names=$$('.count-start-place').filter(x=>x.checked).map(x=>x.value);const extra=$('#countStartExtra')?.value.trim();if(extra)names.push(extra);
    if(!names.length)throw Error('Отметьте хотя бы одно место');
    const r=await api('/api/inventory/start',{shop_id:S.shop,zones:[...new Set(names)]});close();return openCount(r.id)}
  if(a==='count-settings')return countSettingsDialog();
  if(a==='count-settings-save'){const places=$('#countSetPlaces').value.split('\n').map(x=>x.trim()).filter(Boolean);
    await api('/api/inventory/settings',{shop_id:S.shop,places,scan_mode:$('#countSetMode').value,require_done:$('#countSetDone').checked,learn:$('#countSetLearn').checked});close();toast('Настройки пересчёта сохранены');return}
  if(a==='count-print')return countPrint();
  if(a==='count-send'){await countFlush();
    if(!await ask('Отправить пересчёт в МойСклад? Вы обошли все места магазина? Не внесённые товары будут считаться отсутствующими.'))return;
    const current=await api('/api/document?'+shopArgs()+'&id='+C.doc.id);
    const sent=await api('/api/inventory/send',{shop_id:S.shop,id:C.doc.id,version:current.version});
    C.zones.forEach(dropBackup);clearInterval(C.poll);S.page='inventory';await render();
    toast(sent.status==='waiting'?'Нет связи с МоимСкладом. Пересчёт сохранён и отправится сам, как только связь появится. Продажи можно продолжать.':S.boot.moysklad?'Пересчёт отправлен в МойСклад. Расхождения проверит управляющий.':'Пересчёт завершён');return}
  if(a==='count-cancel-list'){
    if(!await ask('Отменить пересчёт № '+el.dataset.id+'? Все посчитанные в нём числа будут удалены, продажи снова станут доступны.',{ok:'Отменить пересчёт',cancel:'Назад',danger:true}))return;
    const current=await api('/api/document?'+shopArgs()+'&id='+el.dataset.id);
    await api('/api/inventory/cancel',{shop_id:S.shop,id:current.id,version:current.version});
    try{for(const k of Object.keys(localStorage))if(k.includes(':'+current.id+':')&&k.startsWith('beermag:inv:'))localStorage.removeItem(k)}catch{}
    await page();toast('Пересчёт отменён');return}
  if(a==='count-cancel'){if(!await ask('Отменить пересчёт? Все посчитанные числа будут удалены.',{ok:'Отменить пересчёт',cancel:'Назад',danger:true}))return;
    const current=await api('/api/document?'+shopArgs()+'&id='+C.doc.id);await api('/api/inventory/cancel',{shop_id:S.shop,id:C.doc.id,version:current.version});
    C.zones.forEach(dropBackup);clearInterval(C.poll);S.page='inventory';await render();toast('Пересчёт отменён');return}
  return countAction(a,el);
}
document.addEventListener('keydown',e=>{
  if(S.page!=='count')return;
  if(e.target.id==='countScan'){
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){if(!C.results.length)return;e.preventDefault();const n=C.results.length,down=e.key==='ArrowDown';C.moved=true;C.hit=C.hit<0?(down?0:n-1):(C.hit+(down?1:-1)+n)%n;return countResults()}
    if(e.key===' '&&C.moved&&C.results.length){e.preventDefault();return countToggle(C.results[C.hit].id)}
    if(e.key==='Escape'){e.target.value='';C.results=[];C.returnQuery=null;countResults();return}
    if(e.key==='Enter'&&!e.isComposing){e.preventDefault();try{countScanEnter()}catch(x){toast(x.message,true)}return}
  }
  if(e.target.id==='countPromptQty'){if(e.key==='Enter'){e.preventDefault();countPromptApply(false)}if(e.key==='Escape'){e.preventDefault();C.prompt=null;$('#countPrompt').innerHTML='';$('#countScan')?.focus()}return}
  if(e.target.id==='countNewPlace'&&e.key==='Enter'){e.preventDefault();countAddPlace(e.target.value).catch(x=>toast(x.message,true));return}
  if(e.target.classList?.contains('count-input')&&e.key==='Enter'){e.preventDefault();e.target.blur();countFocusPending()}
});
document.addEventListener('input',e=>{
  if(S.page!=='count')return;
  if(e.target.id==='countScan'){const v=e.target.value.trim();C.moved=false;C.lastQuery=null;C.results=/^\d{8,}$/.test(v)?[]:countSearch(v);C.hit=0;C.live=C.results.length?v:null;countResults()}
  if(e.target.classList?.contains('count-input')&&countProduct(e.target.dataset.id)?.kind==='weight')weightTyping(e.target);
  if(e.target.id==='countPromptQty'&&countProduct(C.prompt?.pid)?.kind==='weight')weightTyping(e.target);
  if(e.target.id==='countFilter'){C.filter=e.target.value;const pos=e.target.selectionStart;countReview();const f=$('#countFilter');f?.focus();f?.setSelectionRange?.(pos,pos)}
});
document.addEventListener('change',e=>{
  if(S.page!=='count')return;
  if(e.target.classList?.contains('count-input')){const zone=countZone(),pid=Number(e.target.dataset.id),p=countProduct(pid);
    if(looksLikeBarcode(e.target.value)){beep(false);toast('Это штрихкод, а не количество. Сначала введите количество для «'+(p?.name||'товара')+'», потом сканируйте следующий.',true);e.target.value=showQty(zone.items.get(pid));return}
    const v=qtyText(e.target.value);
    if(!validQty(v,p?.kind)){beep(false);toast(p?.kind==='piece'||p?.kind==='packaging'?'Введите целое число штук':'Введите число, например 1,25',true);e.target.value=showQty(zone.items.get(pid));return}
    countSet(zone,pid,v,'=')}
});
window.addEventListener('beforeunload',e=>{if(S.page==='count'&&C.zones.some(z=>z.dirty)){e.preventDefault();e.returnValue=''}});

document.addEventListener('dblclick',e=>{
  if(S.page!=='count')return;const row=e.target.closest?.('.count-result');if(!row)return;
  e.preventDefault();C.selected.delete(Number(row.dataset.id));countAction('count-pick-one',row).catch(x=>toast(x.message,true));
});

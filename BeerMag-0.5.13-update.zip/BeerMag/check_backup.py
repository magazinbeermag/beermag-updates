"""Read-only validation and identification of a BeerMag recovery copy."""
import argparse
import sqlite3
from contextlib import closing
from pathlib import Path

REQUIRED = {'users', 'shops', 'documents', 'shifts', 'ms_options', 'ms_outbox'}


def inspect(path):
    path = Path(path).resolve(strict=True)
    if not path.is_file():
        raise ValueError('Укажите файл резервной копии .sqlite3.')
    # Backups are standalone SQLite snapshots; no journal should be written beside one.
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
        db.row_factory = sqlite3.Row
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('Нарушена целостность базы.')
        tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED.issubset(tables):
            raise ValueError('Это не полная резервная копия BeerMag.')
        opts = dict(db.execute("SELECT key,value FROM ms_options WHERE key IN ('register_id','register_retail_id')"))
        return {
            'register': opts.get('register_id', 'не присвоен'),
            'retail_point': opts.get('register_retail_id', 'не закреплена'),
            'documents': db.execute('SELECT COUNT(*) FROM documents').fetchone()[0],
            'unsent': db.execute("SELECT COUNT(*) FROM ms_outbox WHERE status NOT IN ('sent','skipped')").fetchone()[0],
        }


def main():
    parser = argparse.ArgumentParser(description='Проверить копию BeerMag перед восстановлением')
    parser.add_argument('file', help='Путь к файлу .sqlite3')
    args = parser.parse_args()
    try:
        result = inspect(args.file)
    except (OSError, sqlite3.Error, ValueError) as error:
        parser.exit(1, 'Копия не прошла проверку: ' + str(error) + '\n')
    print('Копия целая. Код кассы: {register}; точка МойСклад: {retail_point}; '
          'документов: {documents}; неотправленных операций: {unsent}.'.format(**result))
    print('Восстанавливайте только на место этой кассы после остановки старой установки.')


if __name__ == '__main__':
    main()

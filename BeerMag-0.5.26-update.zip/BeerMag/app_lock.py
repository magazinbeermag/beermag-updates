"""Prevent two cash register processes, or an update and a running register."""
from contextlib import contextmanager


@contextmanager
def exclusive(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as handle:
        handle.seek(0,2)
        if handle.tell()==0:   # 0.5.16: байт пишется один раз (файл больше не растёт), полный диск — понятная ошибка
            try:handle.write(b'0');handle.flush()
            except OSError:raise RuntimeError('На диске кассы закончилось место. Освободите место на диске и запустите кассу снова.') from None
        handle.seek(0)
        try:
            if __import__('os').name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise RuntimeError('Закройте работающее окно BeerMag перед обновлением или повторным запуском.') from None
        try:
            yield
        finally:
            if __import__('os').name == 'nt':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

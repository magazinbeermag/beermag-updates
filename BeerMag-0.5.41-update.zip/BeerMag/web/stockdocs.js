// 0.5.27: приход и списание товара через кассу. Поставщики, товары и цены — из МоегоСклада, остатки не показываются.
// Документ проводится сразу и уходит в МойСклад через очередь магазина; исправляет управляющий в МоемСкладе.
const SD={kind:null,form:null,refs:null,list:[],hit:-1};
const SD_TITLE={supply:['Приход товара','Новый приход','приход'],writeoff:['Списание товара','Новое списание','списание']};
const stockReady=()=>['supply','writeoff'].includes(S.page)&&!!SD.form&&!$('#modal')?.open&&!$('#ask')?.open;
const sdKey=()=>S.boot?`beermag:stockdoc:v1:${S.demo?'demo':'live'}:${S.boot.user.id}:${S.shop}:${SD.kind}`:null;
const sdNum=v=>Number(String(v??'').trim().replace(/\s/g,'').replace(',','.'));
const sdProduct=id=>S.boot.products.find(p=>p.id===Number(id));
function sdSave(){const key=sdKey();if(key&&SD.form)cartStore('set',key,JSON.stringify(SD.form))}
function sdDrop(){const key=sdKey();if(key)cartStore('remove',key);SD.form=null}
function sdToday(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
async function sdRefs(refresh=false){
 try{SD.refs=await api('/api/stockdocs/refs?'+shopArgs()+(refresh?'&refresh=1':''))}catch(e){SD.refs=SD.refs||{counterparties:[],buy_prices:{}};if(refresh)toast(e.message,true)}
 if(refresh&&SD.refs.error)toast('Список из МоегоСклада не обновлён: '+SD.refs.error+' Используется сохранённый список.',true);
 return SD.refs;
}
async function stockDocs(kind){
 if(SD.form&&(SD.form.kind!==kind||SD.form.shop!==S.shop))SD.form=null;
 SD.kind=kind;
 if(!SD.form){try{const saved=JSON.parse(cartStore('get',sdKey())||'null');if(saved&&Array.isArray(saved.lines))SD.form={...saved,kind,shop:S.shop}}catch{}}
 if(SD.form)return sdForm();
 SD.list=await api('/api/documents?'+shopArgs()+'&type='+kind);const [title,create]=SD_TITLE[kind];
 const what=x=>kind==='supply'?`${esc(x.body.counterparty||'—')}<div class="muted small">накладная № ${esc(x.body.number||'')} от ${esc((x.body.date||'').split('-').reverse().join('.'))}</div>`:esc(x.body.note||'—');
 $('#content').innerHTML=heading(title,kind==='supply'?'Поставщики, товары и цены — из МоегоСклада. После «Провести» приход уходит в МойСклад.':'Списание считается по цене продажи и уходит в МойСклад после «Провести».',btn(create,'sd-new','primary'))+
  (SD.list.length?`<div class="panel tablewrap compact-table"><table><thead><tr><th>№</th><th>Когда</th><th>${kind==='supply'?'Поставщик':'Причина'}</th><th class="num">Строк</th><th class="num">Сумма</th>${kind==='supply'?'<th class="num">По продаже</th>':''}<th>Кто</th><th>Передача</th></tr></thead><tbody>${SD.list.map(x=>`<tr class="clickable" data-action="sd-open" data-id="${x.id}" tabindex="0"><td>${x.id}</td><td>${shortDate(x.created)}</td><td>${what(x)}</td><td class="num">${x.body.lines.length}</td><td class="num">${money(x.body.total)}</td>${kind==='supply'?`<td class="num">${money(sdSaleSum(x))}</td>`:''}<td>${esc(x.author_name||'')}</td><td>${x.sync_status?syncLabel(x.sync_status):'Локально'}</td></tr>`).join('')}</tbody></table></div>`:empty(kind==='supply'?'Приходов пока нет':'Списаний пока нет'));
 $('#content [data-action="sd-new"]')?.focus?.();
}
async function sdNew(){
 SD.form={kind:SD.kind,shop:S.shop,counterparty_id:'',number:'',date:sdToday(),note:'',lines:[],key:null};sdSave();
 if(SD.kind==='supply')await sdRefs(true);return sdForm();
}
async function sdForm(){
 const f=SD.form,supply=SD.kind==='supply';if(supply&&!SD.refs)await sdRefs(false);
 const agents=SD.refs?.counterparties||[];
 const head=supply?`<div class="grid sd-head"><label>Поставщик<select id="sdAgent"><option value="">— выберите —</option>${agents.map(x=>`<option value="${esc(x.id)}" ${x.id===f.counterparty_id?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><label>Номер накладной<input id="sdNumber" value="${esc(f.number)}" maxlength="60" autocomplete="off"></label><label>Дата накладной<input id="sdDate" type="date" value="${esc(f.date)}"></label><label>Комментарий<input id="sdNote" value="${esc(f.note)}" maxlength="250" autocomplete="off" placeholder="необязательно"></label></div><p class="muted small">${btn('↻ Обновить поставщиков и цены из МоегоСклада','sd-refs','small')}</p>`:
  `<div class="grid sd-head"><label>Причина списания (обязательно)<input id="sdNote" value="${esc(f.note)}" maxlength="250" autocomplete="off" placeholder="например: бой, пролив, просрочка"></label></div>`;
 $('#content').innerHTML=heading(SD_TITLE[SD.kind][1],(supply?'Сканируйте товар или найдите по названию, укажите цену из накладной (с НДС) и количество. Наценка ниже 56% — красным, это только подсказка: приход проводится.':'Сканируйте товар или найдите по названию и укажите количество. Цена — цена продажи.')+' F4 — поиск товара, F9 — провести.',btn('Отмена','sd-cancel','small')+btn('Провести (F9)','sd-send','primary'))+
  `<div class="panel">${head}<div class="toolbar sd-search"><label for="sdSearch">Товар</label><input id="sdSearch" placeholder="Штрихкод или название · Enter — добавить" aria-label="Поиск товара" autocomplete="off"></div><div id="sdResults" class="sd-results"></div></div>`+
  `<div class="panel tablewrap"><table class="sd-lines"><thead><tr>${supply?
   '<th>Товар</th><th>Ед.</th><th class="num">Цена закупки, ₽</th><th class="num">Цена продажи</th><th class="num">Наценка</th><th class="num">Кол-во</th><th>% НДС</th><th class="num">НДС</th><th class="num">Сумма покупки</th><th class="num">Сумма продажи</th><th></th>':
   '<th>Товар</th><th>Ед.</th><th class="num">Кол-во</th><th class="num">Цена продажи</th><th class="num">Сумма</th><th></th>'}</tr></thead><tbody id="sdLines"></tbody></table>${supply?'<div id="sdSums" class="sd-sums"></div>':'<div id="sdTotal" class="shift-line shift-total"></div>'}</div>`;   // 0.5.32: в приходе «Итого» не дублирует «Всего по закупке»
 sdLines();const first=supply&&!f.counterparty_id?$('#sdAgent'):supply&&!f.number?$('#sdNumber'):!supply&&!f.note?$('#sdNote'):$('#sdSearch');first?.focus?.();
}
// 0.5.29: приход как в прежней программе магазинов — цена закупки, цена продажи, наценка (ниже 56% — красным), суммы покупки и продажи.
const SD_MARKUP_MIN=56;
// 0.5.30: ставка НДС строки (цена накладной — уже с НДС); «Без НДС» — по умолчанию.
const SD_VAT=[['','Без НДС'],['0','0%'],['5','5%'],['7','7%'],['10','10%'],['20','20%'],['22','22%']];
const sdVatSum=(total,vat)=>vat===''||vat==null||total==null?0:Math.round(total*Number(vat)/(100+Number(vat)));
function sdLines(){
 const body=$('#sdLines');if(!body)return;const supply=SD.kind==='supply';
 const qtyCell=(x,i)=>`<td class="num"><input class="sd-qty" data-i="${i}" value="${esc(x.qty)}" inputmode="decimal" autocomplete="off" aria-label="Количество"></td>`;
 body.innerHTML=SD.form.lines.length?SD.form.lines.map((x,i)=>{const p=sdProduct(x.product_id);const name=`<td>${esc(p?.name||'Товар не найден')}</td><td>${esc(unit(p?.kind)||'')}</td>`,del=`<td>${btn('✕','sd-remove','small ghost',`data-i="${i}" aria-label="Убрать строку"`)}</td>`;
  return supply?`<tr>${name}<td class="num"><input class="sd-price" data-i="${i}" value="${esc(x.price)}" inputmode="decimal" autocomplete="off" aria-label="Цена закупки"></td><td class="num">${money(p?.price)}</td><td class="num sd-markup" id="sdMk${i}"></td>${qtyCell(x,i)}<td><select class="sd-vat" data-i="${i}" aria-label="Ставка НДС">${SD_VAT.map(([v,t])=>`<option value="${v}" ${String(x.vat??'')===v?'selected':''}>${t}</option>`).join('')}</select></td><td class="num" id="sdVat${i}"></td><td class="num" id="sdSum${i}"></td><td class="num" id="sdSale${i}"></td>${del}</tr>`:
   `<tr>${name}${qtyCell(x,i)}<td class="num">${money(p?.price)}</td><td class="num" id="sdSum${i}"></td>${del}</tr>`}).join(''):`<tr><td colspan="${supply?11:6}" class="muted">Товаров пока нет. Отсканируйте первый товар.</td></tr>`;
 sdTotals();
}
// Наценка к цене закупки, %: (продажа − закупка) / закупка × 100. Без цены закупки — не считается.
function sdMarkup(x){const p=sdProduct(x.product_id),buy=sdNum(x.price);if(!p||String(x.price??'').trim()===''||!Number.isFinite(buy)||buy<=0)return null;return Math.round((p.price/100-buy)/buy*10000)/100}   // 0.5.40: красное — по тому же числу, что видно на экране (55,996 → 56,00 % — не красное)
function sdLineTotal(x){const p=sdProduct(x.product_id),q=sdNum(x.qty),price=SD.kind==='supply'?(String(x.price??'').trim()===''?NaN:Math.round(sdNum(x.price)*100)):p?.price;return Number.isFinite(q)&&Number.isFinite(price)&&q>0&&price>=0?lineSum(price,q):null}
const sdRows=n=>n+' '+(n%10===1&&n%100!==11?'строка':n%10>=2&&n%10<=4&&(n%100<10||n%100>=20)?'строки':'строк');
function sdTotals(){let total=0,bad=false,sale=0,vat=0;SD.form.lines.forEach((x,i)=>{const t=sdLineTotal(x);const cell=$('#sdSum'+i);if(cell)cell.textContent=t==null?'—':money(t);if(t==null)bad=true;else total+=t;
  if(SD.kind==='supply'){const v=sdVatSum(t,x.vat??'');vat+=v;const vc=$('#sdVat'+i);if(vc)vc.textContent=x.vat==null||x.vat===''?'—':money(v)}
  if(SD.kind==='supply'){const p=sdProduct(x.product_id),q=sdNum(x.qty),s=p&&Number.isFinite(q)&&q>0?lineSum(p.price,q):null;if(s!=null)sale+=s;const c=$('#sdSale'+i);if(c)c.textContent=s==null?'—':money(s);
   const m=sdMarkup(x),mk=$('#sdMk'+i);if(mk){mk.textContent=m==null?'—':m.toFixed(2).replace('.',',')+' %';mk.className='num sd-markup'+(m==null?'':m<SD_MARKUP_MIN?' low':' ok')}}});
 const sums=$('#sdSums');if(sums)sums.innerHTML=`<span>Всего по закупке: <strong>${bad?'—':money(total)}</strong></span><span>НДС: <strong>${money(vat)}</strong></span><span>по продаже: <strong>${money(sale)}</strong></span>`;
 const box=$('#sdTotal');if(box)box.innerHTML=`<strong>Итого · ${sdRows(SD.form.lines.length)}</strong><strong>${bad?'проверьте количество и цены':money(total)}</strong>`;return bad?null:total}
function sdMatches(value){
 const v=String(value||'').trim();if(!v)return [];
 const list=S.boot.products.filter(p=>p.active&&(!S.boot.moysklad||p.source_uuid));
 const scanned=list.filter(p=>p.barcode===v||(p.barcodes||[]).includes(v));if(scanned.length)return scanned;
 const words=fold(v).split(/\s+/);return list.filter(p=>words.every(w=>hayOf(p).includes(w))).slice(0,30);   // 0.5.41: готовая строка поиска (hayOf)
}
// 0.5.28: найденные товары — списком; ↓/↑ выбирают строку, Enter добавляет выбранный, Esc снимает выбор.
// Курсор остаётся в поиске, поэтому сканер работает как обычно.
function sdShowResults(value){
 const box=$('#sdResults');if(!box)return;const found=String(value||'').trim()?sdMatches(value):[];SD.hit=-1;
 box.innerHTML=found.map(p=>btn(`${esc(p.name)}<span class="muted small">${esc(unit(p.kind)||'')}</span>`,'sd-add','small',`data-id="${p.id}" tabindex="-1"`)).join('');
}
const sdHits=()=>[...$$('#sdResults button[data-action="sd-add"]')];
function sdMark(i){const list=sdHits();SD.hit=list.length?Math.max(0,Math.min(list.length-1,i)):-1;list.forEach((b,n)=>b.classList.toggle('hit',n===SD.hit));list[SD.hit]?.scrollIntoView?.({block:'nearest'})}
function sdAdd(id){
 const p=sdProduct(id);if(!p)return;const f=SD.form;let i=f.lines.findIndex(x=>x.product_id===p.id);
 if(i>=0){const q=sdNum(f.lines[i].qty);if(p.kind==='piece'||p.kind==='packaging')f.lines[i].qty=String((Number.isFinite(q)?q:0)+1)}
 else{const last=SD.refs?.buy_prices?.[String(p.id)];f.lines.push({product_id:p.id,qty:p.kind==='piece'||p.kind==='packaging'?'1':'',price:SD.kind==='supply'&&last!=null?(last/100).toFixed(2):'',...(SD.kind==='supply'?{vat:f.vat||''}:{})});i=f.lines.length-1}
 sdSave();const search=$('#sdSearch');if(search)search.value='';const box=$('#sdResults');if(box)box.innerHTML='';sdLines();
 // Приход: сначала цена закупки (как в накладной), потом количество; списание — сразу количество.
 const q=$(`.${SD.kind==='supply'?'sd-price':'sd-qty'}[data-i="${i}"]`);q?.focus?.();q?.select?.();
}
function sdFind(value){
 const found=sdMatches(value);
 if(found.length===1)return sdAdd(found[0].id);
 sdShowResults(value);if(found.length)sdMark(0);toast(found.length?'Найдено несколько товаров — выберите стрелками ↓ ↑ и нажмите Enter.':/^\d{6,}$/.test(String(value).trim())?'Штрихкод '+String(value).trim()+' не найден в каталоге. Обновите каталог или найдите товар по названию.':'Товар не найден.',!found.length);
}
function stockScan(code,target){
 if(target?.id==='sdDate'&&SD.dateBefore!=null){target.value=SD.dateBefore;if(SD.form){SD.form.date=SD.dateBefore;sdSave()}}   // 0.5.40: скан в поле даты не меняет дату накладной
 if(target&&textField(target)&&target.id!=='sdSearch'&&typeof target.value==='string'&&target.value.endsWith(code)){target.value=target.value.slice(0,-code.length);target.dispatchEvent?.(new Event('input',{bubbles:true}))}
 const search=$('#sdSearch');if(search)search.value='';sdFind(code);
}
function sdBody(confirmDuplicate=false){
 const f=SD.form,supply=SD.kind==='supply';
 if(supply){if(!f.counterparty_id)throw Error('Выберите поставщика.');if(!f.number.trim())throw Error('Укажите номер накладной.');if(!f.date)throw Error('Укажите дату накладной.');const y=Number(f.date.slice(0,4)),now=new Date().getFullYear();if(!(y>=now-1&&y<=now+1)){$('#sdDate')?.focus?.();throw Error('Проверьте дату накладной: '+f.date.split('-').reverse().join('.'))}}
 else if(!f.note.trim())throw Error('Напишите причину списания.');
 if(!f.lines.length)throw Error('Добавьте товары.');
 const stop=(i,field,text)=>{const el=$(`.${field}[data-i="${i}"]`);el?.focus?.();el?.select?.();throw Error(text)};   // курсор — в поле с ошибкой
 f.lines.forEach((x,i)=>{const p=sdProduct(x.product_id);const q=sdNum(x.qty);if(!p)throw Error('Товар не найден в каталоге. Уберите строку.');
  if(!Number.isFinite(q)||q<=0)stop(i,'sd-qty','Укажите количество: '+p.name);if((p.kind==='piece'||p.kind==='packaging')&&!Number.isInteger(q))stop(i,'sd-qty','Штучный товар — целое количество: '+p.name);
  if(supply&&(!Number.isFinite(sdNum(x.price))||sdNum(x.price)<0||String(x.price).trim()===''))stop(i,'sd-price','Укажите цену закупки: '+p.name);
  if(supply&&/[.,]\d{3,}/.test(String(x.price)))stop(i,'sd-price','Цена — в рублях и копейках, не больше двух знаков после запятой: '+p.name)});   // 0.5.40
 const body={shop_id:S.shop,kind:SD.kind,note:f.note.trim(),lines:f.lines.map(x=>({product_id:x.product_id,qty:String(sdNum(x.qty)),...(supply?{price:String(sdNum(x.price)),vat:x.vat===''||x.vat==null?null:Number(x.vat)}:{})}))};
 if(supply)Object.assign(body,{counterparty_id:f.counterparty_id,number:f.number.trim(),date:f.date});
 if(confirmDuplicate)body.confirm_duplicate=true;
 return body;
}
async function sdSend(confirmDuplicate=false){
 const body=sdBody(confirmDuplicate),total=sdTotals(),supply=SD.kind==='supply';
 if(total==null)throw Error('Проверьте количество и цены.');
 if(!confirmDuplicate&&!await ask(`Провести ${SD_TITLE[SD.kind][2]} на ${money(total)} (${sdRows(body.lines.length)})? После проведения исправить его можно только в МоемСкладе.`,{title:supply?'Провести приход?':'Провести списание?',ok:'Провести'}))return;
 // Ключ хранится с черновиком: если ответ потерялся, повтор не создаст второй документ.
 if(!SD.form.key||SD.form.keyFor!==JSON.stringify(body)){SD.form.key=crypto.randomUUID();SD.form.keyFor=JSON.stringify(body);sdSave()}
 let r;
 try{r=await api('/api/stockdocs/send',body,SD.form.key)}
 catch(e){
  if(supply&&!confirmDuplicate&&/уже проведена/.test(e.message)){if(await ask(e.message,{title:'Такая накладная уже есть',ok:'Это другая накладная — провести',cancel:'Не проводить',danger:true}))return sdSend(true);return}
  throw e;
 }
 sdDrop();toast(r.duplicate?'Документ уже был проведён раньше. Повторно не создан.':(supply?'Приход':'Списание')+' № '+r.id+' проведено'+(S.boot.moysklad?' и отправляется в МойСклад.':'.'));
 return stockDocs(SD.kind);
}
// 0.5.35: в приходе — и цена продажи: из накладной (с 0.5.35), для старых приходов — текущая цена из каталога.
const sdSaleOf=x=>x.sale_price??sdProduct(x.product_id)?.price??0;
const sdSaleTotal=x=>x.sale_total??lineSum(sdSaleOf(x),x.qty/1000);
const sdSaleSum=r=>r.body.lines.reduce((a,x)=>a+sdSaleTotal(x),0);
function sdView(r){
 const supply=r.type==='supply',lines=r.body.lines;
 if(supply){const sale=sdSaleSum(r);
  return modal('Приход № '+r.id,`<p class="muted small">${date(r.created)} · ${esc(r.author_name||'')}${r.sync_status?' · '+syncLabel(r.sync_status):''}</p>`+
   `<p><strong>${esc(r.body.counterparty||'')}</strong> · накладная № ${esc(r.body.number||'')} от ${esc((r.body.date||'').split('-').reverse().join('.'))}${r.body.note?' · '+esc(r.body.note):''}</p>`+
   `<div class="tablewrap"><table class="sd-lines"><thead><tr><th>Товар</th><th class="num">Кол-во</th><th class="num">Цена закупки</th><th class="num">Сумма закупки</th><th class="num">Цена продажи</th><th class="num">Сумма продажи</th></tr></thead><tbody>${lines.map(x=>`<tr><td>${esc(x.name)}</td><td class="num">${qty(x.qty)} ${esc(unit(x.kind)||'')}</td><td class="num">${money(x.price)}</td><td class="num">${money(x.total)}</td><td class="num">${money(sdSaleOf(x))}</td><td class="num">${money(sdSaleTotal(x))}</td></tr>`).join('')}</tbody></table></div>`+
   `<div class="sd-sums"><span>Итого по закупке: <strong>${money(r.body.total)}</strong></span><span>по продаже: <strong>${money(sale)}</strong></span></div>${lines.some(x=>x.sale_price==null)?'<p class="muted small">Цена продажи — текущая из каталога (приход оформлен до версии 0.5.35).</p>':''}<p class="muted small">Исправить проведённый документ можно только в МоемСкладе.</p>`,btn('Закрыть','close','primary'))}
 modal((supply?'Приход':'Списание')+' № '+r.id,`<p class="muted small">${date(r.created)} · ${esc(r.author_name||'')}${r.sync_status?' · '+syncLabel(r.sync_status):''}</p>`+
  (supply?`<p><strong>${esc(r.body.counterparty||'')}</strong> · накладная № ${esc(r.body.number||'')} от ${esc((r.body.date||'').split('-').reverse().join('.'))}${r.body.note?' · '+esc(r.body.note):''}</p>`:`<p><strong>Причина:</strong> ${esc(r.body.note||'')}</p>`)+
  `<div class="tablewrap"><table><thead><tr><th>Товар</th><th class="num">Количество</th><th class="num">Цена</th><th class="num">Сумма</th></tr></thead><tbody>${lines.map(x=>`<tr><td>${esc(x.name)}</td><td class="num">${qty(x.qty)} ${esc(unit(x.kind)||'')}</td><td class="num">${money(x.price)}</td><td class="num">${money(x.total)}</td></tr>`).join('')}</tbody></table></div><div class="shift-line shift-total"><strong>Итого</strong><strong>${money(r.body.total)}</strong></div><p class="muted small">Исправить проведённый документ можно только в МоемСкладе.</p>`,btn('Закрыть','close','primary'));
}
async function stockAction(a,el){
 if(a==='sd-new')return sdNew();
 if(a==='sd-refs'){await sdRefs(true);if(SD.refs&&!SD.refs.error)toast('Поставщики и цены обновлены.');return sdForm()}
 if(a==='sd-add')return sdAdd(el.dataset.id);
 if(a==='sd-remove'){SD.form.lines.splice(Number(el.dataset.i),1);sdSave();sdLines();return $('#sdSearch')?.focus?.()}
 if(a==='sd-send')return sdSend();
 if(a==='sd-cancel'){if(SD.form.lines.length&&!await ask('Отменить документ? Добавленные товары не сохранятся.',{ok:'Отменить документ',cancel:'Продолжить',danger:true}))return;sdDrop();return stockDocs(SD.kind)}
 if(a==='sd-open'){const r=await api('/api/document?'+shopArgs()+'&id='+el.dataset.id);return sdView(r)}
}
document.addEventListener('input',e=>{
 if(!SD.form||!['supply','writeoff'].includes(S.page))return;const t=e.target,i=Number(t.dataset?.i);
 if(t.classList?.contains('sd-qty')&&SD.form.lines[i]){SD.form.lines[i].qty=t.value;sdSave();sdTotals()}
 else if(t.classList?.contains('sd-price')&&SD.form.lines[i]){SD.form.lines[i].price=t.value;sdSave();sdTotals()}
 else if(t.id==='sdNumber'){SD.form.number=t.value;sdSave()}
 else if(t.id==='sdNote'){SD.form.note=t.value;sdSave()}
 else if(t.id==='sdSearch')sdShowResults(t.value);
});
document.addEventListener('focusin',e=>{if(e.target?.id==='sdDate')SD.dateBefore=e.target.value});   // 0.5.40: дата до возможного скана
document.addEventListener('change',e=>{
 if(!SD.form)return;
 if(e.target.id==='sdAgent'){SD.form.counterparty_id=e.target.value;sdSave()}
 if(e.target.id==='sdDate'){SD.form.date=e.target.value;sdSave()}
 // НДС строки; следующие строки этой накладной получают ту же ставку.
 if(e.target.classList?.contains('sd-vat')){const i=Number(e.target.dataset.i);if(SD.form.lines[i]){SD.form.lines[i].vat=e.target.value;SD.form.vat=e.target.value;sdSave();sdTotals()}}
});
// Без мыши: Enter в поиске добавляет товар, в количестве — переходит к цене (приход) или обратно к поиску.
document.addEventListener('keydown',e=>{
 if(e.key!=='Enter'||e.__blocked||e.repeat||!stockReady())return;const t=e.target;
 if(t.id==='sdSearch'){e.preventDefault();const pick=sdHits()[SD.hit];if(pick)return sdAdd(pick.dataset.id);if(t.value.trim())sdFind(t.value);return}
 if(t.classList?.contains('sd-price')){e.preventDefault();const q=$(`.sd-qty[data-i="${t.dataset.i}"]`);q?.focus?.();q?.select?.();return}
 if(t.classList?.contains('sd-qty')){e.preventDefault();$('#sdSearch')?.focus?.();return}
 const order=SD.kind==='supply'?['sdAgent','sdNumber','sdDate','sdNote','sdSearch']:['sdNote','sdSearch'];const at=order.indexOf(t.id);
 if(at>=0){e.preventDefault();$('#'+order[at+1])?.focus?.()}
});
document.addEventListener('keydown',e=>{
 if(e.target?.id!=='sdSearch'||!stockReady()||e.ctrlKey||e.altKey||e.metaKey)return;
 if(e.key==='ArrowDown'||e.key==='ArrowUp'){const list=sdHits();if(!list.length)return;e.preventDefault();
  sdMark(SD.hit<0?(e.key==='ArrowDown'?0:list.length-1):SD.hit+(e.key==='ArrowDown'?1:-1));return}
 if(e.key==='Escape'&&SD.hit>=0){e.preventDefault();sdMark(-1);sdHits().forEach(b=>b.classList.remove('hit'));SD.hit=-1}
});
// F4 — к поиску товара, F9 — провести (браузерные F-клавиши касса и так глушит).
document.addEventListener('keydown',e=>{
 if(!['F4','F9'].includes(e.key)||e.ctrlKey||e.altKey||e.metaKey||e.repeat||!stockReady()||S.busy)return;e.preventDefault();
 if(e.key==='F4'){const i=$('#sdSearch');i?.focus?.();i?.select?.();return}
 $('#content [data-action="sd-send"]')?.click();
});

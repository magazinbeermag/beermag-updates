"""БирМаг — приложение кассы для Windows.

Запускается без чёрного окна (runtime\\pythonw.exe beermag_app.py):
  • значок у часов с меню (открыть кассу, состояние, перезапуск, выход);
  • сервер кассы работает в фоне и сам перезапускается после сбоя;
  • код 42 от сервера — «установить обновление и перезапустить»;
  • окно кассы открывается отдельным окном-приложением (Edge/Chrome --app);
  • второй запуск не создаёт вторую кассу, а просто показывает окно.
"""
import hashlib, json, os, secrets, shutil, subprocess, sys, threading, time, urllib.request, webbrowser
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
LOGS=DATA/'logs'
PORT=int(os.environ.get('BEERMAG_PORT','8765'))
URL='http://127.0.0.1:%d/'%PORT
TITLE='БирМаг — касса'
WINDOW_PROFILE=Path(os.environ.get('LOCALAPPDATA') or str(ROOT))/'BeerMagWindow'
CREATE_NO_WINDOW=0x08000000
DETACHED=0x00000008|0x00000200

STOP=threading.Event()
RESTART=threading.Event()
STATE={'proc':None,'status':'Запуск…','ready':False,'error':''}

def log(message):
    try:
        LOGS.mkdir(parents=True,exist_ok=True)
        with (LOGS/'app.log').open('a',encoding='utf-8') as f:f.write(time.strftime('%Y-%m-%d %H:%M:%S ')+message+'\n')
    except OSError:pass

def notice(text=None):
    """Сообщение для следующего запуска значка (после автоотката значок перезапускается)."""
    path=DATA/'update-notice.txt'
    try:
        if text is not None:DATA.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8');return None
        text=path.read_text(encoding='utf-8').strip();path.unlink();return text
    except OSError:return None

def app_key():
    """Ключ окна кассы: им подтверждаются первая настройка и ввод токена (вместо кода из консоли)."""
    path=DATA/'app-key.txt'
    try:
        key=path.read_text(encoding='ascii').strip()
        if len(key)>=24:return key
    except OSError:pass
    key=secrets.token_urlsafe(24)
    DATA.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(key,encoding='ascii');os.replace(tmp,path)
    return key

NO_PROXY=urllib.request.build_opener(urllib.request.ProxyHandler({}))   # системный прокси не должен мешать 127.0.0.1
def status():
    try:
        with NO_PROXY.open(URL+'api/status',timeout=3) as r:return json.loads(r.read())
    except Exception:return None

# ---------------------------------------------------------------- окно кассы
def browser():
    bases=[os.environ.get(k) for k in ('ProgramFiles(x86)','ProgramFiles','LOCALAPPDATA')]
    for rel in ('Microsoft/Edge/Application/msedge.exe','Google/Chrome/Application/chrome.exe','Yandex/YandexBrowser/Application/browser.exe'):
        for base in bases:
            if base and (Path(base)/rel).is_file():return Path(base)/rel
    return None

def focus_existing():
    """Если окно кассы уже открыто — развернуть его вместо второго окна."""
    if os.name!='nt':return False
    import ctypes
    from ctypes import wintypes
    user=ctypes.WinDLL('user32',use_last_error=True)
    H=wintypes.HWND
    user.GetWindowTextLengthW.argtypes=[H];user.GetWindowTextW.argtypes=[H,wintypes.LPWSTR,ctypes.c_int]
    user.IsWindowVisible.argtypes=[H];user.IsIconic.argtypes=[H];user.ShowWindow.argtypes=[H,ctypes.c_int]
    user.SetForegroundWindow.argtypes=[H]
    PROC=ctypes.WINFUNCTYPE(wintypes.BOOL,H,wintypes.LPARAM)
    user.EnumWindows.argtypes=[PROC,wintypes.LPARAM]
    found=[]
    @PROC
    def each(hwnd,_):
        n=user.GetWindowTextLengthW(hwnd)
        if n and user.IsWindowVisible(hwnd):
            buf=ctypes.create_unicode_buffer(n+1);user.GetWindowTextW(hwnd,buf,n+1)
            if buf.value.startswith(TITLE):found.append(hwnd);return False
        return True
    user.EnumWindows(each,0)
    if not found:return False
    hwnd=found[0]
    if user.IsIconic(hwnd):user.ShowWindow(hwnd,9)   # SW_RESTORE
    user.SetForegroundWindow(hwnd)
    return True

# 0.5.34: запасы дополнений браузера в профиле окна кассы. Черновики чеков и пересчёта (Default) не трогаем.
PROFILE_JUNK=('component_crx_cache','ProvenanceData','Edge Wallet','Edge Shopping','Edge Entity Extraction','WidevineCdm',
              'Subresource Filter','EdgeLanguageDetectionModel','BrowserMetrics','GrShaderCache','ShaderCache')
def trim_window_profile():
    for name in PROFILE_JUNK:
        try:shutil.rmtree(WINDOW_PROFILE/name,ignore_errors=True)
        except Exception as e:log('Очистка окна: '+repr(e))

LAST_OPEN=[-10.0]
def open_window(key):
    if time.monotonic()-LAST_OPEN[0]<3:return   # двойной щелчок не открывает два окна
    LAST_OPEN[0]=time.monotonic()
    try:
        if focus_existing():return
    except Exception as e:log('Поиск окна: '+repr(e))
    url=URL+'#k='+key
    exe=browser()
    if exe:
        trim_window_profile()
        # 0.5.34: окну кассы не нужны дополнения браузера (кошелёк, покупки, модели, DRM) — они занимали ~400 МБ.
        args=[str(exe),'--app='+url,'--user-data-dir='+str(WINDOW_PROFILE),'--no-first-run','--no-default-browser-check',
              '--disable-features=Translate,msEdgeTranslate,msEdgeShopping,msWalletHub,msEntityExtraction','--disable-component-update',
              '--start-maximized','--disable-session-crashed-bubble']
        try:subprocess.Popen(args,creationflags=DETACHED if os.name=='nt' else 0,close_fds=True);return
        except OSError as e:log('Окно кассы: '+repr(e))
    webbrowser.open(url)

# ---------------------------------------------------------------- сервер кассы
def python_exe():
    for name in ('python.exe','python3','python'):
        p=ROOT/'runtime'/name
        if p.is_file():return str(p)
    exe=Path(sys.executable)
    if exe.name.lower()=='pythonw.exe' and exe.with_name('python.exe').is_file():return str(exe.with_name('python.exe'))
    return sys.executable

def rotate(path,limit=5_000_000):
    try:
        if path.stat().st_size>limit:os.replace(path,path.with_suffix('.old.log'))
    except OSError:pass

JOB=[]
def job():
    """Объект задания Windows «закрыть всё при закрытии»: если значок закроют или его процесс завершат
    из диспетчера задач, Windows сама остановит сервер кассы — без значка он не останется работать."""
    if JOB:return JOB[0]
    import ctypes
    from ctypes import wintypes as w
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    class BASIC(ctypes.Structure):
        _fields_=[('user_time',ctypes.c_int64),('job_time',ctypes.c_int64),('flags',w.DWORD),('min_ws',ctypes.c_size_t),('max_ws',ctypes.c_size_t),
                  ('processes',w.DWORD),('affinity',ctypes.c_size_t),('priority',w.DWORD),('scheduling',w.DWORD)]
    class EXTENDED(ctypes.Structure):
        _fields_=[('basic',BASIC),('io',ctypes.c_uint64*6),('process_memory',ctypes.c_size_t),('job_memory',ctypes.c_size_t),
                  ('peak_process',ctypes.c_size_t),('peak_job',ctypes.c_size_t)]
    k.CreateJobObjectW.argtypes=[w.LPVOID,w.LPCWSTR];k.CreateJobObjectW.restype=w.HANDLE
    k.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD];k.SetInformationJobObject.restype=w.BOOL
    k.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];k.AssignProcessToJobObject.restype=w.BOOL
    handle=k.CreateJobObjectW(None,None)   # дескриптор не наследуется: он есть только у значка
    info=EXTENDED();info.basic.flags=0x2000   # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not handle or not k.SetInformationJobObject(handle,9,ctypes.byref(info),ctypes.sizeof(info)):
        raise OSError(ctypes.get_last_error(),'объект задания Windows не создан')
    JOB.append((k,handle));return JOB[0]

def attach(proc):
    if os.name!='nt':return False
    try:
        k,handle=job()
        if not k.AssignProcessToJobObject(handle,int(proc._handle)):raise OSError(k.GetLastError(),'процесс не добавлен в задание')
        return True
    except Exception as e:log('Сервер не привязан к значку: '+repr(e));return False

PID_FILE='server.pid'
def remember(proc,launch):
    """data\\server.pid: какой сервер запустил значок (если значок «убьют», новый значок его узнает)."""
    try:(DATA/PID_FILE).write_text(json.dumps({'pid':proc.pid,'launch':launch,'exe':python_exe()}),encoding='utf-8')
    except (OSError,AttributeError,TypeError):pass
def forget():
    try:(DATA/PID_FILE).unlink(missing_ok=True)
    except OSError:pass

def stop_orphan(st):
    """На порту отвечает сервер этой же кассы, оставшийся без значка (значок был завершён аварийно).
    Он узнаётся по номеру запуска из data\\server.pid и останавливается, чтобы касса снова была под присмотром."""
    if os.name!='nt' or not st or not st.get('launch'):return False
    try:info=json.loads((DATA/PID_FILE).read_text(encoding='utf-8'))
    except (OSError,ValueError):return False
    if not isinstance(info,dict) or info.get('launch')!=st['launch'] or not isinstance(info.get('pid'),int):return False
    import ctypes
    from ctypes import wintypes as w
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
    k.QueryFullProcessImageNameW.argtypes=[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
    k.TerminateProcess.argtypes=[w.HANDLE,w.UINT];k.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD];k.CloseHandle.argtypes=[w.HANDLE]
    handle=k.OpenProcess(0x0001|0x1000|0x00100000,False,info['pid'])   # TERMINATE|QUERY_LIMITED_INFORMATION|SYNCHRONIZE
    if not handle:return False
    try:
        buf=ctypes.create_unicode_buffer(1024);size=w.DWORD(1024)
        if not k.QueryFullProcessImageNameW(handle,0,buf,ctypes.byref(size)):return False
        if os.path.normcase(os.path.abspath(buf.value))!=os.path.normcase(os.path.abspath(str(info.get('exe','')))):return False   # номер процесса уже занят другой программой
        log('Остановлен сервер кассы, оставшийся без значка (pid %d)'%info['pid'])
        k.TerminateProcess(handle,1);k.WaitForSingleObject(handle,10000)
    finally:k.CloseHandle(handle)
    forget()
    for _ in range(20):   # порт освобождается не мгновенно
        if not status():break
        time.sleep(.5)
    return True

def spawn(key,launch=''):
    LOGS.mkdir(parents=True,exist_ok=True)
    server_log=LOGS/'server.log';rotate(server_log)
    out=server_log.open('ab')
    env=dict(os.environ,BEERMAG_APP_KEY=key,BEERMAG_LAUNCH_ID=launch,PYTHONIOENCODING='utf-8',PYTHONUNBUFFERED='1')
    try:
        proc=subprocess.Popen([python_exe(),str(ROOT/'start_moysklad.py'),'--app','--no-browser','--port',str(PORT)],
                              cwd=str(ROOT),env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,
                              creationflags=CREATE_NO_WINDOW if os.name=='nt' else 0)
    finally:out.close()
    attach(proc);remember(proc,launch)
    return proc

def log_tail(lines=6):
    try:
        text=(LOGS/'server.log').read_bytes()[-4000:].decode('utf-8','replace')
        return '\n'.join([x for x in text.splitlines() if x.strip()][-lines:])
    except OSError:return ''

def own_hash():
    try:return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    except OSError:return ''

PROBATION_UPTIME=int(os.environ.get('BEERMAG_PROBATION_UPTIME','600'))   # секунд работы новой версии до снятия испытания

class Supervisor:
    def __init__(self,key,tray,open_first=True):
        self.key=key;self.tray=tray;self.open_first=open_first;self.hash=own_hash()
    def wait_ready(self,proc,launch):
        # Ждём, пока ответит именно наш сервер (по номеру запуска), сколько бы ни длился запуск.
        # Только что установленная версия ждётся не дольше PROBATION_WAIT: зависла — значит, не запустилась.
        started=time.monotonic();slow=False;self.hung=False   # не time.time(): Windows может перевести часы во время запуска
        limit=self.probation_wait()
        while proc.poll() is None and not STOP.is_set():
            st=status()
            if st and st.get('launch')==launch:return st
            if not slow and time.monotonic()-started>90:
                slow=True;self.tray.tip('БирМаг — касса запускается дольше обычного…');log('Запуск дольше 90 с')
            if limit and time.monotonic()-started>limit:
                log('Новая версия не ответила за %d с'%limit);self.hung=True;stop_server(proc);break
            time.sleep(.5)
        return None
    def probation_wait(self):
        try:
            import autoupdate
            return autoupdate.PROBATION_WAIT if autoupdate.probation() else 0
        except Exception:return 0
    def update_started(self,st):
        # 0.5.15: испытание снимается не по первому ответу, а когда новая версия проработала 10 минут подряд
        # (этот же запуск отвечает). Версия, которая ответила один раз и потом падает, по-прежнему откатывается.
        launch=st.get('launch')
        def passed():
            if STOP.is_set():return
            now=status()
            if not now:   # сервер не ответил в эту секунду — повторим через минуту, пока это тот же запуск
                if STATE.get('ready'):t=threading.Timer(60,passed);t.daemon=True;t.start()
                return
            if now.get('launch')!=launch:return
            try:
                import autoupdate
                try:autoupdate.probation_passed(st.get('version',''),answered=True)
                except TypeError:autoupdate.probation_passed(st.get('version',''))   # autoupdate прежней версии
            except Exception as e:log('Проверка обновления: '+repr(e))
        try:
            import autoupdate
            if not autoupdate.probation():return
        except Exception as e:log('Проверка обновления: '+repr(e));return
        timer=threading.Timer(PROBATION_UPTIME,passed);timer.daemon=True;timer.start()
    def update_failed(self):
        """Новая версия не запустилась: после нескольких попыток (или зависания) вернуть прежнюю."""
        try:
            import autoupdate   # уже свежий: apply_update перечитал его с диска перед этим запуском
            if not autoupdate.probation():return False
            if not autoupdate.probation_failed() and not self.hung:return False
            result=autoupdate.rollback_failed()
        except Exception as e:
            log('Откат обновления не выполнен: '+repr(e));return False
        text='Новая версия %s не запустилась. Касса вернулась к версии %s.'%(result['from'],result['to'])
        log(text);notice(text)
        return True
    def wait_port_free(self):
        # На порту уже отвечает другая касса (например, старое чёрное окно): ждём, пока её закроют.
        warned=False
        while not STOP.is_set():
            st=status()
            if not st:break
            try:
                if stop_orphan(st):continue
            except Exception as e:log('Остановка прежнего сервера: '+repr(e))
            if not warned:
                warned=True;log('Порт кассы занят другой программой')
                STATE.update(error='На этом компьютере уже открыта другая касса БирМаг (например, старое чёрное окно). Закройте её.')
                self.tray.tip('БирМаг — закройте другое окно кассы')
                self.tray.balloon('Касса уже открыта','Закройте старое окно кассы БирМаг — после этого касса запустится сама.',error=True)
            time.sleep(5)
    def apply_update(self):
        # Скачанное обновление ставится до запуска сервера; если обновился сам значок — перезапускаем его.
        try:
            # Значок работает неделями: модули обновления каждый раз читаем с диска заново.
            for name in ('autoupdate','update','app_lock'):sys.modules.pop(name,None)
            import autoupdate
            installed=autoupdate.apply_pending()
            if installed:log('Установлено обновление '+installed)
        except Exception as e:
            log('Обновление не установлено: '+repr(e))
        return own_hash()!=self.hash
    def run(self):
        """Сбой самого присмотра (например, антивирус убрал python.exe) не должен молча оставлять «Запуск…» навсегда."""
        pause=5
        while not STOP.is_set():
            try:return self.loop()
            except Exception as e:
                import traceback;log('Сбой запуска кассы: '+traceback.format_exc())
                try:stop_server()
                except Exception:pass
                STATE.update(ready=False,proc=None,status='не запускается',error='Касса не запускается: '+str(e)[:300])
                try:
                    self.tray.tip('БирМаг — касса не запускается')
                    self.tray.balloon('Касса не запускается','Не удалось запустить кассу: '+str(e)[:150]+'. Повтор через %d с. Если не поможет — перезагрузите компьютер.'%pause,error=True)
                except Exception:pass
                RESTART.wait(pause);pause=min(pause*2,300)
    def loop(self):
        fails=[]
        while not STOP.is_set():
            RESTART.clear()
            self.wait_port_free()
            if STOP.is_set():break
            if self.apply_update():
                log('Приложение обновлено — перезапуск значка');return self.restart_self(None,self.open_first)
            started=time.monotonic();launch=secrets.token_hex(8)
            self.tray.tip('БирМаг — запуск кассы…')
            proc=spawn(self.key,launch);STATE['proc']=proc;log('Сервер запущен, pid %d'%proc.pid)
            st=self.wait_ready(proc,launch)
            if st:
                STATE.update(ready=True,error='',status='работает')
                self.tray.tip('БирМаг %s — касса работает'%st.get('version',''))
                self.update_started(st)
                if own_hash()!=self.hash:   # обновление заменило само приложение (запасная проверка)
                    log('Приложение обновлено — перезапуск значка');return self.restart_self(proc,self.open_first)
                if self.open_first:self.open_first=False;open_window(self.key)
            code=proc.wait();STATE.update(ready=False,proc=None);forget()
            if STOP.is_set():break
            log('Сервер завершился с кодом %s'%code)
            if code==42 or RESTART.is_set():
                self.tray.tip('БирМаг — перезапуск…')
                if code==42:self.tray.balloon('БирМаг','Устанавливается обновление, касса перезапускается.')
                continue
            # 0.5.16: новая версия на испытании, которая ответила, но упала раньше 10 минут работы, — тоже неудача.
            if (not st or time.monotonic()-started<PROBATION_UPTIME) and self.update_failed():
                return self.restart_self(None,self.open_first)   # прежняя версия, в том числе прежний значок
            if time.monotonic()-started<30:fails.append(time.monotonic())
            fails=[t for t in fails if t>time.monotonic()-300]
            if len(fails)>=3:
                tail=log_tail()
                STATE.update(status='остановлена',error=tail)
                self.tray.tip('БирМаг — касса не запускается')
                self.tray.balloon('Касса не запускается',(tail.splitlines() or ['См. data\\logs\\server.log'])[-1][:200],error=True)
                log('Касса не запускается: '+tail.replace('\n',' | '))
                RESTART.wait(120)   # «Перезапустить кассу» из меню — или сами пробуем снова через 2 минуты
                fails=[];continue
            self.tray.balloon('БирМаг','Касса была остановлена и запускается снова.')
            time.sleep(3)
    def restart_self(self,proc,open_window_after=False):
        if proc:stop_server(proc)
        self.tray.release()
        exe=Path(sys.executable)
        subprocess.Popen([str(exe),str(Path(__file__)),'--restarted']+([] if open_window_after else ['--no-window']),cwd=str(ROOT),close_fds=True,
                         creationflags=DETACHED if os.name=='nt' else 0)
        STOP.set();self.tray.quit()

def stop_server(proc=None):
    proc=proc or STATE.get('proc')
    if proc and proc.poll() is None:
        proc.terminate()
        try:proc.wait(10)
        except subprocess.TimeoutExpired:proc.kill()

# ---------------------------------------------------------------- значок у часов (Win32)
class Tray:
    """Минимальный значок в области уведомлений на чистом ctypes."""
    OPEN,STATUS,RESTART_ID,LOGS_ID,QUIT=1,2,3,4,9
    def __init__(self,key):
        import ctypes
        from ctypes import wintypes as w
        self.c=ctypes;self.w=w;self.key=key;self.hwnd=None;self.mutex=None
        u=self.user=ctypes.WinDLL('user32',use_last_error=True)
        self.shell=ctypes.WinDLL('shell32',use_last_error=True)
        self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        LRESULT=ctypes.c_ssize_t
        self.WNDPROC=ctypes.WINFUNCTYPE(LRESULT,w.HWND,w.UINT,w.WPARAM,w.LPARAM)
        class WNDCLASSW(ctypes.Structure):
            _fields_=[('style',w.UINT),('lpfnWndProc',self.WNDPROC),('cbClsExtra',ctypes.c_int),('cbWndExtra',ctypes.c_int),
                      ('hInstance',w.HINSTANCE),('hIcon',w.HICON),('hCursor',w.HANDLE),('hbrBackground',w.HBRUSH),
                      ('lpszMenuName',w.LPCWSTR),('lpszClassName',w.LPCWSTR)]
        class GUID(ctypes.Structure):
            _fields_=[('a',ctypes.c_ulong),('b',ctypes.c_ushort),('c',ctypes.c_ushort),('d',ctypes.c_ubyte*8)]
        class NOTIFYICONDATAW(ctypes.Structure):
            _fields_=[('cbSize',w.DWORD),('hWnd',w.HWND),('uID',w.UINT),('uFlags',w.UINT),('uCallbackMessage',w.UINT),
                      ('hIcon',w.HICON),('szTip',ctypes.c_wchar*128),('dwState',w.DWORD),('dwStateMask',w.DWORD),
                      ('szInfo',ctypes.c_wchar*256),('uVersion',w.UINT),('szInfoTitle',ctypes.c_wchar*64),
                      ('dwInfoFlags',w.DWORD),('guidItem',GUID),('hBalloonIcon',w.HICON)]
        self.WNDCLASSW=WNDCLASSW;self.NID=NOTIFYICONDATAW
        u.DefWindowProcW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.DefWindowProcW.restype=LRESULT
        u.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,
                                    w.HWND,w.HMENU,w.HINSTANCE,w.LPVOID];u.CreateWindowExW.restype=w.HWND
        u.RegisterClassW.argtypes=[ctypes.POINTER(WNDCLASSW)];u.RegisterClassW.restype=w.ATOM
        u.LoadImageW.argtypes=[w.HINSTANCE,w.LPCWSTR,w.UINT,ctypes.c_int,ctypes.c_int,w.UINT];u.LoadImageW.restype=w.HANDLE
        u.LoadIconW.argtypes=[w.HINSTANCE,w.LPVOID];u.LoadIconW.restype=w.HICON
        u.AppendMenuW.argtypes=[w.HMENU,w.UINT,ctypes.c_size_t,w.LPCWSTR];u.CreatePopupMenu.restype=w.HMENU
        u.TrackPopupMenu.argtypes=[w.HMENU,w.UINT,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.HWND,w.LPVOID];u.TrackPopupMenu.restype=ctypes.c_int
        u.SetMenuDefaultItem.argtypes=[w.HMENU,w.UINT,w.UINT]
        u.DestroyMenu.argtypes=[w.HMENU]
        u.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
        u.SetForegroundWindow.argtypes=[w.HWND]
        u.MessageBoxW.argtypes=[w.HWND,w.LPCWSTR,w.LPCWSTR,w.UINT]
        u.RegisterWindowMessageW.argtypes=[w.LPCWSTR];u.RegisterWindowMessageW.restype=w.UINT
        u.GetMessageW.argtypes=[ctypes.POINTER(w.MSG),w.HWND,w.UINT,w.UINT]
        u.TranslateMessage.argtypes=[ctypes.POINTER(w.MSG)];u.DispatchMessageW.argtypes=[ctypes.POINTER(w.MSG)]
        u.DestroyWindow.argtypes=[w.HWND]
        self.shell.Shell_NotifyIconW.argtypes=[w.DWORD,ctypes.POINTER(NOTIFYICONDATAW)];self.shell.Shell_NotifyIconW.restype=w.BOOL
        self.kernel.GetModuleHandleW.argtypes=[w.LPCWSTR];self.kernel.GetModuleHandleW.restype=w.HMODULE
        self.kernel.CreateMutexW.argtypes=[w.LPVOID,w.BOOL,w.LPCWSTR];self.kernel.CreateMutexW.restype=w.HANDLE
        self.kernel.CloseHandle.argtypes=[w.HANDLE]
        self.WM_CALLBACK=0x8000+1   # WM_APP+1
        self.lock=threading.Lock();self._tip='БирМаг';self.added=False;self.TASKBAR=0;self.icon=None

    # единственный экземпляр
    def single(self,wait=0):
        end=time.monotonic()+wait
        while True:
            self.mutex=self.kernel.CreateMutexW(None,False,'Local\\BeerMagKassaApp')
            if self.c.get_last_error()!=183:return True      # ERROR_ALREADY_EXISTS
            self.kernel.CloseHandle(self.mutex);self.mutex=None
            if time.monotonic()>=end:return False
            time.sleep(.5)
    def release(self):
        self.remove()
        if self.mutex:self.kernel.CloseHandle(self.mutex);self.mutex=None

    def nid(self,flags):
        n=self.NID();n.cbSize=self.c.sizeof(self.NID);n.hWnd=self.hwnd;n.uID=1;n.uFlags=flags
        return n
    def add(self):
        n=self.nid(0x1|0x2|0x4);n.uCallbackMessage=self.WM_CALLBACK;n.hIcon=self.icon;n.szTip=self._tip[:127]
        self.added=bool(self.shell.Shell_NotifyIconW(0,self.c.byref(n)))
    def remove(self):
        if self.hwnd and self.added:
            n=self.nid(0);self.shell.Shell_NotifyIconW(2,self.c.byref(n));self.added=False
    def tip(self,text):
        with self.lock:
            self._tip=text
            if self.hwnd and self.added:
                n=self.nid(0x4);n.szTip=text[:127];self.shell.Shell_NotifyIconW(1,self.c.byref(n))
    def balloon(self,title,text,error=False):
        with self.lock:
            if self.hwnd and self.added:
                n=self.nid(0x10);n.szInfo=text[:255];n.szInfoTitle=title[:63];n.dwInfoFlags=3 if error else 1
                self.shell.Shell_NotifyIconW(1,self.c.byref(n))
    def message(self,text,flags=0x40):
        return self.user.MessageBoxW(None,text,'БирМаг',flags|0x10000|0x40000)   # поверх окон
    def quit(self):
        if self.hwnd:self.user.PostMessageW(self.hwnd,0x0010,0,0)   # WM_CLOSE

    def menu(self):
        u=self.user;m=u.CreatePopupMenu()
        u.AppendMenuW(m,0,self.OPEN,'Открыть кассу')
        u.AppendMenuW(m,0,self.STATUS,'Состояние')
        u.AppendMenuW(m,0x800,0,None)
        u.AppendMenuW(m,0,self.RESTART_ID,'Перезапустить кассу')
        u.AppendMenuW(m,0,self.LOGS_ID,'Папка журналов')
        u.AppendMenuW(m,0x800,0,None)
        u.AppendMenuW(m,0,self.QUIT,'Выход')
        u.SetMenuDefaultItem(m,self.OPEN,0)
        pt=self.w.POINT();u.GetCursorPos(self.c.byref(pt))
        u.SetForegroundWindow(self.hwnd)
        cmd=u.TrackPopupMenu(m,0x0100|0x0080|0x0002,pt.x,pt.y,0,self.hwnd,None)   # RETURNCMD|NONOTIFY|RIGHTBUTTON
        u.PostMessageW(self.hwnd,0,0,0);u.DestroyMenu(m)
        if cmd:self.command(cmd)

    def command(self,cmd):
        if cmd==self.OPEN:
            if STATE['ready']:open_window(self.key)
            else:self.message('Касса ещё запускается или остановлена.\n\n'+(STATE['error'] or 'Подождите несколько секунд.'),0x30)
        elif cmd==self.STATUS:
            st=status()
            if st:
                lines=['Версия: '+str(st.get('version','')),'Касса работает: '+URL]
                if st.get('token_needed'):lines.append('МойСклад: нужен API-токен (введите в окне кассы).')
                elif st.get('moysklad_ready'):lines.append('МойСклад: подключён.')
                if st.get('setup'):lines.append('Нужна первая настройка управляющего.')
            else:lines=['Касса не отвечает.',STATE['error'] or 'Идёт запуск или перезапуск.']
            try:
                upd=(DATA/'update-log.txt').read_text(encoding='utf-8').strip().splitlines()[-1]
                lines.append('Обновления: '+upd)
            except (OSError,IndexError):pass
            lines.append('Папка программы: '+str(ROOT))
            self.message('\n'.join(lines))
        elif cmd==self.RESTART_ID:
            if self.message('Перезапустить кассу? Незавершённые чеки сохранятся.',0x21)==1:
                RESTART.set();threading.Thread(target=stop_server,daemon=True).start()
        elif cmd==self.LOGS_ID:
            LOGS.mkdir(parents=True,exist_ok=True);os.startfile(str(LOGS))
        elif cmd==self.QUIT:
            if self.message('Закрыть кассу БирМаг?\n\nПока касса закрыта, продажи на этом компьютере невозможны. '
                            'Чтобы снова запустить — ярлык «Касса БирМаг» на рабочем столе.',0x31)==1:
                STOP.set();RESTART.set();self.tip('БирМаг — закрытие…')
                threading.Thread(target=lambda:(stop_server(),self.quit()),daemon=True).start()

    def wndproc(self,hwnd,msg,wparam,lparam):
        try:
            if msg==self.WM_CALLBACK:
                event=lparam&0xFFFF
                if event in (0x0203,0x0202):self.command(self.OPEN)         # щелчок по значку
                elif event in (0x0205,0x007B):self.menu()                   # правая кнопка
                return 0
            if msg==self.TASKBAR and self.TASKBAR:self.add();return 0       # проводник перезапустился
            if msg==0x0010:self.user.DestroyWindow(hwnd);return 0          # WM_CLOSE
            if msg==0x0002:self.remove();self.user.PostQuitMessage(0);return 0   # WM_DESTROY
        except Exception as e:log('Меню: '+repr(e))
        return self.user.DefWindowProcW(hwnd,msg,wparam,lparam)

    def create(self):
        c,w,u=self.c,self.w,self.user
        hinst=self.kernel.GetModuleHandleW(None)
        self._proc=self.WNDPROC(self.wndproc)   # держим ссылку, иначе сборщик мусора удалит callback
        wc=self.WNDCLASSW();wc.lpfnWndProc=self._proc;wc.hInstance=hinst;wc.lpszClassName='BeerMagTray'
        u.RegisterClassW(c.byref(wc))
        self.hwnd=u.CreateWindowExW(0,'BeerMagTray','БирМаг',0,0,0,0,0,None,None,hinst,None)
        self.TASKBAR=u.RegisterWindowMessageW('TaskbarCreated')
        ico=ROOT/'beermag.ico'
        self.icon=u.LoadImageW(None,str(ico),1,0,0,0x10|0x40) if ico.is_file() else None
        if not self.icon:self.icon=u.LoadIconW(None,c.c_void_p(32512))   # IDI_APPLICATION
        self.add()
        if not self.added:   # проводник ещё не готов сразу после входа в Windows
            for _ in range(30):
                time.sleep(2);self.add()
                if self.added:break
        log('Значок у часов: '+('показан' if self.added else 'не удалось показать'))
    def loop(self):
        msg=self.w.MSG()
        while self.user.GetMessageW(self.c.byref(msg),None,0,0)>0:
            self.user.TranslateMessage(self.c.byref(msg));self.user.DispatchMessageW(self.c.byref(msg))

def main():
    args=sys.argv[1:]
    if os.name!='nt':raise SystemExit('Приложение БирМаг работает в Windows. Для проверки используйте server.py.')
    os.chdir(ROOT)
    key=app_key()
    tray=Tray(key)
    if not tray.single(wait=20 if '--restarted' in args else 0):
        # Касса уже работает: только показать окно.
        if status():open_window(key)
        else:tray.message('Касса БирМаг уже запускается. Значок — у часов справа внизу.')
        return
    log('Запуск приложения '+' '.join(args))
    tray.create()
    text=notice()
    if text:tray.balloon('Обновление отменено',text,error=True)
    sup=Supervisor(key,tray,open_first='--no-window' not in args)
    threading.Thread(target=sup.run,daemon=True).start()
    try:tray.loop()
    finally:
        STOP.set();RESTART.set()
        if STATE.get('proc'):stop_server()
        tray.release();log('Приложение закрыто')

if __name__=='__main__':
    try:main()
    except SystemExit:raise
    except Exception as e:
        import traceback;log('Сбой приложения: '+traceback.format_exc())
        raise

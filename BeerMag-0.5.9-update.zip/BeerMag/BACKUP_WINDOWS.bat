@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
"%~dp0runtime\python.exe" server.py --backup
pause

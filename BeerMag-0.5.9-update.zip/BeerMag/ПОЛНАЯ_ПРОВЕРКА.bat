@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
echo Полная проверка кассы на настоящем МоемСкладе: рабочий день, работа без интернета, инвентаризация.
echo Запускайте, когда смена на этой кассе ЗАКРЫТА. Займёт 3-5 минут.
echo Тестовые документы (номера BM-TEST) удаляются из МоегоСклада автоматически.
echo.
pause
"%~dp0runtime\python.exe" live_full_test.py
"%~dp0runtime\python.exe" live_test.py
"%~dp0runtime\python.exe" live_test.py --inventory
echo.
echo Отчёты: data\live-full-report.txt, data\live-test-report.txt, data\live-test-inventory-report.txt
pause

'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MONEY_FORMAT=new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:2});
const money=v=>MONEY_FORMAT.format((v||0)/100);
// 0.5.4: поиск не различает ё/е и регистр; несколько слов — в любом порядке («барное жигули»).
const fold=v=>String(v??'').toLocaleLowerCase('ru-RU').replace(/ё/g,'е');
const matchWords=(query,values)=>{const words=fold(query).split(/\s+/).filter(Boolean);if(!words.length)return false;const hay=values.map(fold).join(' ');return words.every(w=>hay.includes(w))};
// 0.5.3: функциональные клавиши никогда не уходят браузеру (F1 справка, F3 поиск, F5 перезагрузка, F6 адресная строка,
// F7 «активный курсор», F9 режим чтения, F10 меню, F12 инструменты). Действия кассы назначены отдельно ниже.
document.addEventListener('keydown',e=>{if(/^F([1-9]|10|12)$/.test(e.key)&&!e.altKey&&!e.metaKey)e.preventDefault()},true);
// 0.5.4: окно разливного с клавиатуры: ←/→ объём, ↑/↓ вид тары, +/− количество порций, Enter — «Добавить в покупку».
function draftFocus(){const c=$('#bottleCount');c?.focus?.();c?.select?.()}
function draftVolume(step){
 const buttons=[...$$('.volumes button')];if(!buttons.length)return;
 const at=Math.max(0,buttons.findIndex(b=>b.classList.contains('active')));const next=buttons[Math.min(buttons.length-1,Math.max(0,at+step))];
 if(next&&next!==buttons[at])next.click();else draftFocus();
}
document.addEventListener('keydown',e=>{
 if(!S.draftOpen||!$('#modal')?.open||e.ctrlKey||e.altKey||e.metaKey||e.isComposing)return;
 const key=e.key;
 if(key==='ArrowLeft'||key==='ArrowRight'){e.preventDefault();draftVolume(key==='ArrowRight'?1:-1);return}
 if(key==='ArrowUp'||key==='ArrowDown'){
  e.preventDefault();const sel=$('#drinkPackaging');const step=key==='ArrowDown'?1:-1;
  if(sel&&sel.options&&sel.options.length>1){const i=Math.min(sel.options.length-1,Math.max(0,sel.selectedIndex+step));if(i!==sel.selectedIndex){sel.selectedIndex=i;S.selection.packaging_id=Number(sel.value)}draftFocus()}
  else draftVolume(key==='ArrowUp'?1:-1);
  return;
 }
 if(key==='+'||key==='='||key==='Add'){e.preventDefault();$('#modal [data-action="portion-plus"]')?.click();return}
 if(key==='-'||key==='−'||key==='Subtract'){e.preventDefault();$('#modal [data-action="portion-minus"]')?.click();return}
 if(key==='Enter'){
  if(e.repeat)return;const target=e.target;
  if(target?.closest?.('[data-action="close"],[data-action="add-draft"]'))return;   // кнопка сработает сама
  e.preventDefault();if(!S.busy)$('#modal [data-action="add-draft"]')?.click();
 }
});
const qty=v=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:3}).format((v||0)/1000);
const date=v=>v?new Date(v).toLocaleString('ru-RU'):'';
const shortDate=v=>v?new Date(v).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'';
const roles={seller:'Продавец',admin:'Администратор',manager:'Управляющий'};
const kinds={draft:'Разливные напитки',piece:'Штучные товары',weight:'Весовые закуски',packaging:'Тара'};
const unit=k=>({draft:'л',weight:'кг',piece:'шт.',packaging:'шт.'}[k]);
const statuses={draft:'Черновик',posted:'Проведён',submitted:'На проверке',adjusting:'Корректировка остатков',cancelled:'Отменён',refunded:'Возврат',exported:'Передано в МойСклад'};
let S={demo:false,boot:null,shop:0,page:'pos',cart:[],cartSlot:1,category:'all',group:null,catalogView:'groups',query:'',shift:null,docs:[],receipt:null,inventory:null,selection:null,busy:false,last:null,saleAttempt:null,refundAttempt:null,cashAttempt:null,shiftAttempt:null};
// Тема запоминается на этом компьютере; по умолчанию светлая.
function applyTheme(theme){try{localStorage.setItem('beermag:theme',theme)}catch{}if(theme==='dark')document.documentElement.dataset.theme='dark';else delete document.documentElement.dataset.theme}
try{if(localStorage.getItem('beermag:theme')==='dark')document.documentElement.dataset.theme='dark'}catch{}
let inventoryDirty=false;
let inventoryZones=[],inventoryZoneId=null;
let activeCartKey=null;
let saleAttempted=false;
function cartKey(slot=S.cartSlot){return S.boot&&S.shop?`beermag:cart:v1:${S.demo?'demo':'live'}:${S.boot.user.id}:${S.shop}${slot===1?'':':'+slot}`:null}
function cartStore(action,key,value){try{if(action==='get')return localStorage.getItem(key);if(action==='set')localStorage.setItem(key,value);else localStorage.removeItem(key);return true}catch{return action==='get'?null:false}}
function shiftAttemptKey(){return S.boot?`beermag:shift-attempt:v1:${S.demo?'demo':'live'}:${S.boot.user.id}`:null}
function loadShiftAttempt(){
 S.shiftAttempt=null;const key=shiftAttemptKey();if(!key)return;
 try{
  const saved=JSON.parse(cartStore('get',key)||'null');if(!saved)return;
  if(!['open','close'].includes(saved.mode)||!saved.body||!Number.isInteger(saved.body.shop_id)||
     typeof saved.body.cash!=='string'||typeof saved.key!=='string'||!saved.key||
     saved.fingerprint!==JSON.stringify(saved.body))throw Error('bad shift attempt');
  S.shiftAttempt=saved;
 }catch{cartStore('remove',key)}
}
function updateShiftRecovery(){
 const panel=$('#shiftRecoveryPanel');if(!panel)return;
 if(!S.shiftAttempt){panel.innerHTML='';return}
 const attempt=S.shiftAttempt,shop=S.boot?.shops?.find(x=>x.id===attempt.body.shop_id);
 panel.innerHTML=`<div class="notice amber"><strong>${attempt.mode==='open'?'Открытие':'Закрытие'} смены пока не подтверждено кассой.</strong> ${esc(shop?.name||'Магазин № '+attempt.body.shop_id)}. Проверка использует прежний ключ операции. ${btn('Проверить смену','shift-retry','small primary')}</div>`;
}
function clearShiftAttempt(){const key=shiftAttemptKey();if(key)cartStore('remove',key);S.shiftAttempt=null;updateShiftRecovery()}
async function sendShiftAttempt(){
 const attempt=S.shiftAttempt;if(!attempt)throw Error('Нет операции смены для проверки');
 let result;
 try{result=await api('/api/shifts/'+attempt.mode,attempt.body,attempt.key)}
 catch(error){if(definiteRejection(error))clearShiftAttempt();else updateShiftRecovery();throw error}
 clearShiftAttempt();if($('#modal')?.open)close();S.shop=attempt.body.shop_id;
 await refreshBoot();
 if(attempt.mode==='open'){S.page='pos';await render()}
 else {S.page='shift';await render()}
 if(result.duplicate)toast('Смена уже записана. Повторная операция не создавалась.');
 // 0.5.4: итоги закрытой смены уже на экране — всплывающее сообщение не закрывает «Разницу» на фото.
 else if(attempt.mode==='close'&&Number.isInteger(result.difference)&&!$('#closedShift'))toast(result.difference===0?'Смена закрыта. Наличные сходятся.':'Смена закрыта. '+(result.difference<0?'Недостача ':'Излишек ')+money(Math.abs(result.difference))+' записан(а) в отчёт смен.',result.difference!==0);
}
function shiftCashRefresh(){
 const info=$('#shiftDiff'),input=$('#shiftCash');if(!info||!input||S.shiftExpected==null)return;
 const raw=String(input.value??'').trim().replace(',','.');if(raw===''){info.className='change-info';info.textContent='';return}
 const counted=Math.round(Number(raw)*100);if(!Number.isFinite(counted)){info.className='change-info error';info.textContent='Проверьте сумму';return}
 const diff=counted-S.shiftExpected;
 info.className='change-info'+(diff?' error':'');info.innerHTML=diff===0?'Сумма сходится':(diff<0?'Недостача ':'Излишек ')+'<strong>'+money(Math.abs(diff))+'</strong> — пересчитайте ещё раз перед закрытием';
}
function recordShift(mode,shiftId=null){
 if(!['open','close'].includes(mode))throw Error('Неизвестная операция смены');
 const cash=$('#shiftCash')?.value;
 if(cash==null||cash.trim()==='')throw Error('Укажите сумму наличных в кассе. Если касса пуста, введите 0.');
 const body={shop_id:S.shop,cash};if(shiftId)body.shift_id=shiftId;
 if(S.shiftAttempt){
  if(S.shiftAttempt.mode!==mode||S.shiftAttempt.fingerprint!==JSON.stringify(body))
   throw Error('Прежняя операция смены не подтверждена. Нажмите «Проверить смену» в предупреждении кассы.');
 }else{
  const key=shiftAttemptKey(),attempt={mode,body,key:crypto.randomUUID(),fingerprint:JSON.stringify(body)};
  if(!key||!cartStore('set',key,JSON.stringify(attempt)))throw Error('Не удалось сохранить ключ смены на этом компьютере. Проверьте хранилище браузера.');
  S.shiftAttempt=attempt;updateShiftRecovery();
 }
 return sendShiftAttempt();
}
function cashAttemptKey(){return S.boot?`beermag:cash-attempt:v1:${S.demo?'demo':'live'}:${S.boot.user.id}`:null}
function saleAttemptKey(){return S.boot?`beermag:sale-attempt:v1:${S.demo?'demo':'live'}:${S.boot.user.id}`:null}
function loadSaleAttempt(){
 S.saleAttempt=null;saleAttempted=false;const key=saleAttemptKey();if(!key)return;
 try{
  const saved=JSON.parse(cartStore('get',key)||'null');if(!saved)return;
  if(!saved.body||!Number.isInteger(saved.body.shop_id)||!['cash','card','mixed'].includes(saved.body.payment)||
     !Array.isArray(saved.body.lines)||!Number.isInteger(saved.slot)||saved.slot<1||saved.slot>3||
     typeof saved.key!=='string'||!saved.key||saved.fingerprint!==JSON.stringify(saved.body))throw Error('bad sale attempt');
  S.saleAttempt=saved;saleAttempted=true;
 }catch{cartStore('remove',key)}
}
function updateSaleRecovery(){
 const panel=$('#saleRecoveryPanel');if(!panel)return;
 if(!S.saleAttempt){panel.innerHTML='';return}
 const attempt=S.saleAttempt,shop=S.boot?.shops?.find(x=>x.id===attempt.body.shop_id);
 panel.innerHTML=`<div class="notice amber"><strong>Оплата пока не подтверждена кассой.</strong> Чек ${attempt.slot} · ${esc(shop?.name||'магазин № '+attempt.body.shop_id)} · ${money(Number(attempt.body.expected_total)*100)}. Не берите оплату повторно. Проверка использует прежний ключ продажи. ${btn('Проверить продажу','sale-retry','small primary')}</div>`;
}
function clearSaleAttempt(){const key=saleAttemptKey();if(key)cartStore('remove',key);S.saleAttempt=null;saleAttempted=false;updateSaleRecovery()}
function refundAttemptKey(){return S.boot?`beermag:refund-attempt:v1:${S.demo?'demo':'live'}:${S.boot.user.id}`:null}
function loadRefundAttempt(){
 S.refundAttempt=null;const key=refundAttemptKey();if(!key)return;
 try{
  const saved=JSON.parse(cartStore('get',key)||'null');if(!saved)return;
  if(!saved.body||!Number.isInteger(saved.body.shop_id)||!['string','number'].includes(typeof saved.body.id)||
     !Array.isArray(saved.body.lines)||typeof saved.body.reason!=='string'||saved.body.money_returned!==true||
     typeof saved.key!=='string'||saved.fingerprint!==JSON.stringify(saved.body))throw Error('bad refund attempt');
  S.refundAttempt=saved;
 }catch{cartStore('remove',key)}
}
function updateRefundRecovery(){
 const panel=$('#refundRecoveryPanel');if(!panel)return;
 if(!S.refundAttempt){panel.innerHTML='';return}
 const body=S.refundAttempt.body,shop=S.boot?.shops?.find(x=>x.id===body.shop_id);
 panel.innerHTML=`<div class="notice amber"><strong>Возврат пока не подтверждён.</strong> Покупка № ${esc(body.id)} · ${esc(shop?.name||'магазин № '+body.shop_id)}. Не возвращайте деньги второй раз. Проверка использует прежний ключ операции. ${btn('Проверить возврат','refund-retry','small primary')}</div>`;
}
function clearRefundAttempt(){const key=refundAttemptKey();if(key)cartStore('remove',key);S.refundAttempt=null;updateRefundRecovery()}
function loadCashAttempt(){
 S.cashAttempt=null;const key=cashAttemptKey();if(!key)return;
 try{
  const saved=JSON.parse(cartStore('get',key)||'null');if(!saved)return;
  if(!saved.body||!Number.isInteger(saved.body.shop_id)||!['in','out'].includes(saved.body.kind)||
     typeof saved.body.amount!=='string'||typeof saved.body.note!=='string'||typeof saved.key!=='string')throw Error('bad cash attempt');
  S.cashAttempt=saved;
 }catch{cartStore('remove',key)}
}
function updateCashRecovery(){
 const panel=$('#cashRecoveryPanel');if(!panel)return;
 if(!S.cashAttempt){panel.innerHTML='';return}
 const body=S.cashAttempt.body,shop=S.boot?.shops?.find(x=>x.id===body.shop_id);
 panel.innerHTML=`<div class="notice amber"><strong>Денежная операция пока не подтверждена.</strong> ${body.kind==='in'?'Внесение':'Выплата'} ${money(Number(body.amount)*100)} · ${esc(shop?.name||'магазин № '+body.shop_id)}. Повторите с сохранённым ключом; уже записанная операция второй раз не создастся. ${btn('Проверить запись','cash-retry','small primary')}</div>`;
}
function clearCashAttempt(){const key=cashAttemptKey();if(key)cartStore('remove',key);S.cashAttempt=null;updateCashRecovery()}
function definiteRejection(error){return [400,409,422].includes(error.status)&&!error.message.includes('Ключ уже использован другой операцией')}
async function sendCashAttempt(){
 const attempt=S.cashAttempt;if(!attempt)throw Error('Нет денежной операции для проверки');
 let result;
 try{result=await api('/api/cash/move',attempt.body,attempt.key)}
 catch(error){if(definiteRejection(error))clearCashAttempt();else updateCashRecovery();throw error}
 clearCashAttempt();if($('#modal')?.open)close();
 toast(result.duplicate?'Операция уже записана. Повторного внесения или выплаты не было.':result.sync_status?'Операция сохранена и ждёт передачи в МойСклад':'Операция записана');
 if(S.shop===attempt.body.shop_id)return page();
}
async function sendRefundAttempt(){
 const attempt=S.refundAttempt;if(!attempt)throw Error('Нет возврата для проверки');
 let result;
 try{result=await api('/api/sales/refund',attempt.body,attempt.key)}
 catch(error){if(definiteRejection(error))clearRefundAttempt();else updateRefundRecovery();throw error}
 clearRefundAttempt();if($('#modal')?.open)close();
 toast(result.duplicate?'Возврат уже записан. Деньги повторно не выдавайте.':(result.cash_amount!=null&&result.card_amount!=null?`Возврат: наличными ${money(result.cash_amount)}, на карту ${money(result.card_amount)}. `:'')+(S.boot?.moysklad?'Возврат сохранён и ждёт передачи в МойСклад':'Возврат оформлен'));
 if(S.shop===attempt.body.shop_id)return page();
}
function submitRefund(body){
 const fingerprint=JSON.stringify(body);
 if(S.refundAttempt){
  if(S.refundAttempt.fingerprint!==fingerprint)throw Error('Прежний возврат мог пройти. Сначала нажмите «Проверить возврат» в предупреждении кассы.');
 }else{
  const key=refundAttemptKey(),attempt={body,fingerprint,key:crypto.randomUUID()};
  if(!key||!cartStore('set',key,JSON.stringify(attempt)))throw Error('Не удалось сохранить ключ возврата на этом компьютере. Проверьте доступ к хранилищу браузера.');
  S.refundAttempt=attempt;updateRefundRecovery();
 }
 return sendRefundAttempt();
}
function saveCartDraft(){if(!activeCartKey)return false;if(saleAttempted){cartStore('remove',activeCartKey);return true}if(!S.cart.length)return cartStore('remove',activeCartKey);return cartStore('set',activeCartKey,JSON.stringify({lines:S.cart.map(x=>({...x,unit_price:S.boot.products.find(p=>p.id===x.product_id)?.price,pack_price:S.boot.products.find(p=>p.id===x.packaging_id)?.price})),saved_at:Date.now()}))}
function restoreCartDraft(silent=false){const key=cartKey();if(key===activeCartKey)return;activeCartKey=key;S.cart=[];if(!key)return;let draft;try{draft=JSON.parse(cartStore('get',key)||'null')}catch{cartStore('remove',key);return}if(!draft)return;if(!Array.isArray(draft.lines)){cartStore('remove',key);return}let changed=false;const packs=enabledPacks();for(const x of draft.lines.slice(0,100)){
 if(!x||typeof x!=='object'){changed=true;continue}
 const p=S.boot.products.find(p=>p.id===x.product_id&&p.active&&p.packaging_enabled!==false);
 if(!p||!Number.isFinite(x.qty)||x.qty<=0){changed=true;continue}
 if(p.kind==='draft'){const pack=S.boot.products.find(v=>v.id===x.packaging_id&&v.active&&v.packaging_enabled!==false);if(!pack||!packs.some(r=>r.volume===x.volume*1000&&r.product_id===pack.id)||!Number.isInteger(x.count)||x.count<1||x.count>1000){changed=true;continue}S.cart.push({product_id:p.id,volume:x.volume,count:x.count,qty:x.volume*x.count,packaging_id:pack.id});if(pack.price!==x.pack_price)changed=true}
 else if(p.kind==='weight'&&x.qty<=1000||['piece','packaging'].includes(p.kind)&&Number.isInteger(x.qty)&&x.qty<=1000)S.cart.push({product_id:p.id,qty:x.qty});else{changed=true;continue}
 if(p.price!==x.unit_price)changed=true
 }if(draft.lines.length>100)changed=true;
 saveCartDraft();if(changed||S.cart.length&&!silent)toast(changed?'Чек восстановлен. Часть позиций или цены изменились — проверьте покупку перед оплатой.':'Незавершённый чек восстановлен после перезапуска.',changed)
}
function clearCartDraft(){if(activeCartKey)cartStore('remove',activeCartKey);S.cart=[];saleAttempted=false}
function cartSlotCount(slot){if(slot===S.cartSlot)return S.cart.length;try{const draft=JSON.parse(cartStore('get',cartKey(slot))||'null');return Array.isArray(draft?.lines)?draft.lines.length:0}catch{return 0}}
function cartSlots(){return [1,2,3].map(slot=>`<button type="button" role="tab" aria-selected="${slot===S.cartSlot}" class="${slot===S.cartSlot?'active':''}" data-action="cart-slot" data-slot="${slot}" title="F${slot}"><span class="fkey">F${slot}</span> Чек ${slot}${cartSlotCount(slot)?` · ${cartSlotCount(slot)}`:''}</button>`).join('')}
// F1, F2, F3 — быстрый переход между чеками, чтобы обслуживать нескольких покупателей.
// Горячие клавиши кассы: F4 — поиск, F5 — наличные, F6 — безналичные, F7 — сложная оплата, F8 — пакет.
const BAG_CODE='01872'; // «Пакет Майка» в МоемСкладе
function bagProduct(){const ok=p=>p.active&&p.packaging_enabled!==false;return S.boot.products.find(p=>ok(p)&&p.source_code===BAG_CODE)||S.boot.products.find(p=>ok(p)&&/^пакет\s+майка/i.test(p.name))}
document.addEventListener('keydown',e=>{
 if(!['F4','F5','F6','F7','F8'].includes(e.key)||e.ctrlKey||e.altKey||e.metaKey||e.shiftKey)return;
 if(S.page!=='pos'||!$('#cartTabs'))return;e.preventDefault();
 if($('#modal')?.open||S.busy||e.repeat)return;
 try{
  if(e.key==='F4'){const input=$('#productSearch');input?.focus();input?.select?.();return}
  if(e.key==='F5'||e.key==='F6'||e.key==='F7'){
   const b=$(`[data-action="${{F5:'pay-cash',F6:'pay-card',F7:'pay-mixed'}[e.key]}"]`);
   if(!S.cart.length)throw Error('Чек пуст — добавьте товар');
   if(!S.shift?.shift)throw Error('Сначала откройте смену');
   if(!b||b.disabled)throw Error('Оплата сейчас недоступна');
   return b.click();
  }
  if(e.key==='F8'){const bag=bagProduct();if(!bag)throw Error('Пакет «Пакет Майка» не найден в каталоге. Обновите каталог.');chooseProduct(bag.id);toast('Пакет добавлен в чек');return}
 }catch(error){toast(error.message,true)}
});
document.addEventListener('keydown',e=>{
 const slot={F1:1,F2:2,F3:3}[e.key];if(!slot||e.ctrlKey||e.altKey||e.metaKey||e.shiftKey)return;
 if(S.page!=='pos'||!$('#cartTabs'))return;e.preventDefault();
 if($('#modal')?.open||S.busy)return;
 try{switchCartSlot(slot);const input=$('#productSearch');if(input){input.value='';S.query='';productGrid();input.focus()}}catch(error){toast(error.message,true)}
});
window.addEventListener?.('help',e=>e.preventDefault());
function switchCartSlot(slot){if(!Number.isInteger(slot)||slot<1||slot>3||slot===S.cartSlot)return;if(saleAttempted)throw Error('Оплата могла пройти. Проверьте «Продажи» перед переключением чека.');if(!saveCartDraft())throw Error('Не удалось сохранить чек на этом компьютере. Переключение отменено.');S.cartSlot=slot;activeCartKey=null;restoreCartDraft(true);previousCartLength=0;cartRender()}
const manager=()=>S.boot?.user.role==='manager';
const privileged=()=>['admin','manager'].includes(S.boot?.user.role);
let toastTimer;
let toastElement;
function toast(msg,error=false){const e=$('#modal')?.open?$('#modalToast'):$('#toast');if(toastElement&&toastElement!==e)toastElement.style.display='none';e.textContent=msg;e.className=error?'error':'';e.style.display='block';toastElement=e;clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.style.display='none',6500)}
async function api(path,body,key){const options=body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-BeerDesk':'1','Idempotency-Key':key||crypto.randomUUID()},body:JSON.stringify(body)};let r;try{r=await fetch(path,options)}catch{throw Error('Нет связи с сервером. Операция не подтверждена. Проверьте журнал перед повтором.')}const data=await r.json();if(!r.ok){if(r.status===401&&S.boot){S.boot=null;S.cart=[];activeCartKey=null;$('#modal').close();await start()}const error=Error(data.error||'Не удалось выполнить операцию');error.status=r.status;throw error}return data}
function modal(title,body,foot='',actionsTop=false){S.draftOpen=false;const actions=foot?`<div class="modalfoot">${foot}</div>`:'';$('#modal').className=actionsTop?'inventory-dialog':'';$('#modalBody').innerHTML=`<div class="modalhead"><h2>${esc(title)}</h2><button class="small ghost" data-action="close" aria-label="Закрыть">✕</button></div><div id="modalToast" class="modal-toast" role="alert" aria-live="assertive"></div>${actionsTop?actions:''}<div class="modalcontent">${body}</div>${actionsTop?'':actions}`;if(!$('#modal').open)$('#modal').showModal()}
function close(){if($('#modal').className==='inventory-dialog'&&inventoryDirty&&!confirm('В пересчёте есть несохранённые количества. Закрыть без сохранения?'))return;inventoryDirty=false;$('#modal').close()}
const btn=(label,action,cls='',attrs='')=>`<button class="${cls}" data-action="${action}" ${attrs}>${label}</button>`;
const eyeIcon=(visible=false)=>`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>${visible?'<path d="m3 3 18 18"/>':''}</svg>`;
const field=(label,id,value='',type='text',extra='')=>type==='password'?`<div class="password-field"><label for="${id}">${label}</label><div class="password-control"><input id="${id}" type="password" value="${esc(value)}" ${extra}><button type="button" class="password-toggle" data-action="toggle-password" data-target="${id}" aria-controls="${id}" aria-label="Показать пароль" aria-pressed="false" title="Показать пароль">${eyeIcon()}</button></div></div>`:`<label>${label}<input id="${id}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const badge=(s,label)=>`<span class="badge ${s}">${label||statuses[s]||esc(s)}</span>`;
const opts=(items,value,label='name')=>items.map(x=>`<option value="${x.id}" ${Number(value)===x.id?'selected':''}>${esc(x[label])}</option>`).join('');
const heading=(title,sub='',actions='')=>`<div class="pagehead"><div><h1>${title}</h1><p class="muted small">${sub}</p></div><div>${actions}</div></div>`;
const empty=msg=>`<div class="empty"><div class="emptyicon">▤</div>${msg}</div>`;
function shopArgs(){return `shop_id=${S.shop}`}
// 0.5.0: окно приложения открывается с ключом (#k=…) — им подтверждаются первая настройка и ввод токена.
function appKey(){try{const m=/[#&]k=([^&]+)/.exec(window.location?.hash||'');if(m){sessionStorage.setItem('beermag:key',decodeURIComponent(m[1]));history.replaceState(null,'',location.pathname+location.search)}return sessionStorage.getItem('beermag:key')||''}catch{return ''}}
let tokenLater=false;
function tokenScreen(status,replace=false){
 const setup=status?.setup;
 const form=`<form id="tokenForm"><h1>${replace?'Новый API-токен':'Подключение к МоемуСкладу'}</h1><p class="muted small">Вставьте API-токен вашего аккаунта МойСклад. Касса сохранит его зашифрованным для этого пользователя Windows — вводить его снова не придётся.</p>${field('API-токен МоегоСклада','msToken','','password','autocomplete="off" required spellcheck="false"')}<div id="tokenError" class="negative small" role="alert"></div><button type="submit" class="blue">Проверить и подключить</button>${!setup&&!replace?'<button type="button" class="ghost" id="tokenLater">Позже</button>':''}${replace?'<button type="button" class="ghost" id="tokenCancel">Отмена</button>':''}</form><p class="muted small">Токен создаёт владелец аккаунта в МоемСкладе: настройки аккаунта → «Токены» → «Создать токен». Не пересылайте токен в чатах и почте.</p>`;
 if(replace){modal('Сменить API-токен',form)}
 else $('#app').innerHTML=`<div class="auth"><section class="authside"><div class="brand"><span class="brandmark">Б</span>БирМаг касса</div><div class="authside-copy"><span class="biglabel">ПЕРВЫЙ ЗАПУСК</span><h1>Подключим кассу<br>к МоемуСкладу</h1><p>Товары, цены, сотрудники и торговые точки загрузятся автоматически.</p></div><div class="authfooter">БирМаг · касса магазина${S.version?` · v${esc(S.version)}`:''}</div></section><section class="authform"><div class="authpanel"><div class="authlogo"><span class="brandmark">Б</span><strong>БирМаг</strong><small>КАССА</small></div>${form}</div></section></div>`;
 $('#tokenLater')?.addEventListener('click',()=>{tokenLater=true;start()});
 $('#tokenCancel')?.addEventListener('click',()=>$('#modal').close());
 $('#tokenForm').addEventListener('submit',async event=>{event.preventDefault();const button=$('#tokenForm button[type=submit]');button.disabled=true;$('#tokenError').textContent='Проверяем токен в МоемСкладе…';
  try{const r=await api('/api/moysklad/token',{token:$('#msToken').value.trim(),key:appKey()});
   if(replace){$('#modal').close();toast(r.saved?'Новый токен сохранён.':'Токен принят, но не сохранён: после перезапуска его нужно ввести снова.');S.sync=await api('/api/catalog/status');await render();if(manager())await requestSync().catch(e=>toast(e.message,true));return}
   if(!r.saved)toast('Токен принят, но не сохранён: после перезапуска его нужно ввести снова.',true);await start()}
  catch(e){$('#tokenError').textContent=e.message;button.disabled=false}});
 setTimeout(()=>$('#msToken')?.focus(),0);
}
async function start(){const status=await api('/api/status');S.demo=!!status.demo;S.version=status.version;S.moyskladReady=!!status.moysklad_ready;S.app=!!status.app;appKey();if(status.token_needed&&(status.setup||!tokenLater))return tokenScreen(status);try{if(!status.setup){S.boot=await api('/api/bootstrap');S.sync=await api('/api/catalog/status');loadCashAttempt();loadRefundAttempt();loadSaleAttempt();loadShiftAttempt();S.shop=S.saleAttempt&&S.boot.shops.some(x=>x.id===S.saleAttempt.body.shop_id)?S.saleAttempt.body.shop_id:S.boot.shop_assignment?.shop_id||0;S.cartSlot=S.saleAttempt?.slot||1;activeCartKey=null;restoreCartDraft();await render();if(S.sync.configured&&!S.sync.synced&&!S.sync.running&&manager())await requestSync();return}}catch(e){if(!e.message.includes('Войдите'))throw e}auth(status.setup)}
function auth(setup){
 const maintenance=new URLSearchParams(window.location?.search||'').has('manager-setup');
 const remote=!setup&&!S.demo&&S.moyskladReady&&!maintenance;
 const heading=setup?'Первый запуск':remote?'Вход с данными МоегоСклада':S.demo?'Вход в демо':maintenance?'Вход управляющего для настройки':'Настройка подключения';
 const intro=setup?'Создайте управляющего для первой настройки кассы.':remote?'Введите логин из карточки сотрудника МоегоСклада (например, cashier@company) и его пароль. Email для восстановления пароля может отличаться от логина.':S.demo?'Управляющий: demo / demo-manager-123 · Продавец: seller / demo-seller-123':maintenance?'Используйте пароль управляющего БирМаг, чтобы привязать его профиль МоегоСклада.':'МойСклад ещё не подключён. Войдите управляющим БирМаг для завершения настройки.';
 $('#app').innerHTML=`<div class="auth"><section class="authside"><div class="brand"><span class="brandmark">Б</span>БирМаг касса</div><div class="authside-copy"><span class="biglabel">РАБОЧЕЕ МЕСТО ПРОДАВЦА</span><h1>Касса готова<br>к вашей смене</h1><p>Товары и цены обновляются из МоегоСклада. После входа касса определит вашу торговую точку.</p></div><div class="authfooter">БирМаг · касса магазина${S.version?` · v${esc(S.version)}`:''}</div></section><section class="authform"><div class="authpanel"><div class="authlogo"><span class="brandmark">Б</span><strong>БирМаг</strong><small>КАССА</small></div><form id="authForm"><h1>${heading}</h1><p class="muted small">${intro}</p>${setup?(appKey()?'':field('Код из окна запуска','setupToken'))+field('Ваше имя','authName','Александр'):''}${field(remote?'Логин МоегоСклада':'Логин или email','authLogin',S.demo?'demo':'','text','autocomplete="username" required')}${field('Пароль','authPassword',S.demo?'demo-manager-123':'','password','autocomplete="'+(setup?'new-password':'current-password')+'" required '+(setup?'minlength="10"':''))}<div id="authError" class="negative small" role="alert"></div><button type="submit" class="blue">${setup?'Создать рабочее пространство':remote?'Войти с данными МоегоСклада':'Войти'}</button></form>${setup?`<p class="muted small">${appKey()?'Это будет вход управляющего этой кассы.':'Код указан в окне запуска.'} Пароль — не менее 10 символов.</p>`:''}</div></section></div>`;
 async function sendAuth(path,payload,button){button.disabled=true;try{const loginResult=await api(path,payload);S.boot=await api('/api/bootstrap');S.sync=await api('/api/catalog/status');loadCashAttempt();loadRefundAttempt();loadSaleAttempt();loadShiftAttempt();S.shop=S.saleAttempt&&S.boot.shops.some(x=>x.id===S.saleAttempt.body.shop_id)?S.saleAttempt.body.shop_id:S.boot.shop_assignment?.shop_id||0;S.cartSlot=S.saleAttempt?.slot||1;activeCartKey=null;restoreCartDraft();await render();if(loginResult.offline)toast("Работа без интернета: продажи сохраняются в кассе и будут переданы после восстановления связи.");if(S.sync.configured&&!S.sync.synced&&!S.sync.running&&manager())await requestSync()}catch(error){const target=$('#authError');if(target)target.textContent=error.message;else toast(error.message,true);button.disabled=false}}
 $('#authForm').addEventListener('submit',async event=>{event.preventDefault();const button=event.submitter||$('#authForm button[type=submit]');const payload={login:$('#authLogin').value,password:$('#authPassword').value};if(setup)Object.assign(payload,{name:$('#authName').value,token:appKey()||$('#setupToken')?.value||''});await sendAuth(setup?'/api/setup':remote?'/api/login/moysklad':'/api/login',payload,button)});
}
async function refreshBoot(){saveCartDraft();S.boot=await api('/api/bootstrap');const assigned=S.boot.shop_assignment?.shop_id||0;const selected=privileged()&&S.boot.shops.some(s=>s.id===S.shop)?S.shop:assigned;if(S.shop!==selected){S.shop=selected;S.cartSlot=1;activeCartKey=null;restoreCartDraft()}else if(S.cart.length){activeCartKey=null;restoreCartDraft()}if(!privileged()&&['stock','summary'].includes(S.page))S.page='pos';if(!manager()&&['settings','users','audit','moysklad'].includes(S.page))S.page='pos'}
async function render(){
 if(!S.boot)return;
 const integrated=(S.boot.moysklad||S.sync?.configured)&&!S.boot.demo;
 // Касса — рабочее место продавца. Справочники, сотрудники, остатки, отчёты и
 // решения по инвентаризации ведутся в МоемСкладе; здесь только настройка самой кассы.
 const cashNav=[['pos','Касса','▦'],['shift','Смена','₽'],['sales','Продажи','≡'],['inventory','Инвентаризация','✓'],['shifts','История смен','☰']];
 const legacyNav=[];
 const manageNav=manager()&&!S.boot.demo?[['moysklad','Настройка кассы','⚙']]:[];
 const navButtons=items=>items.map(([id,name,symbol])=>btn(`<span class="symbol">${symbol}</span>${name}`,'nav',S.page===id||S.page==='count'&&id==='inventory'?'active':'',`data-page="${id}"`)).join('');
 const shop=S.boot.shops.find(x=>x.id===S.shop);
 const management=manageNav.length?`<details class="admin-nav" ${manageNav.some(([id])=>S.page===id)?'open':''}><summary>Служебное</summary><nav class="nav">${navButtons(manageNav)}</nav></details>`:'';
 const upd=S.boot.update?.ready?`<div class="notice ok"><strong>Загружено обновление кассы ${esc(S.boot.update.ready)}.</strong> ${S.boot.update.open_shift?'Оно установится автоматически при следующем запуске кассы после закрытия смены.':'Можно установить сейчас — касса перезапустится примерно за полминуты.'} ${!S.boot.update.open_shift?btn('Обновить сейчас','update-restart','small primary'):''}</div>`:'';
 const notice=upd+(S.boot.demo?'<div class="notice amber"><strong>Учебный режим.</strong> Все операции остаются в отдельной демо базе.</div>':integrated&&S.boot.moysklad&&!S.boot.sales_enabled&&manager()?'<div class="notice amber">Каталог загружен. Продавец может открыть смену; с этого момента операции передаются в МойСклад.</div>':'');
 $('#app').innerHTML=`<div class="layout"><aside class="sidebar"><div class="brand"><span class="brandmark">Б</span>БирМаг касса</div><div class="caption">Магазин</div><nav class="nav">${navButtons([...cashNav,...legacyNav])}</nav>${management}<div class="account"><strong>${esc(S.boot.user.name)}</strong><div class="role">${roles[S.boot.user.role]}</div>${btn('Выйти','logout','small')}${btn(document.documentElement?.dataset?.theme==='dark'?'☀ Светлая тема':'☾ Тёмная тема','theme-toggle','small theme-toggle')}<div class="app-version">Версия ${esc(S.boot.version||S.version||'—')}</div></div></aside><main class="main"><header class="topbar"><div class="topinfo">${integrated&&!privileged()?`<strong>${esc(shop?.name||'Точка не определена')}</strong>`:`<select id="shopSelect" aria-label="Магазин">${opts(S.boot.shops,S.shop)}</select>`}<span class="muted small">${esc(shop?.organization||'')}</span></div><div class="topinfo">${S.boot.demo?'<span class="badge">ДЕМО</span>':''}<span id="queueStatus" class="muted small"></span><span id="lastRemoteStatus" class="muted small"></span><span class="badge">${roles[S.boot.user.role]}</span>${integrated?btn('↻ Синхронизировать','sync-catalog','primary'):btn('Обновить','refresh','small')}</div></header><div class="content"><div id="syncPanel" role="status" aria-live="polite"></div><div id="deliveryPanel" role="status" aria-live="polite"></div><div id="backupPanel" role="status" aria-live="polite"></div><div id="saleRecoveryPanel" role="status" aria-live="polite"></div><div id="cashRecoveryPanel" role="status" aria-live="polite"></div><div id="refundRecoveryPanel" role="status" aria-live="polite"></div><div id="shiftRecoveryPanel" role="status" aria-live="polite"></div>${notice}<div id="content"></div></div></main></div>`;
 updateSyncPanel();
 updateSaleRecovery();
 updateCashRecovery();
 updateRefundRecovery();
 updateShiftRecovery();
 refreshDelivery();
 await page();
}
function updateSyncPanel(){
 const panel=$('#syncPanel');if(!panel||!S.sync)return;
 const st=S.sync;
 if(st.running)panel.innerHTML=`<div class="sync-panel"><span class="sync-spinner" aria-hidden="true"></span><div><strong>Загружаем данные из МоегоСклада</strong><p>${esc(st.stage||'Подключаемся…')}</p></div></div>`;
 else if(st.error)panel.innerHTML=`<div class="notice error"><strong>Загрузка не завершена.</strong> ${esc(st.error)} ${S.boot?.catalog_synced?'Доступна предыдущая версия каталога.':''}</div>`;
 else if(st.warning)panel.innerHTML=`<div class="notice amber"><strong>Каталог обновлён не полностью.</strong> ${esc(st.warning)}</div>`;
 else if(st.configured&&!S.boot?.catalog_synced)panel.innerHTML='<div class="notice amber">Каталог ещё не загружен. Загрузка начнётся автоматически; состояние появится здесь.</div>';
 else if(!st.configured&&S.boot?.moysklad)panel.innerHTML='<div class="notice amber">Нет API-токена МоегоСклада. Работает последний сохранённый каталог; новые цены пока недоступны.</div>';
 else panel.innerHTML='';
 const button=$('[data-action="sync-catalog"]');if(button)button.disabled=!!st.running;
}
async function requestSync(){
 const result=await api('/api/moysklad/start',{});
 S.sync={...S.sync,...result};updateSyncPanel();
}
async function pollSync(){
 try{
  if(S.boot&&!S.demo){
   const current=await api('/api/catalog/status');
   const changed=!!current.synced&&current.synced!==S.boot.catalog_synced;
   S.sync=current;
   if(changed){await refreshBoot();await render();toast('Товары и цены обновлены. Проверьте незавершённый чек.')}
   else updateSyncPanel();
  }
 }catch{}finally{setTimeout(pollSync,S.sync?.running?1500:10000)}
}
async function page(){if(S.page==='moysklad'&&manager())return moyskladPage();if(!S.shop){$('#content').innerHTML=empty(esc(S.boot.shop_assignment?.reason||'Нет доступных магазинов. Обратитесь к управляющему.'));return}switch(S.page){case'pos':return pos();case'shift':return shiftPage();case'count':return countPage();case'shifts':return shiftsReport();case'sales':return documents('sale');case'receipts':return documents('receipt');case'inventory':return documents('inventory');case'stock':return stocks();case'summary':return summary();case'settings':return settings()}}
function otherShiftsNotice(){
 const others=S.shift?.others||[];if(!others.length)return '';
 return others.map(x=>`<div class="notice amber"><strong>В магазине открыта смена № ${x.id}</strong> — ${esc(x.user_name)}, с ${date(x.opened)}. ${S.boot.moysklad?'Пока она открыта, новую смену начать нельзя. ':''}Пересчитайте деньги и закройте её. ${btn('Закрыть смену № '+x.id,'shift-close','small primary',`data-shift="${x.id}"`)}</div>`).join('');
}
function shiftNotice(){
 if(S.shift?.others?.length)return otherShiftsNotice();
 if(S.boot.moysklad&&!S.boot.sales_enabled)return '<div class="notice amber">Откройте смену сами. При первом открытии касса начнёт передачу реальных операций в МойСклад. До открытия смены оплата недоступна.</div>';
 return '<div class="notice amber">Смена закрыта. Товары можно подобрать, оплата станет доступна после открытия смены.</div>';
}
async function pos(){S.shift=await api('/api/shift?'+shopArgs());$('#content').innerHTML=heading('Касса',S.shift.shift?`Смена № ${S.shift.shift.id} · открыта ${date(S.shift.shift.opened)}`:'Откройте смену, чтобы начать продажи',S.shift.shift?btn('Смена и наличные','shift-page','small'):(S.shift.last_closed?btn('Итоги смены № '+S.shift.last_closed.id,'shift-page','small'):'')+btn('Открыть смену','shift-open','primary'))+(!S.shift.shift?shiftNotice():'')+`<div class="pos"><section><div class="toolbar"><input id="productSearch" placeholder="F4 · Название или штрихкод · Enter — добавить · F8 — пакет" aria-label="Поиск товара" value="${esc(S.query)}"></div><div id="catalogNavigation" class="catalog-navigation"></div><div class="products" id="productGrid"></div></section><aside class="cart"><div class="cart-tabs" id="cartTabs" role="tablist" aria-label="Чеки клиентов">${cartSlots()}</div><div class="carthead"><h2 id="cartTitle">Чек ${S.cartSlot}</h2>${btn('Очистить','cart-clear','small ghost')}</div><div class="cartlines" id="cartLines" tabindex="0" role="region" aria-label="Товары в чеке"></div><div class="cartfoot" id="cartFoot"></div></aside></div>`;productGrid();cartRender()}
function shiftLinesHtml(t){
 return `<div class="shift-line"><strong>Продажи · ${t.count}</strong><strong>${money(t.cash+t.card+t.refund_cash+t.refund_card)}</strong></div><div class="shift-sub"><span>Наличными</span><span>${money(t.cash+t.refund_cash)}</span></div><div class="shift-sub"><span>Безналичными</span><span>${money(t.card+t.refund_card)}</span></div><div class="shift-line"><strong>Возвраты · ${t.refund_count}</strong><strong>${money(t.refund_cash+t.refund_card)}</strong></div><div class="shift-line"><strong>Внесения</strong><strong>${money(t.cash_in)}</strong></div><div class="shift-line"><strong>Выплаты</strong><strong>${money(t.cash_out)}</strong></div>`;
}
function shiftMovementsHtml(title,list,none){
 return `<div class="panel"><h2>${title}</h2>${list.length?`<div class="tablewrap"><table><thead><tr><th>Когда</th><th>Операция</th><th>Причина</th><th class="num">Сумма</th><th>Передача</th></tr></thead><tbody>${list.map(x=>`<tr><td>${date(x.created)}</td><td>${x.kind==='in'?'Внесение':'Выплата'}</td><td>${esc(x.note||'—')}</td><td class="num">${money(x.amount)}</td><td>${x.sync_status?syncLabel(x.sync_status):'Локально'}</td></tr>`).join('')}</tbody></table></div>`:empty(none)}</div>`;
}
// 0.5.4: после закрытия итоги смены остаются на экране (продавцы их фотографируют) до открытия следующей смены.
function closedShiftHtml(x){
 const t=x.totals,shop=S.boot.shops?.find(s=>s.id===x.shop_id);
 const expected=x.expected_cash??t.cash_on_hand;
 const diff=x.difference==null?'<span class="muted">—</span>':x.difference===0?'<span class="ok-text">сходится</span>':`<span class="${x.difference<0?'bad-text':'warn-text'}">${x.difference<0?'Недостача −':'Излишек +'}${money(Math.abs(x.difference))}</span>`;
 const closer=x.closed_by&&x.closed_by!==x.user_id&&x.closed_by_name?` · закрыл(а) ${esc(x.closed_by_name)}`:'';
 return `<div class="panel shift-panel shift-closed" id="closedShift"><div class="shift-closed-head"><div><h2>Итоги смены № ${x.id}</h2><p class="muted small">${esc(shop?.name||'')}${shop?' · ':''}${esc(x.user_name||'—')}${closer}</p><p class="muted small">Открыта ${date(x.opened)} · закрыта ${date(x.closed)}</p></div><span class="shift-closed-badge">Закрыта</span></div>`+
 shiftLinesHtml(t)+
 `<div class="shift-line"><strong>Должно быть в кассе</strong><strong>${money(expected)}</strong></div><div class="shift-line"><strong>Посчитано при закрытии</strong><strong>${x.closing_cash==null?'—':money(x.closing_cash)}</strong></div><div class="shift-line shift-total"><strong>Разница</strong><strong>${diff}</strong></div></div>`+
 shiftMovementsHtml(`Операции с наличными за смену № ${x.id}`,x.movements||[],'Операций с наличными не было');
}
async function shiftPage(){
 S.shift=await api('/api/shift?'+shopArgs());const r=S.shift.shift,t=S.shift.totals,last=!r&&S.shift.last_closed;
 $('#content').innerHTML=heading('Смена',r?`Открыта ${date(r.opened)} · № ${r.id}`:last?`Смена № ${last.id} закрыта ${date(last.closed)} · итоги видны до открытия новой смены`:'Смена закрыта',btn(r?'Закрыть смену':'Открыть смену',r?'shift-close':'shift-open','primary'))+(!r?shiftNotice():'')+
 (r?`<div class="panel shift-panel">${shiftLinesHtml(t)}<div class="shift-line shift-total"><strong>Денег в кассе</strong><strong>${money(t.cash_on_hand)}</strong></div><div class="shift-actions">${btn('Внести деньги','cash-in','primary')}${btn('Выдать деньги','cash-out','blue')}</div></div>`+shiftMovementsHtml('Операции с наличными',S.shift.movements,'Операций с наличными пока нет'):last?closedShiftHtml(last):'');
}
async function shiftsReport(){
 const list=await api('/api/shifts?'+shopArgs()+'&limit=90');const shop=S.boot.shops.find(x=>x.id===S.shop);
 const diff=x=>x.difference==null?'<span class="muted">—</span>':x.difference===0?'<span class="ok-text">сходится</span>':`<strong class="${x.difference<0?'bad-text':'warn-text'}">${x.difference<0?'−':'+'}${money(Math.abs(x.difference))}</strong>`;
 const closedShortage=list.filter(x=>x.difference<0).reduce((a,x)=>a+x.difference,0);
 $('#content').innerHTML=heading(privileged()?'Отчёт по сменам':'Мои смены',esc(shop?.name||'')+' · последние '+list.length+' смен',btn('Напечатать','shifts-print','small'))+
 (privileged()&&closedShortage?`<div class="notice error">Недостача за показанные смены: <strong>${money(-closedShortage)}</strong></div>`:'')+
 (list.length?`<div class="panel tablewrap compact-table" id="shiftsTable"><table><thead><tr><th>№</th><th>Продавец</th><th>Время</th><th class="num">Чеков</th><th class="num">Нал / безнал</th><th class="num">Возвраты</th><th class="num">Внесено / выдано</th><th class="num">Должно быть</th><th class="num">Посчитано</th><th class="num">Разница</th></tr></thead><tbody>${list.map(x=>{const t=x.totals;return `<tr><td>${x.id}</td><td>${esc(x.user_name||'—')}${x.closed_by&&x.closed_by!==x.user_id?`<div class="muted small">закрыл(а) ${esc(x.closed_by_name||'')}</div>`:''}</td><td>${shortDate(x.opened)}<div class="muted small">${x.closed?'до '+shortDate(x.closed):'открыта'}</div></td><td class="num">${t.count}</td><td class="num">${money(t.cash+t.refund_cash)}<div class="muted small">${money(t.card+t.refund_card)}</div></td><td class="num">${t.refund_count?money(t.refund_cash+t.refund_card):'—'}</td><td class="num">${money(t.cash_in)}<div class="muted small">${money(t.cash_out)}</div></td><td class="num">${x.closed?(x.expected_cash==null?'—':money(x.expected_cash)):money(t.cash_on_hand)}</td><td class="num">${x.closed&&x.closing_cash!=null?money(x.closing_cash):'—'}</td><td class="num">${x.closed?diff(x):'—'}</td></tr>`}).join('')}</tbody></table></div>`:empty('Смен пока нет'));
}
function folderTree(available){
    const folders=new Map(),byPath=new Map();
    for(const g of S.boot.groups||[]){
        const id=String(g.id||'path:'+g.path);
        folders.set(id,{id,name:g.name,path:g.path,parent:String(g.parent_id||'')});
        byPath.set(g.path,id);
    }
    // Old local catalogues and imported files may only have a path, without folder UUIDs.
    for(const path of [...folders.values()].map(g=>g.path).concat(available.map(p=>p.category||''))){
        if(!path)continue;
        const parts=path.split('/');let prefix='';
        for(const part of parts){prefix=prefix?prefix+'/'+part:part;
            if(!byPath.has(prefix)){const id='path:'+prefix;byPath.set(prefix,id);folders.set(id,{id,name:part,path:prefix,parent:''})}
        }
    }
    for(const f of folders.values()){
        if(!f.parent||!folders.has(f.parent))f.parent=byPath.get(f.path.slice(0,f.path.lastIndexOf('/')))||'';
    }
    const productFolder=p=>folders.has(p.source_folder_uuid)?p.source_folder_uuid:(byPath.get(p.category||'')||'');
    return {folders,productFolder};
}
// 0.5.2: плитки групп — графитовые «клавиши»; у каждой группы свой постоянный цвет метки.
const BUBBLE_HUES=[145,355,28,205,268,172,44,322,95,12];
function bubbleHue(name){let h=0;for(const ch of String(name||''))h=(h*31+ch.codePointAt(0))>>>0;return BUBBLE_HUES[h%BUBBLE_HUES.length]}
function groupCount(id,available,folders,productFolder){
    let n=0;for(const p of available){let f=productFolder(p),guard=0;if(id===''){if(!f)n++;continue}
        while(f&&guard++<50){if(f===id){n++;break}f=folders.get(f)?.parent||''}}
    return n+' '+(n%10===1&&n%100!==11?'товар':n%10>=2&&n%10<=4&&(n%100<10||n%100>=20)?'товара':'товаров');
}
const PRODUCT_LIMIT=240;
function productGrid(){
    const available=S.boot.products.filter(p=>p.active&&p.packaging_enabled!==false);
    const {folders,productFolder}=folderTree(available);
    if(S.group!==null&&S.group!==''&&!folders.has(S.group))S.group=null;
    const query=S.query.trim().toLocaleLowerCase('ru-RU');
    const browsing=!query&&S.catalogView==='groups';
    const root=browsing&&S.group===null;
    const current=folders.get(S.group);
    const nav=$('#catalogNavigation'),grid=$('#productGrid');
    let crumbs='';if(current){let cursor=current,seen=new Set();const steps=[];
        while(cursor&&!seen.has(cursor.id)){seen.add(cursor.id);steps.unshift(cursor);cursor=folders.get(cursor.parent)}
        crumbs=steps.map((f,i)=>i===steps.length-1?esc(f.name):`<button class="small ghost" data-action="catalog-group" data-group="${esc(f.id)}">${esc(f.name)}</button>`).join(' / ');
    }
    nav.innerHTML=btn('▦ Группы','catalog-home',root?'active':'')+' '+btn('Все товары','catalog-all',!query&&S.catalogView==='all'?'active':'')+
      (browsing&&S.group!==null?btn('← Назад','catalog-up','small'):'')+
      `<span class="catalog-location">${query?'Поиск по всему каталогу':S.group===''?'Без группы':current?crumbs:root?'Выберите группу':'Все товары'}</span>`+
      (query?btn('Очистить поиск','catalog-clear','small'):'');
    // Hide groups without sellable goods (empty or archived-only folders).
    const filled=new Set();for(const p of available){let id=productFolder(p),guard=0;while(id&&!filled.has(id)&&guard++<50){filled.add(id);id=folders.get(id)?.parent||''}}
    const tiles=browsing&&S.group!==''?[...folders.values()].filter(f=>f.parent===(S.group||'')&&filled.has(f.id)).sort((a,b)=>a.name.localeCompare(b.name,'ru')):[];
    const ps=available.filter(p=>query?
      matchWords(query,[p.name,p.barcode,p.source_code,...(p.barcodes||[])]):
      S.catalogView==='all'||(S.group===''?!productFolder(p):S.group!==null&&productFolder(p)===S.group));
    if(root&&available.some(p=>!productFolder(p)))tiles.push({id:'',name:'Без группы'});
    grid.className=tiles.length?'products group-tiles':'products';
    grid.innerHTML=tiles.map(f=>`<button class="group-tile" style="--hue:${bubbleHue(f.name)}" data-action="catalog-group" data-group="${esc(f.id)}"><strong>${esc(f.name)}</strong><span class="group-count">${groupCount(f.id,available,folders,productFolder)}</span></button>`).join('')+
      (!root?ps.slice(0,PRODUCT_LIMIT).map(p=>`<button class="product" data-action="product" data-id="${p.id}"><span class="kind">${p.kind==='draft'?'На розлив':p.kind==='weight'?'На вес':'За штуку'}</span><strong>${esc(p.name)}</strong>${query?`<span class="muted small">${esc(p.category||'Без группы')}</span>`:''}<span class="price">${money(p.price)} <span class="unit">/ ${unit(p.kind)}</span></span></button>`).join(''):'')||
      empty(query?'Товаров не найдено':root?'Нет доступных товаров. Загрузите каталог из МоегоСклада.':'В этой группе нет доступных товаров');
    if(!root&&ps.length>PRODUCT_LIMIT)grid.insertAdjacentHTML('beforeend',`<div class="notice more-results">Показаны первые ${PRODUCT_LIMIT} из ${ps.length}. Уточните поиск или выберите группу.</div>`);
}
function lineTotal(x){const p=S.boot.products.find(p=>p.id===x.product_id);const total=Math.round(p.price*x.qty);if(p.kind!=='draft')return total;const pack=S.boot.products.find(p=>p.id===x.packaging_id);return total+(pack?.price||0)*x.count}
function cartTotal(){return S.cart.reduce((a,x)=>a+lineTotal(x),0)}
function cartRender(){saveCartDraft();if(!$('#cartLines'))return;$('#cartTabs').innerHTML=cartSlots();$('#cartTitle').textContent='Чек '+S.cartSlot;$('#cartLines').innerHTML=S.cart.length?S.cart.map((x,i)=>{const p=S.boot.products.find(p=>p.id===x.product_id);const pack=p.kind==='draft'?S.boot.products.find(p=>p.id===x.packaging_id):null;return `<div class="cartline"><div class="cartrow"><strong>${esc(p.name)}</strong><strong>${money(lineTotal(x))}</strong></div><div class="cartsub">${p.kind==='draft'?`${x.count} × ${x.volume} л · ${money(p.price)} / л<br>+ ${esc(pack?.name||'Тара не настроена')} × ${x.count}`:`${x.qty} ${unit(p.kind)} × ${money(p.price)}`}</div><div class="stepper">${btn('−','cart-minus','small',`data-id="${i}"`)}<span>${p.kind==='draft'?x.count:x.qty}</span>${btn('+','cart-plus','small',`data-id="${i}"`)}${btn('Удалить','cart-remove','small remove',`data-id="${i}"`)}</div></div>`}).join(''):empty('Добавьте напиток, закуску или тару.<br>К напитку тара добавится автоматически.');$('#cartFoot').innerHTML=`<div class="carttotal"><span>К оплате</span><strong>${money(cartTotal())}</strong></div><div class="payments">${btn('Наличные <span class="fkey">F5</span>','pay-cash','primary',S.cart.length&&S.shift.shift&&(!S.boot.moysklad||S.boot.sales_enabled)?'':'disabled')}${btn('Безналичные <span class="fkey">F6</span>','pay-card','blue',S.cart.length&&S.shift.shift&&(!S.boot.moysklad||S.boot.sales_enabled)?'':'disabled')}</div>${btn('Сложная оплата <span class="fkey">F7</span>','pay-mixed','mixed-pay',S.cart.length&&S.shift.shift&&(!S.boot.moysklad||S.boot.sales_enabled)?'':'disabled')}<div class="statusbar">Незавершённый чек сохраняется на этом компьютере · Печать после оплаты</div>`;const added=S.cart.length>previousCartLength;previousCartLength=S.cart.length;requestAnimationFrame(()=>resizeCart(added))}
function chooseProduct(id){if(saleAttempted)throw Error('Оплата могла пройти. Нажмите «Проверить продажу» в предупреждении кассы.');const p=S.boot.products.find(x=>x.id===Number(id));if(!p||!p.active||p.packaging_enabled===false)return;if(p.kind==='piece'||p.kind==='packaging'){const same=S.cart.find(x=>x.product_id===p.id&&!x.volume);if(same)same.qty+=1;else S.cart.push({product_id:p.id,qty:1});return cartRender()}S.selection={product_id:p.id,volume:enabledPacks().some(r=>r.volume===1000)?1:(enabledPacks()[0]?.volume||1000)/1000,count:1};if(p.kind==='draft'){modal(p.name,`<div class="muted">${money(p.price)} / л · тара оплачивается отдельно</div><div class="draft-keys"><span><span class="fkey">←</span><span class="fkey">→</span> объём</span><span><span class="fkey">↑</span><span class="fkey">↓</span> тара</span><span><span class="fkey">+</span><span class="fkey">−</span> порции</span><span><span class="fkey">Enter</span> добавить</span></div><div class="volumes">${[...new Set(enabledPacks().map(r=>r.volume/1000))].sort((a,b)=>a-b).map(v=>btn(v+' л','volume',v===S.selection.volume?'active':'',`data-value="${v}"`)).join('')}</div><label class="portion-label" for="bottleCount">Количество порций</label><div class="portion-picker"><button type="button" data-action="portion-minus" aria-label="Уменьшить количество порций">−</button><input id="bottleCount" type="number" min="1" max="1000" step="1" value="1" inputmode="numeric" aria-label="Количество порций"><button type="button" data-action="portion-plus" aria-label="Увеличить количество порций">+</button></div><div class="notice" id="packNotice" style="margin-top:18px"></div>`,btn('Добавить в покупку','add-draft','primary'));S.draftOpen=true;packNotice();(typeof requestAnimationFrame==='function'?requestAnimationFrame:setTimeout)(()=>{const c=$('#bottleCount');c?.focus?.();c?.select?.()})}else{modal(p.name,field('Вес, кг','weightQty','0.','text','inputmode="decimal" autocomplete="off" spellcheck="false"'),btn('Добавить','add-weight','primary'));requestAnimationFrame(()=>{const input=$('#weightQty');if(input){input.focus();input.setSelectionRange(2,2)}})}}
function enabledPacks(){return S.boot.packaging.filter(r=>r.enabled&&S.boot.products.some(p=>p.id===r.product_id&&p.active))}
function packNotice(){
    const choices=enabledPacks().filter(r=>r.volume===S.selection.volume*1000);
    if(!choices.some(r=>r.product_id===S.selection.packaging_id))S.selection.packaging_id=(choices.find(r=>r.slot.startsWith('bottle-'))||choices[0])?.product_id;
    $('#packNotice').innerHTML=choices.length?`<label>Тара для напитка<select id="drinkPackaging">${choices.map(r=>{const p=S.boot.products.find(p=>p.id===r.product_id);return `<option value="${p.id}" ${p.id===S.selection.packaging_id?'selected':''}>${esc(r.label)} · ${esc(p.name)} · ${money(p.price)}</option>`}).join('')}</select></label>`:'Нет включённой тары для этого объёма. Обратитесь к управляющему.';
}
function payment(type){if(saleAttempted)throw Error('Оплата могла пройти. Нажмите «Проверить продажу» в предупреждении кассы.');S.paymentKey=crypto.randomUUID();const total=cartTotal();S.payTotal=total;if(type==='mixed')return mixedPayment(total);modal(type==='cash'?'Оплата наличными':'Оплата банковским терминалом',`<div class="carttotal"><span>К оплате</span><strong>${money(total)}</strong></div>${type==='cash'?field('Получено от покупателя, ₽','cashReceived',(total/100).toFixed(2),'number','min="0" step="0.01" inputmode="decimal"')+`<div class="quick-cash">${quickCash(total).map(v=>btn(money(v*100),'cash-quick','small',`data-value="${v}"`)).join('')}</div><div id="changeInfo" class="change-info"></div>`:'<div class="notice amber">Проведите оплату на отдельном терминале. Нажмите «Оплата получена» только после успешной оплаты.</div>'}`,btn('Отмена','close')+btn(type==='cash'?'Завершить продажу':'Оплата получена','pay-confirm','primary',`data-type="${type}"`));requestAnimationFrame(()=>{const input=type==='cash'?$('#cashReceived'):$('#modal [data-action="pay-confirm"]');input?.focus?.();if(type==='cash'){input?.select?.();changeRefresh()}})}
// Сложная оплата: часть наличными, остаток — картой на терминале.
function mixedPayment(total){
 modal('Сложная оплата',`<div class="carttotal"><span>К оплате</span><strong>${money(total)}</strong></div><div class="mixed-grid">${field('Наличными, ₽','mixCash','','number','min="0" step="0.01" inputmode="decimal" placeholder="0,00"')}${field('Картой, ₽','mixCard','','number','min="0" step="0.01" inputmode="decimal" placeholder="0,00"')}</div><div id="mixInfo" class="change-info"></div><div class="notice amber">Сначала проведите картой сумму «Картой» на терминале, затем примите наличные. Нажмите «Оплата получена» только после успешной оплаты картой.</div>`,btn('Отмена','close')+btn('Оплата получена','pay-confirm','primary','data-type="mixed" disabled'));
 (typeof requestAnimationFrame==='function'?requestAnimationFrame:setTimeout)(()=>{$('#mixCash')?.focus?.();mixRefresh()});
}
function mixRefresh(source){
 const total=cartTotal(),cashInput=$('#mixCash'),cardInput=$('#mixCard'),info=$('#mixInfo'),ok=$('#modal [data-action="pay-confirm"]');if(!cashInput||!cardInput||!info)return;
 const read=x=>{const raw=String(x.value??'').trim().replace(',','.');return raw===''?NaN:Math.round(Number(raw)*100)};
 if(source==='mixCash'){const c=read(cashInput);cardInput.value=Number.isFinite(c)&&c>=0&&c<=total?((total-c)/100).toFixed(2):''}
 if(source==='mixCard'){const k=read(cardInput);cashInput.value=Number.isFinite(k)&&k>=0&&k<=total?((total-k)/100).toFixed(2):''}
 const cash=read(cashInput),card=read(cardInput);
 const valid=Number.isFinite(cash)&&Number.isFinite(card)&&cash>0&&card>0&&cash+card===total;
 info.className='change-info'+(valid?'':' error');
 info.innerHTML=valid?`Наличными <strong>${money(cash)}</strong> + картой <strong>${money(card)}</strong>`:Number.isFinite(cash)&&(cash<=0||cash>=total)?'Для оплаты одним способом используйте F5 или F6':'Введите сумму наличными — остаток пойдёт на карту';
 if(ok)ok.disabled=!valid;
}
function quickCash(total){const rub=Math.ceil(total/100),out=[];for(const note of [100,500,1000,2000,5000]){const v=Math.ceil(rub/note)*note;if(v>rub&&!out.includes(v))out.push(v)}return out.slice(0,4)}
function changeRefresh(){
 const input=$('#cashReceived'),info=$('#changeInfo'),confirmButton=$('#modal [data-action="pay-confirm"]');if(!input||!info)return;
 const total=cartTotal(),raw=String(input.value??'').trim().replace(',','.'),received=raw===''?NaN:Math.round(Number(raw)*100);
 if(!Number.isFinite(received)){info.className='change-info error';info.textContent='Введите полученную сумму';if(confirmButton)confirmButton.disabled=true;return}
 if(received<total){info.className='change-info error';info.textContent='Не хватает '+money(total-received);if(confirmButton)confirmButton.disabled=true;return}
 info.className='change-info';info.innerHTML='Сдача: <strong>'+money(received-total)+'</strong>';if(confirmButton)confirmButton.disabled=false;
}
async function documents(type){S.docs=await api('/api/documents?'+shopArgs()+'&type='+type);let title={sale:'Продажи',receipt:'Приход товара',inventory:'Инвентаризации'}[type];let sub={sale:'Завершённые покупки и способ оплаты',receipt:'Черновики не меняют остатки. «Отправить» проводит накладную.',inventory:'Пересчёт можно начать в любой день.'}[type];let actions=type==='receipt'?btn('＋ Новая накладная','receipt-new','primary'):type==='inventory'?btn('＋ Начать пересчёт','inventory-new','primary'):'';const blocker=type==='inventory'?S.docs.find(r=>['draft','submitted','adjusting'].includes(r.status)):null;const inventoryNotice=blocker?`<div class="notice amber">${blocker.status==='draft'?`Идёт пересчёт № ${blocker.id}. Продолжите его или отмените.`:`Пересчёт № ${blocker.id} ещё передаётся в МойСклад. Новый пересчёт можно начать после передачи.`} ${btn(blocker.status==='draft'?'Продолжить пересчёт':'Открыть','doc-open','small primary',`data-id="${blocker.id}"`)}${blocker.status==='draft'&&(manager()||blocker.author===S.boot.user.id)?' '+btn('Отменить пересчёт','count-cancel-list','small danger',`data-id="${blocker.id}"`):''}</div>`:'';$('#content').innerHTML=heading(title,sub,actions)+inventoryNotice+(type==='sale'?'<div class="toolbar"><input id="saleSearch" placeholder="Номер, товар или сумма" aria-label="Найти продажу для возврата"></div>':'')+(S.docs.length?`<div class="tablewrap"><table><thead><tr><th>Документ</th><th>Дата</th><th>${type==='receipt'?'Поставщик':'Сотрудник'}</th><th>Статус</th>${type!=='inventory'?'<th class="num">Сумма</th>':''}<th></th></tr></thead><tbody>${S.docs.map(r=>`<tr ${type==='sale'?`class="sale-row" data-search="${esc(('#'+r.id+' '+r.body.lines.map(l=>l.name).join(' ')+' '+(r.body.total/100).toFixed(2)).toLocaleLowerCase('ru-RU'))}"`:''}><td><strong>${type==='receipt'?esc(r.body.number):'#'+r.id}</strong>${type==='sale'?`<div class="muted small">${payLabel(r.body)}</div>`:''}</td><td>${date(r.created)}</td><td>${esc(type==='receipt'?r.body.supplier.name:r.author_name)}</td><td>${badge(r.status,type==='inventory'&&r.status==='draft'?'В работе':undefined)}${type==='sale'&&r.return_count?'<div class="small">'+(r.status==='refunded'?'Возвращён весь чек':'Частичный возврат · '+r.return_count)+'</div>':''}${r.sync_status?'<div class="small">'+(type==='inventory'?'Инвентаризация':'Продажа')+': '+syncLabel(r.sync_status)+'</div>':''}${r.refund_sync_status?'<div class="small">Возврат: '+syncLabel(r.refund_sync_status)+'</div>':''}</td>${type!=='inventory'?`<td class="num">${money(r.body.total)}</td>`:''}<td class="right">${btn('Открыть','doc-open','small',`data-id="${r.id}"`)}</td></tr>`).join('')}</tbody></table></div>`:empty(type==='receipt'?'Накладных пока нет':type==='inventory'?'Пересчётов пока нет':'Продаж пока нет'))+'<div class="statusbar">Показаны последние 300 документов</div>'}
async function openDoc(id){const r=await api('/api/document?'+shopArgs()+'&id='+id);if(r.type==='receipt')return receiptForm(r);if(r.type==='inventory')return r.status==='draft'?openCount(r.id):inventoryForm(r);saleView(r)}
function saleView(r){S.last=r;const remaining=r.remaining||r.body.lines.map(x=>x.qty);const history=(r.returns||[]).map(x=>`<div class="notice">Возврат № ${x.id} · ${date(x.created)} · ${money(x.body.total)}${x.body.payment==='mixed'?` (нал. ${money(x.body.cash_amount)}, на карту ${money(x.body.card_amount)})`:''}${x.sync_status?' · '+syncLabel(x.sync_status):''}<br>${x.body.lines.map(line=>esc(line.name)+' — '+qty(line.qty)+' '+unit(line.kind)).join('; ')}</div>`).join('');modal('Покупка № '+r.id,`<p class="muted">${date(r.created)} · ${payLabel(r.body)} · ${statuses[r.status]}</p>${r.sync_status?'<div class="notice">Продажа: '+syncLabel(r.sync_status)+'</div>':''}${r.refund_sync_status?'<div class="notice">Возврат: '+syncLabel(r.refund_sync_status)+'</div>':''}${saleTable(r)}<div class="carttotal" style="margin-top:20px"><span>Итого</span><strong>${money(r.body.total)}</strong></div>${r.body.payment==='cash'?`<p>Получено: ${money(r.body.received)} · Сдача: ${money(r.body.change)}</p>`:''}${history}<p class="muted small">Нефискальный документ о покупке</p>`,btn('Напечатать','print')+(r.status==='posted'&&remaining.some(x=>x>0)?btn('Возврат покупателю','refund','danger',`data-id="${r.id}"`):'')+btn('Закрыть','close','primary'));requestAnimationFrame(()=>$('#modal [data-action="close"].primary')?.focus?.())}
function payLabel(b){return b.payment==='mixed'?`Сложная: ${money(b.cash_amount)} нал. + ${money(b.card_amount)} карта`:b.payment==='cash'?'Наличные':'Безналичные'}
function saleTable(r){return `<table><thead><tr><th>Товар</th><th>Кол-во</th><th class="num">Сумма</th></tr></thead><tbody>${r.body.lines.map(x=>`<tr><td>${esc(x.name)}</td><td>${qty(x.qty)} ${unit(x.kind)}</td><td class="num">${money(x.total)}</td></tr>`).join('')}</tbody></table>`}
function refundDialog(){const r=S.last,remaining=r.remaining||r.body.lines.map(x=>x.qty),ready=true;modal('Возврат покупателю · покупка № '+r.id,`${ready?'':'<div class="notice amber">Исходная продажа ещё не передана в МойСклад. Возврат станет доступен после подтверждения передачи. Деньги пока не выдавайте.</div>'}<p>Выберите возвращённые товары и количество. Деньги выдайте покупателю вручную: банковский терминал с кассой не связан.</p>${r.body.payment==='mixed'?`<div class="notice amber">Покупка оплачена сложной оплатой (${money(r.body.cash_amount)} наличными + ${money(r.body.card_amount)} картой). При возврате сначала выдаются наличные — в пределах оплаченных наличными, остаток возвращается на карту через терминал.</div>`:''}<div class="tablewrap"><table><thead><tr><th>Вернуть</th><th>Товар</th><th>Кол-во</th></tr></thead><tbody>${r.body.lines.map((line,i)=>remaining[i]>0?`<tr><td><input class="refund-check" type="checkbox" data-index="${i}" aria-label="Вернуть ${esc(line.name)}"></td><td>${esc(line.name)}<br><span class="muted small">Доступно ${qty(remaining[i])} ${unit(line.kind)} · ${money(line.price)} / ${unit(line.kind)}</span></td><td><input class="refund-qty" type="number" data-index="${i}" min="${line.kind==='piece'||line.kind==='packaging'?1:0.001}" max="${remaining[i]/1000}" step="${line.kind==='piece'||line.kind==='packaging'?1:0.001}" value="${remaining[i]/1000}" disabled aria-label="Количество для возврата: ${esc(line.name)}"></td></tr>`:'').join('')}</tbody></table></div><p>К возврату: <strong id="refundTotal">0,00 ₽</strong></p>${field('Причина возврата','refundReason','','text','maxlength="500" required')}<label class="checklabel"><input type="checkbox" id="refundMoney"> Деньги возвращены покупателю</label>`,btn('Отмена','close')+btn('Оформить возврат','refund-confirm','danger',`data-id="${r.id}" ${ready?'':'disabled'}`))}
function refundSplit(sale,total){
 // Как на сервере: при сложной оплате сначала возвращаются наличные (в пределах оплаченных наличными), остаток — на карту.
 if(sale.body.payment!=='mixed')return sale.body.payment==='cash'?{cash:total,card:0}:{cash:0,card:total};
 const back=(sale.returns||[]).reduce((a,x)=>a+(x.body.cash_amount||0),0);const cash=Math.min(total,Math.max(0,sale.body.cash_amount-back));return {cash,card:total-cash};
}
function refundRefresh(){
 let total=0;const paid={};for(const x of S.last.returns||[])for(const l of x.body.lines||[])paid[l.line_index]=(paid[l.line_index]||0)+l.total;
 for(const check of $$('.refund-check:checked')){const i=Number(check.dataset.index),input=$(`.refund-qty[data-index="${i}"]`);const requested=Number(input?.value);if(!Number.isFinite(requested)||requested<=0)continue;
  const line=S.last.body.lines[i],rest=(S.last.remaining||[])[i];
  total+=Math.round(requested*1000)===rest?line.total-(paid[i]||0):Math.round(line.price*requested)}
 const label=$('#refundTotal');if(label){const sp=refundSplit(S.last,total);label.innerHTML=money(total)+(S.last.body.payment==='mixed'&&total?` — <strong>наличными ${money(sp.cash)}</strong>, на карту ${money(sp.card)}`:'')}
}
function receiptForm(r=null){S.receipt=r;const b=r?.body;const editable=!r||r.status==='draft'&&r.author===S.boot.user.id||manager();const form=`<div class="grid"><label>Поставщик<select id="receiptSupplier" ${editable?'':'disabled'}>${opts(S.boot.suppliers.filter(x=>x.active||x.id===b?.supplier.id),b?.supplier.id)}</select></label>${field('Номер накладной','receiptNumber',b?.number||'','','')}${field('Дата накладной','receiptDate',b?.date||new Date().toLocaleDateString('sv-SE'),'date')}</div><div class="tablewrap" style="margin-top:22px"><table><thead><tr><th>Товар</th><th>Количество</th><th>Закупочная цена, ₽</th><th></th></tr></thead><tbody id="receiptLines">${(b?.lines||[{}]).map(x=>receiptLine(x,editable)).join('')}</tbody></table></div>${editable?btn('＋ Добавить строку','receipt-line','small','style="margin-top:12px"'):''}${r?.status==='posted'&&editable?`<div class="notice amber" style="margin-top:18px">Изменения проведённой накладной изменят учёт. Предыдущая версия сохранится в истории.</div>${field('Причина исправления','receiptReason')}`:''}`;modal(r?'Накладная '+b.number:'Новая накладная',form,(manager()&&r?btn('История','revisions','',`data-id="${r.id}"`):'')+btn('Закрыть','close')+(editable?btn(r?.status==='posted'?'Сохранить исправления':'Сохранить черновик','receipt-save')+(r?.status!=='posted'?btn('Отправить','receipt-send','primary'):''):''));if(!editable)$$('#modal input').forEach(x=>x.disabled=true)}
function receiptLine(x={},edit=true){return `<tr class="receipt-line"><td><select class="r-product" ${edit?'':'disabled'}>${opts(S.boot.products,x.product_id)}</select></td><td><input class="r-qty" aria-label="Количество" type="number" min="0.001" step="0.001" value="${x.qty!==undefined?x.qty/1000:''}" ${edit?'':'disabled'}></td><td><input class="r-price" aria-label="Закупочная цена" type="number" min="0" step="0.01" value="${x.price!==undefined?x.price/100:''}" ${edit?'':'disabled'}></td><td>${edit?btn('×','receipt-remove','small','aria-label="Удалить строку"'):''}</td></tr>`}
async function saveReceipt(send){const r=S.receipt;const body={shop_id:S.shop,id:r?.id,version:r?.version,supplier_id:$('#receiptSupplier').value,number:$('#receiptNumber').value,date:$('#receiptDate').value,reason:$('#receiptReason')?.value,lines:$$('.receipt-line').map(tr=>({product_id:tr.querySelector('.r-product').value,qty:tr.querySelector('.r-qty').value,price:tr.querySelector('.r-price').value}))};let saved=await api('/api/receipts/save',body);S.receipt=saved;if(send){try{saved=await api('/api/receipts/send',{shop_id:S.shop,id:saved.id,version:saved.version})}catch(e){receiptForm(saved);throw e}}close();toast(send?'Накладная отправлена и проведена':'Накладная сохранена');await page()}
function inventoryForm(r){
  if(r.status==='draft'&&typeof openCount==='function')return openCount(r.id);
  // Просмотр отправленного пересчёта: только то, что посчитали. Учётные остатки
  // и расхождения смотрит и проводит управляющий в МоемСкладе.
  S.inventory=r;const indexed=new Map(S.boot.products.map(p=>[p.id,p]));
  const zones=(r.body.zones||[]).map(z=>`<details><summary>${esc(z.name)} · ${z.items.length} поз.${z.by?' · считал(а) '+esc(z.by):''}</summary><div class="small">${z.items.map(i=>{const p=indexed.get(i.product_id);return esc(p?.name||'Товар № '+i.product_id)+' · '+qty(i.qty)+' '+unit(p?.kind)}).join('<br>')||'пусто'}</div></details>`).join('');
  const lines=r.body.lines.filter(x=>!x.auto_zero&&x.qty!==null).map(x=>`<tr><td>${esc(x.name)}</td><td>${unit(x.kind)}</td><td class="num">${qty(x.qty)}</td></tr>`).join('');
  const where=r.status==='exported'?'<div class="notice ok">Пересчёт передан в МойСклад. Расхождения проверяет и проводит управляющий в МоемСкладе, в документе «Инвентаризация».</div>':
    r.status==='submitted'?(S.boot.moysklad?`<div class="notice amber">Пересчёт передаётся в МойСклад${r.sync_status?' · '+syncLabel(r.sync_status):''}. Новый пересчёт можно начать после передачи.</div>`:'<div class="notice">Пересчёт отправлен.</div>'):'';
  modal('Пересчёт № '+r.id,`${badge(r.status)}${where}${zones?`<div class="panel"><strong>Места пересчёта</strong>${zones}</div>`:''}<div class="tablewrap" style="margin-top:18px"><table><thead><tr><th>Товар</th><th>Ед.</th><th class="num">Посчитано</th></tr></thead><tbody>${lines||'<tr><td colspan="3">Нет позиций</td></tr>'}</tbody></table></div>`,
    btn('Закрыть','close','primary'),true);
}
function inventoryZone(){return inventoryZones.find(z=>z.id===inventoryZoneId)}
function inventoryProducts(){const byId=new Map(S.boot.products.map(p=>[p.id,p]));return S.inventory.body.lines.map(line=>({...byId.get(line.product_id),...line,id:line.product_id}))}
function inventoryRenderZone(){
  const tabs=$('#inventoryZoneTabs'),list=$('#inventoryZoneList');if(!tabs||!list)return;
  tabs.innerHTML=inventoryZones.map(z=>btn(esc(z.name)+' · '+Object.values(z.items).filter(v=>v!=='').length,'inventory-zone-select',z.id===inventoryZoneId?'active':'',`data-id="${esc(z.id)}"`)).join('');
  const zone=inventoryZone();
  if(!zone){list.innerHTML='<div class="notice amber">Добавьте первое место пересчёта, затем найдите или отсканируйте товар.</div>';return}
  const products=new Map(inventoryProducts().map(p=>[p.id,p]));
  const entries=Object.entries(zone.items).reverse().map(([id,value])=>{const p=products.get(Number(id));if(!p)return '';
    return `<tr><td>${esc(p.name)}</td><td>${unit(p.kind)}</td><td><input class="inv-qty" data-id="${p.id}" type="number" min="0" step="${['draft','weight'].includes(p.kind)?'.001':'1'}" value="${esc(value)}" aria-label="Факт ${esc(p.name)} в ${esc(zone.name)}"></td><td>${btn('Убрать','inventory-item-remove','small',`data-id="${p.id}"`)}</td></tr>`}).join('');
  list.innerHTML=`<h3>${esc(zone.name)} · найдено ${Object.values(zone.items).filter(v=>v!=='').length} поз.</h3>`+(entries?`<div class="tablewrap"><table><thead><tr><th>Товар</th><th>Ед.</th><th>Факт</th><th></th></tr></thead><tbody>${entries}</tbody></table></div>`:empty('В этом месте ещё нет пересчитанных товаров. Найдите товар по названию или сканируйте штрихкод.'));
}
function inventoryRenderSearch(){
  const target=$('#inventorySearchResults'),search=$('#inventorySearch');if(!target||!search)return;
  const query=search.value.trim().toLocaleLowerCase('ru-RU');
  if(!query){target.innerHTML='';return}
  const found=inventoryProducts().filter(p=>matchWords(query,[p.name])||p.barcode===query||(p.barcodes||[]).includes(query));
  target.innerHTML=found.length?`<div class="inventory-results">${found.slice(0,25).map(p=>btn(esc(p.name)+' · '+unit(p.kind),'inventory-item-add','small',`data-id="${p.id}"`)).join('')}</div>${found.length>25?'<p class="muted small">Показаны первые 25 товаров. Уточните поиск.</p>':''}`:'<p class="muted small">Товар не найден в этом пересчёте. Проверьте название или штрихкод.</p>';
}
function inventoryAddProduct(id,byName=false){
  const zone=inventoryZone();if(!zone)throw Error('Сначала добавьте место пересчёта');
  const p=inventoryProducts().find(x=>x.id===Number(id));if(!p)throw Error('Товар отсутствует в пересчёте');
  const previous=zone.items[p.id];
  if(p.kind==='piece'||p.kind==='packaging'){
    const n=previous==null||previous===''?0:Number(previous);
    if(!Number.isSafeInteger(n)||n<0||n>=1_000_000_000)throw Error('Проверьте количество перед следующим сканированием');
    zone.items[p.id]=String(n+1);inventoryDirty=true;
  }else if(previous==null){zone.items[p.id]='';inventoryDirty=true}
  const search=$('#inventorySearch');if(search&&!byName)search.value='';inventoryRenderSearch();inventoryRenderZone();
  const feedback=$('#inventoryScanStatus');if(feedback)feedback.textContent=p.name+(p.kind==='piece'||p.kind==='packaging'?' · '+zone.items[p.id]+' шт.':' · укажите количество в '+unit(p.kind))+' · не сохранено';
  if(p.kind==='piece'||p.kind==='packaging')search?.focus();else{$(`.inv-qty[data-id="${p.id}"]`)?.focus();$(`.inv-qty[data-id="${p.id}"]`)?.select?.()}
}
function inventorySearchEnter(){
  const value=$('#inventorySearch')?.value.trim();if(!value)return;
  const matches=inventoryProducts().filter(p=>p.barcode===value||(p.barcodes||[]).includes(value));
  if(matches.length===1)return inventoryAddProduct(matches[0].id);
  if(matches.length>1){$('#inventoryScanStatus').textContent='Штрихкод назначен нескольким товарам. Выберите товар вручную.';return}
  const names=inventoryProducts().filter(p=>matchWords(value,[p.name]));
  if(names.length===1)return inventoryAddProduct(names[0].id,true);
  inventoryRenderSearch();$('#inventoryScanStatus').textContent=names.length?'Уточните поиск или выберите товар из списка.':'Товар не найден. Проверьте каталог и штрихкод.';
}
function inventoryRequestZones(){
  const active=inventoryZone();if(active)$$('.inv-qty').forEach(input=>active.items[input.dataset.id]=input.value);
  const zones=inventoryZones.map(z=>({id:z.id,name:z.name,items:Object.entries(z.items).filter(([,v])=>v!=='').map(([id,v])=>({product_id:Number(id),qty:v}))}));
  if(!zones.length)throw Error('Добавьте место пересчёта');
  return zones;
}
async function stocks(){if(S.boot.moysklad){$('#content').innerHTML=heading('Остатки','Актуальные остатки доступны в МоемСкладе');return}const data=await api('/api/stock?'+shopArgs());$('#content').innerHTML=heading('Остатки магазина','Учётное количество по проведённым операциям')+`<div class="tablewrap"><table><thead><tr><th>Товар</th><th>Тип</th><th class="num">Остаток</th><th class="num">Розничная цена</th></tr></thead><tbody>${data.map(x=>`<tr><td><strong>${esc(x.name)}</strong></td><td class="muted">${kinds[x.kind]}</td><td class="num ${x.qty<0?'negative':''}">${qty(x.qty)} ${unit(x.kind)}</td><td class="num">${money(x.price)}</td></tr>`).join('')}</tbody></table></div>`}
async function summary(){if(S.boot.moysklad){$('#content').innerHTML=heading('Обзор сети','Актуальные отчёты доступны в МоемСкладе');return}const data=await api('/api/summary?'+shopArgs());const sum=key=>data.reduce((s,x)=>s+x[key],0);$('#content').innerHTML=heading('Обзор сети','За всё время · только проведённые продажи, за вычетом полных возвратов')+`<div class="metrics"><div class="metric"><div class="label">Выручка</div><strong>${money(sum('cash')+sum('card'))}</strong></div><div class="metric"><div class="label">Покупок</div><strong>${sum('count')}</strong></div><div class="metric"><div class="label">Позиций с минусом</div><strong class="${sum('negative')?'negative':''}">${sum('negative')}</strong></div><div class="metric"><div class="label">Пересчётов на проверке</div><strong>${sum('pending')}</strong></div></div><div class="tablewrap"><table><thead><tr><th>Магазин</th><th class="num">Наличные</th><th class="num">Безналичные</th><th class="num">Покупок</th><th class="num">Минусовых остатков</th></tr></thead><tbody>${data.map(x=>`<tr><td><strong>${esc(x.name)}</strong></td><td class="num">${money(x.cash)}</td><td class="num">${money(x.card)}</td><td class="num">${x.count}</td><td class="num ${x.negative?'negative':''}">${x.negative}</td></tr>`).join('')}</tbody></table></div><div class="statusbar">Получено с сервера: ${new Date().toLocaleTimeString('ru-RU')}. Безналичные суммы фиксируются продавцами, без проверки банковского терминала.</div>`}
let settingTab='products';
function settings(){const tabs={products:'Товары',packaging:'Тара к розливу',suppliers:'Поставщики',organizations:'ИП и организации',shops:'Магазины'};let data=S.boot[settingTab]||[];$('#content').innerHTML=heading('Справочники','Общие настройки сети',settingTab==='packaging'||S.boot.moysklad?'':(settingTab==='products'?btn('Загрузить из Excel','catalog-open')+' ':'')+btn('＋ Добавить','setting-new','primary'))+`<div class="tabs">${Object.entries(tabs).map(([id,l])=>btn(l,'setting-tab',settingTab===id?'active':'',`data-id="${id}"`)).join('')}</div>`;if(settingTab==='packaging'){
    $('#content').innerHTML+=`<div class="panel"><h2>Тара к напитку</h2><div class="notice">Тара настроена автоматически. Для напитка 0,5 л по умолчанию выбрана бутылка; продавец может переключить на стаканчик. Любую тару можно продать отдельно.</div><div class="tablewrap"><table><thead><tr><th>Вид тары</th><th>Товар из МоегоСклада</th><th>Цена</th></tr></thead><tbody>${data.map(r=>{const p=S.boot.products.find(p=>p.id===r.product_id);return `<tr><td>${esc(r.label)}</td><td>${esc(p?.name||'Нет в загруженном каталоге')}${p&&!p.active?' · недоступен':''}</td><td>${p?money(p.price):'—'}</td></tr>`}).join('')}</tbody></table></div><p class="muted">Цены обновляются из МоегоСклада. Стаканчик 0,2 л и бутылка 5 л продаются отдельно и не входят в этот список.</p></div>`;return}$('#content').innerHTML+=`<div class="tablewrap"><table><thead><tr><th>Название</th><th>${settingTab==='products'?'Тип / штрихкод':settingTab==='shops'?'Организация':'ИНН / контакты'}</th><th>${settingTab==='products'?'Цена':'Статус'}</th><th></th></tr></thead><tbody>${data.map(x=>`<tr><td><strong>${esc(x.name)}</strong>${!x.active?' <span class="badge">Архив</span>':''}</td><td class="muted">${esc(settingTab==='products'?kinds[x.kind]+(x.barcode?' · '+x.barcode:''):settingTab==='shops'?S.boot.organizations.find(o=>o.id===x.organization_id)?.name:x.inn||'Не заполнено')}</td><td>${settingTab==='products'?money(x.price):x.active?'Активен':'Архив'}</td><td class="right">${S.boot.moysklad?'':btn('Изменить','setting-edit','small',`data-id="${x.id}"`)}</td></tr>`).join('')}</tbody></table></div>`}
function settingForm(id){const r=S.boot[settingTab]?.find(x=>x.id===Number(id))||{};S.settingRecord=r;let html=field('Название','set-name',r.name||'');if(settingTab==='products')html+=`<label>Тип<select id="set-kind">${Object.entries(kinds).map(([id,n])=>`<option value="${id}" ${r.kind===id?'selected':''}>${n}</option>`).join('')}</select></label>`+field('Розничная цена за литр / кг / штуку, ₽','set-price',(r.price||0)/100,'number','min="0" step="0.01"')+field('Штрихкод','set-barcode',r.barcode||'')+field('Группа товаров','set-category',r.category||'')+(r.source_code?'<p class="muted small full">Код из выгрузки: '+esc(r.source_code)+' · Штрихкодов: '+(r.barcodes?.length||1)+'</p>':'');else if(settingTab==='shops')html+=`<label>ИП / организация<select id="set-organization_id">${opts(S.boot.organizations,r.organization_id)}</select></label>`+field('Адрес','set-address',r.address||'');else html+=field('ИНН','set-inn',r.inn||'')+field('Адрес','set-address',r.address||'')+field('Банковские реквизиты','set-bank',r.bank||'')+(settingTab==='suppliers'?field('Контакт / телефон','set-contact',r.contact||''):'');html+=`<label class="checklabel full"><input type="checkbox" id="set-active" ${r.active!==0?'checked':''}> Активная запись</label>`;modal(r.id?'Редактирование':'Новая запись',`<div class="grid">${html}</div>`,btn('Отмена','close')+btn('Сохранить','setting-save','primary'))}
async function users(){
 S.users=await api('/api/users');S.registrations=await api('/api/registrations');
 const assignedStores=u=>u.role==='manager'||u.role==='admin'?'Все магазины':JSON.parse(u.shops).map(id=>S.boot.shops.find(s=>s.id===id)?.name).filter(Boolean).join(', ')||'Точка не назначена';
 const pending=S.registrations.length?`<div class="panel"><h2>Заявки по email · ${S.registrations.length}</h2><p class="muted small">Адрес не подтверждён письмом. Перед одобрением проверьте сотрудника и назначьте его магазин.</p><div class="tablewrap"><table><thead><tr><th>Сотрудник</th><th>Email</th><th>Магазин</th><th>Действия</th></tr></thead><tbody>${S.registrations.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.email)}</td><td><select id="registration-shop-${r.id}" aria-label="Магазин для ${esc(r.name)}">${opts(S.boot.shops,S.shop)}</select></td><td>${btn('Одобрить','registration-approve','small primary',`data-id="${r.id}"`)} ${btn('Отклонить','registration-reject','small',`data-id="${r.id}"`)}</td></tr>`).join('')}</tbody></table></div></div>`:'';
 $('#content').innerHTML=heading('Сотрудники','Роли и доступ к магазинам назначает только управляющий',btn('＋ Добавить сотрудника','user-new','primary'))+pending+`<div class="tablewrap"><table><thead><tr><th>Сотрудник</th><th>Логин</th><th>Роль</th><th>Магазины</th><th></th></tr></thead><tbody>${S.users.map(u=>`<tr><td><strong>${esc(u.name)}</strong>${u.needs_password?(u.active?' · вход через МойСклад':' · настройте доступ'):!u.active?' · отключён':''}</td><td>${esc(u.login)}</td><td>${roles[u.role]}</td><td>${esc(assignedStores(u))}</td><td>${btn('Настроить','user-edit','small',`data-id="${u.id}"`)}</td></tr>`).join('')}</tbody></table></div>`
}
function userForm(id){
 const u=S.users?.find(x=>x.id===Number(id))||{role:'seller',shops:'[]',active:1};S.userRecord=u;
 const remote=!!S.boot.moysklad&&u.needs_password!=null;
 const assigned=JSON.parse(u.shops).map(id=>S.boot.shops.find(x=>x.id===id)?.name).filter(Boolean).join(', ');
 modal(u.id?'Настройки сотрудника':'Новый сотрудник',`<div class="grid">${remote?`<p class="notice full">${u.role==='seller'?`Торговая точка: <strong>${esc(assigned||'не назначена')}</strong>. Привязку кассира меняйте в МоемСкладе, затем нажмите «Синхронизировать».`:'Управляющему и администратору доступны все синхронизированные магазины.'}</p>`:''}${field('Имя','user-name',u.name||'')}${field('Логин','user-login',u.login||'')}${field(u.id?'Новый пароль (пусто — оставить прежний)':'Пароль, минимум 10 символов','user-password','','password','autocomplete="new-password"')}<label>Роль<select id="user-role">${Object.entries(roles).map(([r,l])=>`<option value="${r}" ${u.role===r?'selected':''}>${l}</option>`).join('')}</select></label><label class="checklabel"><input type="checkbox" id="user-active" ${u.active?'checked':''}> Доступ разрешён</label>${remote?'':`<div class="full"><h3>Доступные магазины</h3><p class="muted small">Управляющий и администратор имеют доступ ко всем магазинам.</p><div class="shopchecks">${S.boot.shops.map(s=>`<div class="shop-access-row"><label class="checklabel"><input class="user-shop" type="checkbox" value="${s.id}" ${JSON.parse(u.shops).includes(s.id)?'checked':''}> <span data-shop-name="${s.id}">${esc(s.name)}</span></label><button ${S.boot.moysklad?'hidden':''} type="button" class="small shop-rename" data-action="shop-rename" data-id="${s.id}" aria-label="Переименовать магазин ${esc(s.name)}" title="Переименовать магазин">✎</button></div>`).join('')}</div></div>`}</div>`,btn('Отмена','close')+btn('Сохранить','user-save','primary'));
}
async function auditPage(){const data=await api('/api/audit');const names={'sale':'Продажа','setup':'Первичная настройка','user.updated':'Настройка сотрудника','shift.open':'Открытие смены','shift.close':'Закрытие смены','packaging':'Настройка тары','settings.products':'Товар','settings.suppliers':'Поставщик','settings.organizations':'ИП / организация','settings.shops':'Магазин','document.receipt.sent':'Проведение накладной','document.draft.saved':'Изменение черновика','document.inventory.draft':'Сохранение пересчёта','document.inventory.submitted':'Пересчёт на проверку','document.inventory.approved':'Утверждение пересчёта','document.inventory.cancelled':'Отмена пересчёта','document.refund':'Возврат'};$('#content').innerHTML=heading('История действий','Последние 300 событий')+`<div class="tablewrap"><table><thead><tr><th>Время</th><th>Сотрудник</th><th>Действие</th><th>Подробности</th></tr></thead><tbody>${data.map(x=>`<tr><td>${date(x.created)}</td><td>${esc(x.user||'Первичная настройка')}</td><td>${esc(names[x.action]||x.action.replace('document.','Исправление: '))}</td><td><details><summary>Показать</summary><div class="history">${esc(JSON.stringify(JSON.parse(x.detail),null,2))}</div></details></td></tr>`).join('')}</tbody></table></div>`}

function importPreview(){const p=S.importPreview,ready=p.rows.filter(x=>x.state==='ready'),review=p.rows.filter(x=>x.state==='review'),errors=p.rows.filter(x=>x.state==='error');modal('Проверка каталога',`<div class="metrics"><div class="metric"><div class="label">Всего карточек</div><strong>${p.rows.length}</strong></div><div class="metric"><div class="label">Готовы к загрузке</div><strong>${ready.length}</strong></div><div class="metric"><div class="label">Нужно уточнить</div><strong>${review.length}</strong></div><div class="metric"><div class="label">Конфликты</div><strong>${errors.length}</strong></div></div><p>Будет добавлено: <strong>${ready.filter(x=>x.action==='create').length}</strong>, обновлено: <strong>${ready.filter(x=>x.action==='update').length}</strong>. Среди них архивных: <strong>${ready.filter(x=>!x.active).length}</strong> — они не появятся на кассе.</p><div class="notice amber">Строки «Нужно уточнить» и «Конфликты» не загружаются. Существующие записи не удаляются. Единицы литр и килограмм определяют тип товара, даже если флаги в исходной программе выключены.</div><label>Показать<select id="importFilter"><option value="review" ${review.length?'selected':''}>Нужно уточнить</option><option value="error" ${!review.length&&errors.length?'selected':''}>Конфликты</option><option value="ready" ${!review.length&&!errors.length?'selected':''}>Готовы к загрузке</option><option value="all">Все строки</option></select></label><div id="importRows" style="margin-top:15px"></div>`,btn('Отмена','close')+btn('Загрузить '+ready.length+' карточек','catalog-commit','primary',ready.length?'':'disabled'));importRows()}
function importRows(){const filter=$('#importFilter').value,rs=S.importPreview.rows.filter(x=>filter==='all'||x.state===filter);$('#importRows').innerHTML=`<p class="muted small">Найдено ${rs.length}. Показаны первые ${Math.min(rs.length,200)}.</p><div class="tablewrap"><table><thead><tr><th>Код / строка</th><th>Товар</th><th>Цена</th><th>Результат проверки</th></tr></thead><tbody>${rs.slice(0,200).map(x=>`<tr><td>${esc(x.source_code)}<br><span class="muted small">Строка ${x.row}</span></td><td>${esc(x.name)}<br><span class="muted small">${esc(x.category)} · ${kinds[x.kind]||'Неизвестный тип'}${!x.active?' · Архив':''}</span></td><td>${money(x.price)}</td><td>${esc([...x.errors,...x.review,...x.notes].join('; ')||(x.action==='create'?'Новая карточка':'Обновление карточки'))}</td></tr>`).join('')}</tbody></table></div>`}

async function sendSaleAttempt(recovery=false){
 const attempt=S.saleAttempt;if(!attempt)throw Error('Нет продажи для проверки');
 let result;
 try{result=await api('/api/sales',attempt.body,attempt.key)}
 catch(error){
  if(definiteRejection(error)){
   if(attempt.body.payment!=='cash')error.message+=' Продажа не записана: если картой уже заплатили на терминале — отмените эту оплату на терминале.';
   clearSaleAttempt();S.shop=attempt.body.shop_id;S.cartSlot=attempt.slot;
   activeCartKey=cartKey();S.cart=attempt.body.lines.map(x=>({...x}));saveCartDraft();
   if($('#modal')?.open)close();
   if(recovery){S.page='pos';await pos()}
  }else updateSaleRecovery();
  throw error;
 }
 clearSaleAttempt();clearCartDraft();if($('#modal')?.open)close();await pos();
 if(result.duplicate){toast('Продажа уже проведена. Проверьте её в разделе «Продажи»; повторной оплаты не было.');return}
 toast(S.boot.moysklad?'Покупка сохранена. Передача в МойСклад — через очередь.':'Продажа завершена');
 return saleView(result);
}
function mixCashValue(){const raw=String($('#mixCash')?.value??'').trim().replace(',','.'),c=raw===''?NaN:Math.round(Number(raw)*100);return Number.isFinite(c)?(c/100).toFixed(2):raw}
function confirmSale(type){
 if(S.saleAttempt){
  // Повтор после потерянного ответа: только с теми же суммами, что ушли в первый раз.
  const sent=S.saleAttempt.body;
  if(sent.payment!==type||(type==='mixed'&&$('#mixCash')&&mixCashValue()!==sent.cash_amount))
   throw Error(`Продажа уже отправлена${sent.payment==='mixed'?` (наличными ${money(Math.round(Number(sent.cash_amount)*100))})`:''}. Не меняйте суммы — нажмите «Проверить продажу» в предупреждении кассы.`);
 }
 if(!S.saleAttempt){
  if(Number.isFinite(S.payTotal)&&cartTotal()!==S.payTotal){const was=S.payTotal;S.payTotal=cartTotal();throw Error(`Цены обновились во время оплаты: было ${money(was)}, стало ${money(cartTotal())}. Закройте окно, проверьте чек и примите оплату заново.`)}
  const body=JSON.parse(JSON.stringify({shop_id:S.shop,payment:type,expected_total:cartTotal()/100,received:$('#cashReceived')?.value,cash_amount:type==='mixed'?mixCashValue():undefined,lines:S.cart}));
  const key=saleAttemptKey(),attempt={body,slot:S.cartSlot,key:S.paymentKey||crypto.randomUUID(),fingerprint:JSON.stringify(body)};
  if(!key||!cartStore('set',key,JSON.stringify(attempt)))throw Error('Не удалось сохранить ключ продажи на этом компьютере. Проверьте хранилище браузера.');
  S.saleAttempt=attempt;saleAttempted=true;saveCartDraft();updateSaleRecovery();
 }
 return sendSaleAttempt();
}

function openCashDialog(incoming){
 const kind=incoming?'in':'out',pending=S.cashAttempt?.body;
 if(pending&&(pending.shop_id!==S.shop||pending.kind!==kind))throw Error('Сначала проверьте прежнюю денежную операцию через предупреждение вверху кассы.');
 modal(incoming?'Внести деньги':'Выдать деньги',
  (pending?'<div class="notice amber">Предыдущая отправка не подтверждена. Сумму и причину нельзя менять до проверки.</div>':'')+
  field('Сумма, ₽','cashAmount',pending?.amount||'','number','min="0.01" step="0.01" required')+
  field('Причина','cashNote',pending?.note||'','text',incoming?'placeholder="Например: размен"':'required maxlength="300"')+
  `<p class="muted small">Денег в кассе: ${money(S.shift.totals.cash_on_hand)}</p>`,
  btn('Отмена','close')+btn(incoming?'Внести':'Выдать','cash-save','primary',`data-kind="${kind}"`));
}
async function recordCash(kind){
 if(!['in','out'].includes(kind))throw Error('Выберите денежную операцию');
 const body={shop_id:S.shop,kind,amount:$('#cashAmount').value,note:$('#cashNote').value};
 if(S.cashAttempt){
  if(JSON.stringify(body)!==JSON.stringify(S.cashAttempt.body))throw Error('Сумма или причина отличаются от неподтверждённой операции. Восстановите прежние значения и проверьте запись.');
 }else{
  const key=cashAttemptKey(),attempt={body,key:crypto.randomUUID()};
  if(!key||!cartStore('set',key,JSON.stringify(attempt)))throw Error('Не удалось сохранить ключ денежной операции на этом компьютере. Проверьте доступ к хранилищу браузера.');
  S.cashAttempt=attempt;updateCashRecovery();
 }
 return sendCashAttempt();
}

async function action(el){const a=el.dataset.action,id=el.dataset.id;
 if(a==='change-token'){if(!manager())throw Error('Сменить токен может управляющий.');return tokenScreen(null,true)}
 if(a==='theme-toggle'){const dark=document.documentElement.dataset.theme!=='dark';applyTheme(dark?'dark':'light');el.textContent=dark?'☀ Светлая тема':'☾ Тёмная тема';return}
 if(a==='update-restart'){if(!confirm('Перезапустить кассу и установить обновление? Незавершённые чеки сохранятся.'))return;
  await api('/api/update/restart',{});toast('Касса перезапускается…');
  const wait=async n=>{try{await new Promise(r=>setTimeout(r,3000));const st=await fetch('/api/status').then(r=>r.json());if(st.version&&st.version!==S.boot.version)return location.reload();}catch{}if(n<40)return wait(n+1);location.reload()};
  return wait(0)}
 if(a.startsWith('count-'))return countTopAction(a,el);
 if(a==='toggle-password'){const input=document.getElementById(el.dataset.target);if(!input)return;const visible=input.type==='password';input.type=visible?'text':'password';const label=visible?'Скрыть пароль':'Показать пароль';el.setAttribute('aria-label',label);el.setAttribute('aria-pressed',String(visible));el.title=label;el.innerHTML=eyeIcon(visible);return}
 if(a==='registration-approve'){
  const shop=Number(document.getElementById('registration-shop-'+id)?.value);
  if(!shop)throw Error('Выберите магазин для сотрудника');
  if(!confirm('Подтвердить сотрудника и открыть ему доступ к выбранному магазину?'))return;
  await api('/api/registrations/approve',{id:Number(id),shops:[shop]});await users();toast('Доступ сотруднику разрешён');return;
 }
 if(a==='registration-reject'){
  if(!confirm('Отклонить заявку на доступ?'))return;
  await api('/api/registrations/reject',{id:Number(id)});await users();return;
 }
 if(['catalog-home','catalog-all','catalog-group','catalog-clear','catalog-up'].includes(a)){
    S.query='';const input=$('#productSearch');if(input)input.value='';
    if(a!=='catalog-clear'){const tree=folderTree(S.boot.products.filter(p=>p.active));S.catalogView=a==='catalog-all'?'all':'groups';S.group=a==='catalog-group'?el.dataset.group:a==='catalog-up'?(tree.folders.get(S.group)?.parent||null):null;}
    return productGrid();
}if(a==='sync-catalog')return requestSync();if(a.startsWith('ms-'))return moyskladAction(a);if(S.boot.moysklad&&['shop-rename','setting-new','setting-edit','catalog-open'].includes(a))throw Error('Измените данные в МоемСкладе и обновите каталог.');if(a==='catalog-open'){modal('Загрузка общего каталога',`<div class="notice">Выберите XLSX-выгрузку ассортимента. Будут прочитаны карточки, группы, розничные цены и штрихкоды. Остатки, закупочные цены и документы не переносятся.</div><label>Файл ассортимента<input type="file" id="catalogFile" accept=".xlsx"></label>`,btn('Отмена','close')+btn('Проверить файл','catalog-check','primary'));return}if(a==='catalog-check'){const f=$('#catalogFile').files[0];if(!f)throw Error('Выберите файл XLSX');if(f.size>8000000)throw Error('Файл превышает 8 МБ');const file=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(Error('Файл не прочитан'));r.readAsDataURL(f)});toast('Проверяю каталог…');S.importPreview=await api('/api/catalog/preview',{file});importPreview();return}if(a==='catalog-commit'){const p=S.importPreview;const ready=p.rows.filter(x=>x.state==='ready');if(!ready.length)throw Error('Нет карточек для загрузки');if(!confirm('Загрузить '+ready.length+' карточек? Существующие карточки, сопоставленные по UUID или штрихкоду, будут обновлены, включая цены. Строки на проверке и с ошибками будут пропущены.'))return;const r=await api('/api/catalog/commit',{token:p.token});S.importPreview=null;close();await refreshBoot();await render();toast('Добавлено: '+r.created+' · Обновлено: '+r.updated+' · Пропущено: '+r.skipped);return}if(a==='close')return close();if(a==='logout'){if(saleAttempted&&!confirm('Оплата могла пройти. Проверьте «Продажи» перед выходом. Выйти сейчас?'))return;if(!saveCartDraft()&&S.cart.length)throw Error('Не удалось сохранить незавершённый чек. Выход отменён.');await api('/api/logout',{});S.boot=null;S.cart=[];S.cartSlot=1;activeCartKey=null;saleAttempted=false;S.saleAttempt=null;S.cashAttempt=null;S.refundAttempt=null;S.shiftAttempt=null;return start()}if(a==='shift-page'){S.page='shift';return page()}if(a==='nav'){S.page=el.dataset.page;return render()}if(a==='refresh'){await refreshBoot();return render()}if(a==='category'){S.category=id;return pos()}if(a==='product')return chooseProduct(id);if(a==='volume'){S.selection.volume=Number(el.dataset.value);S.selection.packaging_id=undefined;$$('.volumes button').forEach(b=>b.classList.toggle('active',b===el));packNotice();return draftFocus()}if(a==='portion-plus'||a==='portion-minus'){const input=$('#bottleCount');const value=Number(input.value);input.value=String(a==='portion-plus'?Math.min(1000,(Number.isInteger(value)&&value>=1?value:0)+1):Math.max(1,(Number.isInteger(value)&&value>=1?value:2)-1));return draftFocus()}if(a==='add-draft'){const count=Number($('#bottleCount').value),v=S.selection.volume;const m=enabledPacks().find(x=>x.volume===v*1000&&x.product_id===S.selection.packaging_id);if(!Number.isInteger(count)||count<1||count>1000)throw Error('Введите целое количество порций');if(!S.boot.products.some(x=>x.id===m?.product_id&&x.active))throw Error('Сначала настройте тару');S.cart.push({...S.selection,count,qty:v*count});close();return cartRender()}if(a==='add-weight'){const q=Number($('#weightQty').value.trim().replace(',','.'));if(!(q>0))throw Error('Введите вес');S.cart.push({product_id:S.selection.product_id,qty:q});close();return cartRender()}if(a==='cart-slot')return switchCartSlot(Number(el.dataset.slot));if(a==='cart-clear'){if(saleAttempted)throw Error('Сначала проверьте продажу в предупреждении кассы.');if(S.cart.length&&!confirm(saleAttempted?'Покупка могла уже пройти. Сначала проверьте «Продажи». Очистить чек?':'Очистить текущую покупку?'))return;clearCartDraft();return cartRender()}if(a.startsWith('cart-')){if(saleAttempted)throw Error('Покупка могла пройти. Проверьте «Продажи» до изменения чека.');const i=Number(id),x=S.cart[i];if(a==='cart-remove')S.cart.splice(i,1);else{const p=S.boot.products.find(p=>p.id===x.product_id);const sign=a==='cart-plus'?1:-1;if(p.kind==='draft'){x.count+=sign;x.qty=x.count*x.volume}else x.qty=Number((x.qty+sign*(p.kind==='weight'?.1:1)).toFixed(3));if(x.qty<=0)S.cart.splice(i,1)}return cartRender()}if(a==='shifts-print'){const table=$('#shiftsTable');if(!table)return;$('#printArea').innerHTML='<h3>'+esc(S.boot.shops.find(x=>x.id===S.shop)?.name||'')+' · смены</h3>'+table.innerHTML;$('#printArea').classList.add('wide');print();$('#printArea').classList.remove('wide');return}if(a==='cash-quick'){const input=$('#cashReceived');if(input){input.value=el.dataset.value;changeRefresh();input.focus()}return}if(a==='pay-cash'||a==='pay-card'||a==='pay-mixed')return payment({'pay-cash':'cash','pay-card':'card','pay-mixed':'mixed'}[a]);if(a==='pay-confirm')return confirmSale(el.dataset.type);if(a==='sale-retry')return sendSaleAttempt(true);if(a==='shift-retry')return sendShiftAttempt();if(a==='shift-open'||a==='shift-close'){if(S.shiftAttempt)throw Error('Сначала нажмите «Проверить смену» в предупреждении кассы.');const opening=a==='shift-open';
 const handover=!opening&&el.dataset.shift?S.shift.others?.find(x=>x.id===Number(el.dataset.shift)):null;
 if(!opening&&el.dataset.shift&&!handover)throw Error('Смена уже закрыта. Обновите страницу.');
 const t=S.shift.totals;
 const summary=opening?'':handover?`<div class="notice amber">Смену № ${handover.id} открыл(а) <strong>${esc(handover.user_name)}</strong> ${date(handover.opened)}. Пересчитайте деньги в кассе и закройте её, чтобы начать свою смену. Расхождение будет записано в отчёт управляющему.</div>`:
  `<div class="shift-close-summary"><div><span>Наличные продажи за вычетом возвратов и внесения</span><strong>${money(t.cash+t.cash_in)}</strong></div><div><span>Выдано из кассы</span><strong>${money(t.cash_out)}</strong></div><div><span>Безналичные</span><strong>${money(t.card)}</strong></div><div class="shift-total"><span>Должно быть в кассе</span><strong>${money(t.cash_on_hand)}</strong></div></div>`;
 modal(opening?'Открытие смены':handover?'Закрытие чужой смены':'Закрытие смены',summary+field(opening?'Сколько денег в кассе сейчас, ₽':'Пересчитайте наличные: сколько денег в кассе, ₽','shiftCash','','number','min="0" step="0.01" required inputmode="decimal"')+(!opening&&!handover?'<div id="shiftDiff" class="change-info"></div>':''),btn('Отмена','close')+btn(opening?'Открыть':'Закрыть смену','shift-save','primary',`data-mode="${opening?'open':'close'}" ${handover?`data-shift="${handover.id}"`:''}`));
 S.shiftExpected=!opening&&!handover?t.cash_on_hand:null;(typeof requestAnimationFrame==='function'?requestAnimationFrame:setTimeout)(()=>{$('#shiftCash')?.focus();shiftCashRefresh()});return}if(a==='shift-save')return recordShift(el.dataset.mode,el.dataset.shift?Number(el.dataset.shift):null);if(a==='cash-in'||a==='cash-out')return openCashDialog(a==='cash-in');if(a==='cash-save')return recordCash(el.dataset.kind);if(a==='cash-retry')return sendCashAttempt();if(a==='doc-open')return openDoc(id);if(a==='receipt-new')return receiptForm();if(a==='receipt-line')return $('#receiptLines').insertAdjacentHTML('beforeend',receiptLine());if(a==='receipt-remove')return el.closest('tr').remove();if(a==='receipt-save'||a==='receipt-send')return saveReceipt(a==='receipt-send');if(a==='inventory-zone-add'){
 const name=$('#inventoryNewZone').value.trim();if(!name||name.length>80)throw Error('Введите название места (до 80 символов)');
 if(inventoryZones.length>=50)throw Error('Можно создать не более 50 мест');
 if(inventoryZones.some(z=>z.name.toLocaleLowerCase('ru-RU')===name.toLocaleLowerCase('ru-RU')))throw Error('Такое место уже есть');
 const id=crypto.randomUUID();inventoryZones.push({id,name,items:{}});inventoryZoneId=id;inventoryDirty=true;
 $('#inventoryNewZone').value='';inventoryRenderZone();$('#inventorySearch')?.focus();return;
}if(a==='inventory-zone-select'){inventoryZoneId=id;inventoryRenderZone();$('#inventorySearch')?.focus();return}
if(a==='inventory-zone-rename'){
 const zone=inventoryZone();if(!zone)throw Error('Сначала добавьте место');const entered=prompt('Новое название места:',zone.name);
 if(entered===null)return;const name=entered.trim();if(!name||name.length>80)throw Error('Введите название места (до 80 символов)');
 if(inventoryZones.some(z=>z!==zone&&z.name.toLocaleLowerCase('ru-RU')===name.toLocaleLowerCase('ru-RU')))throw Error('Такое место уже есть');
 if(name!==zone.name){zone.name=name;inventoryDirty=true;inventoryRenderZone()}return;
}if(a==='inventory-zone-delete'){
 const zone=inventoryZone();if(!zone)throw Error('Место не выбрано');if(inventoryZones.length===1)throw Error('Оставьте хотя бы одно место пересчёта');
 if(Object.values(zone.items).some(v=>v!=='')&&!confirm('Удалить место «'+zone.name+'» вместе со всеми внесёнными здесь количествами?'))return;
 inventoryZones=inventoryZones.filter(z=>z!==zone);inventoryZoneId=inventoryZones[0].id;inventoryDirty=true;inventoryRenderZone();return;
}if(a==='inventory-item-add'){
 const p=inventoryProducts().find(x=>x.id===Number(id)),query=$('#inventorySearch')?.value.trim();
 return inventoryAddProduct(id,!!query&&!!p&&p.barcode!==query&&!(p.barcodes||[]).includes(query));
}
if(a==='inventory-item-remove'){
 const zone=inventoryZone();if(!zone)return;
 if(zone.items[id]!==''&&!confirm('Убрать товар из места «'+zone.name+'»?'))return;
 delete zone.items[id];inventoryDirty=true;inventoryRenderZone();return;
}if(a==='inventory-new')return countStartDialog();if(a==='inventory-new-old'){
 const blocker=S.docs.find(r=>['draft','submitted'].includes(r.status));if(blocker)return openDoc(blocker.id);
 modal('Начать инвентаризацию','<div class="notice amber">Продажи и проведение приходов будут приостановлены до отправки или отмены пересчёта.</div><p>Сначала назовите место, в котором начнёте пересчёт. Другие места можно добавить позже. Поиск товаров будет пустым до ввода названия или штрихкода; товары с остатком в МоемСкладе, которые вы не найдёте, получат факт 0.</p>'+field('Название первого места','inventoryFirstZone','','text','maxlength="80" autocomplete="off"'),btn('Отмена','close')+btn('Начать пересчёт','inventory-start','primary'));
 $('#inventoryFirstZone')?.focus();return;
}if(a==='inventory-start'){
 const name=$('#inventoryFirstZone').value.trim();if(!name||name.length>80)throw Error('Назовите первое место пересчёта');
 const r=await api('/api/inventory/start',{shop_id:S.shop,zones:[name]});await page();return inventoryForm(r);
}if(['inventory-save','inventory-send','inventory-cancel','inventory-approve'].includes(a)){
 if(a==='inventory-cancel'&&S.boot.moysklad&&S.inventory.status==='submitted'&&!confirm('Отменить пересчёт в БирМаг без корректировки остатков? Уже отправленные документы могут остаться в МоемСкладе. После отмены можно начать новый пересчёт.'))return;
 if(a==='inventory-approve'&&!confirm(S.boot.moysklad?'Подтвердить расхождения и отправить списания и оприходования в МойСклад? Убедитесь, что пересчёт охватывает весь магазин.':'Утвердить расхождения и скорректировать остатки?'))return;
 const b={shop_id:S.shop,id:S.inventory.id,version:S.inventory.version};
 if(a==='inventory-save'||a==='inventory-send'){
  b.zones=inventoryRequestZones();
  if(a==='inventory-send'){
   if(!b.zones.some(z=>z.items.length))throw Error('Добавьте и пересчитайте хотя бы один товар');
   if(!confirm('Вы пересчитали все места магазина? Товары с учётным остатком, которые вы не внесли, получат факт 0 после утверждения управляющим. Отправить?'))return;
  }
 }
 const r=await api('/api/inventory/'+a.split('-')[1],b);inventoryDirty=false;close();await page();
 if(a==='inventory-save')inventoryForm(r);
 toast(a==='inventory-send'?(S.boot.moysklad?'Пересчёт с нулём для не найденных товаров ждёт передачи в МойСклад':'Пересчёт отправлен управляющему'):a==='inventory-approve'?(S.boot.moysklad?'Корректировки остатков поставлены в очередь МоегоСклада.':'Расхождения утверждены, остатки скорректированы'):a==='inventory-cancel'?'Пересчёт отменён':'Пересчёт сохранён');
 return;
}if(a==='setting-tab'){settingTab=id;return settings()}if(a==='setting-new'||a==='setting-edit')return settingForm(id);if(a==='setting-save'){const b={table:settingTab,id:S.settingRecord.id};$$('[id^="set-"]').forEach(x=>b[x.id.slice(4)]=x.type==='checkbox'?x.checked:x.value);await api('/api/settings',b);close();await refreshBoot();return render()}if(a==='shop-rename'){if(!manager())throw Error('Переименовывать магазины может только управляющий');const shop=S.boot.shops.find(x=>x.id===Number(id));if(!shop)return;const entered=prompt('Новое название магазина «'+shop.name+'»:',shop.name);if(entered===null)return;const name=entered.trim();if(!name)throw Error('Название магазина не может быть пустым');if(name===shop.name)return;await api('/api/settings',{table:'shops',id:shop.id,name});await refreshBoot();const updated=S.boot.shops.find(x=>x.id===shop.id);document.querySelectorAll('[data-shop-name="'+shop.id+'"]').forEach(x=>x.textContent=updated.name);el.setAttribute('aria-label','Переименовать магазин '+updated.name);const picker=$('#shopSelect');if(picker)picker.innerHTML=opts(S.boot.shops,S.shop);if(S.page==='users')await users();toast('Название магазина изменено');return}if(a==='user-new'||a==='user-edit')return userForm(id);if(a==='user-save'){const b={id:S.userRecord.id,name:$('#user-name').value,login:$('#user-login').value,password:$('#user-password').value,role:$('#user-role').value,active:$('#user-active').checked,shops:S.userRecord.needs_password!=null&&S.boot.moysklad?JSON.parse(S.userRecord.shops):$$('.user-shop:checked').map(x=>Number(x.value))};await api('/api/users',b);close();await refreshBoot();return render()}if(a==='print'){const r=S.last;$('#printArea').innerHTML=`<h2>Документ о покупке № ${r.id}</h2><p>НЕ ЯВЛЯЕТСЯ ФИСКАЛЬНЫМ ЧЕКОМ</p><p>${esc(r.body.organization?.name||'')}<br>ИНН ${esc(r.body.organization?.inn||'—')}<br>${date(r.created)}</p>${saleTable(r)}<h3>Итого: ${money(r.body.total)}</h3><p>${payLabel(r.body)}</p>${r.status==='refunded'?'<p>Оформлен возврат</p>':''}`;window.print();return}if(a==='refund')return refundDialog();if(a==='refund-retry')return sendRefundAttempt();if(a==='refund-confirm'){const reason=$('#refundReason').value.trim();if(!reason)throw Error('Укажите причину возврата');const lines=$$('.refund-check:checked').map(check=>{const index=Number(check.dataset.index);return {line_index:index,qty:$(`.refund-qty[data-index="${index}"]`).value}});if(!lines.length)throw Error('Выберите возвращённые товары');if(!$('#refundMoney').checked)throw Error('Подтвердите, что деньги уже возвращены покупателю');const body={shop_id:S.shop,id,reason,money_returned:true,lines};return submitRefund(body)}if(a==='revisions'){const data=await api('/api/revisions?'+shopArgs()+'&id='+id);modal('История накладной',data.length?data.map(x=>{const old=JSON.parse(x.previous);return `<div class="panel"><strong>${date(x.created)} · ${esc(x.user)}</strong><p>${esc(x.reason)}</p><p class="muted">Предыдущая версия № ${old.version}</p><p>${esc(old.body.supplier?.name||'')} · ${esc(old.body.number||'')} · ${money(old.body.total)}</p>${old.body.lines?`<table><tbody>${old.body.lines.map(l=>`<tr><td>${esc(l.name)}</td><td>${qty(l.qty)}</td><td>${money(l.price)}</td></tr>`).join('')}</tbody></table>`:''}</div>`}).join(''):empty('Изменений пока нет'),btn('Закрыть','close'));return}}
document.addEventListener('click',async e=>{const el=e.target.closest('[data-action]');if(!el||S.busy)return;S.busy=true;el.disabled=true;try{await action(el)}catch(x){toast(x.message,true)}finally{S.busy=false;el.disabled=false}});
document.addEventListener('change',async e=>{if(e.target.id==='drinkPackaging'){S.selection.packaging_id=Number(e.target.value);return;}if(e.target.id==='importFilter'){importRows();return}if(e.target.classList?.contains('refund-check')){const field=$(`.refund-qty[data-index="${e.target.dataset.index}"]`);if(field)field.disabled=!e.target.checked;refundRefresh();return}if(e.target.id==='shopSelect'){if(saleAttempted){e.target.value=S.shop;toast('Сначала проверьте продажу в предупреждении кассы.',true);return}if(!saveCartDraft()&&S.cart.length){e.target.value=S.shop;toast('Не удалось сохранить чек. Переключение магазина отменено.',true);return}S.shop=Number(e.target.value);S.cartSlot=1;activeCartKey=null;restoreCartDraft();try{await render()}catch(x){toast(x.message,true)}}});
document.addEventListener('input',e=>{if(e.target.classList?.contains('inv-qty')){const zone=inventoryZone();if(zone){zone.items[e.target.dataset.id]=e.target.value;inventoryDirty=true}}if(e.target.classList?.contains('refund-qty'))refundRefresh();if(e.target.id==='productSearch'){S.query=e.target.value;productGrid()}if(e.target.id==='cashReceived')changeRefresh();if(e.target.id==='mixCash'||e.target.id==='mixCard')mixRefresh(e.target.id);if(e.target.id==='shiftCash')shiftCashRefresh();if(e.target.id==='saleSearch'){const q=e.target.value.trim().toLocaleLowerCase('ru-RU');$$('.sale-row').forEach(row=>row.hidden=!row.dataset.search.includes(q))}if(e.target.id==='inventorySearch')inventoryRenderSearch()});
document.addEventListener('keydown',e=>{
 if(e.key!=='Enter'||e.repeat||e.isComposing||e.ctrlKey||e.altKey||e.metaKey)return;
 if(e.target.id==='inventorySearch'){e.preventDefault();inventorySearchEnter();return}
 if(e.target.id==='inventoryNewZone'){e.preventDefault();if(!S.busy)$('#modal [data-action="inventory-zone-add"]')?.click();return}
 if(e.target.id==='inventoryFirstZone'){e.preventDefault();if(!S.busy)$('#modal [data-action="inventory-start"]')?.click();return}
 if(e.target.classList?.contains('inv-qty')){e.preventDefault();$('#inventorySearch')?.focus();return}
});
function searchMatches(value){
 const query=String(value||'').trim();if(!query)return [];
 return S.boot.products.filter(p=>p.active&&p.packaging_enabled!==false&&matchWords(query,[p.name,p.barcode,p.source_code,...(p.barcodes||[])]));
}
document.addEventListener('keydown',e=>{if(e.target.id!=='productSearch'||e.key!=='Enter'||e.isComposing)return;e.preventDefault();
 const value=e.target.value.trim();if(!value)return;
 const available=S.boot.products.filter(p=>p.active&&p.packaging_enabled!==false);
 const scanned=available.filter(p=>p.barcode===value||(p.barcodes||[]).includes(value));
 // A scanner sends the full barcode; a person may type part of a name. One match is added right away.
 const matches=scanned.length?scanned:searchMatches(value);
 if(matches.length!==1){toast(scanned.length>1?'Штрихкод назначен нескольким товарам. Выберите товар на экране.':matches.length?'Найдено несколько товаров. Выберите нужный на экране.':'Товар не найден. Проверьте название или штрихкод.',true);return}
 try{chooseProduct(matches[0].id);S.query='';e.target.value='';productGrid()}catch(error){toast(error.message,true)}
});
document.addEventListener('keydown',e=>{
 if(e.key!=='Enter'||e.repeat||e.isComposing||e.ctrlKey||e.altKey||e.metaKey||!$('#modal')?.open)return;
 const addAction={weightQty:'add-weight'}[e.target.id];
 if(addAction){
  e.preventDefault();if(!S.busy)$('#modal [data-action="'+addAction+'"]')?.click();return;
 }
 if(e.target.id==='mixCash'||e.target.id==='mixCard'){
  // Сложная оплата: Enter не проводит продажу — сначала карта на терминале, потом «Оплата получена».
  e.preventDefault();const ok=$('#modal [data-action="pay-confirm"]');if(ok&&!ok.disabled)ok.focus?.();return;
 }
 if(e.target.id==='cashReceived'){
  e.preventDefault();if(!S.busy)$('#modal [data-action="pay-confirm"]')?.click();return;
 }
 if(e.target.closest?.('button,textarea,select,[contenteditable]'))return;
 if(S.last&&$('#modal [data-action="close"].primary')&&!e.target.closest?.('input')){
  e.preventDefault();if(!S.busy)$('#modal [data-action="close"].primary').click();
 }
});
document.addEventListener('cancel',e=>{if(e.target.id==='modal'&&inventoryDirty&&!confirm('В пересчёте есть несохранённые количества. Закрыть без сохранения?'))e.preventDefault();else inventoryDirty=false});
window.addEventListener('beforeunload',e=>{if(S.cart.length||inventoryDirty){e.preventDefault();e.returnValue=''}});
start().catch(e=>{$('#app').textContent=e.message;toast(e.message,true)});


function syncLabel(status){return {pending:'Ожидает передачи в МойСклад',retry:'Ожидает подтверждения МоегоСклада',sent:'Передано в МойСклад'}[status]||status}
function registerHealth(st){
 const backup=st.backup||{},queue=st.register_queue||[];
 const table=queue.length?`<div class="tablewrap"><table><thead><tr><th>Магазин</th><th>Ожидают</th><th>Ошибки</th><th>Первая непереданная операция</th><th>Последнее подтверждение</th></tr></thead><tbody>${queue.map(x=>`<tr><td>${esc(x.name)}</td><td>${x.pending}</td><td>${x.retry?`<strong class="negative">${x.retry}</strong>`:'0'}</td><td>${x.first?`${esc(deliveryKinds[x.first.kind]||x.first.kind)} № ${esc(x.first.local_id)}${x.first.error?`<br><span class="negative">${esc(x.first.error)}</span>`:''}`:'—'}</td><td>${x.last_confirmed?date(x.last_confirmed):'Нет подтверждённых документов на этой кассе'}</td></tr>`).join('')}</tbody></table></div>`:empty('На этой кассе ещё нет магазинов');
 return `<div class="panel"><h2>Контроль этой кассы</h2><p class="muted small">Здесь видны только операции, сохранённые на этом компьютере. Очереди других касс проверяются на тех компьютерах.</p>${table}</div>`+
 `<div class="panel"><h2>Резервная копия</h2><p>Последняя копия: ${backup.last?date(backup.last):'ещё не создана'}.</p>${backup.warning?`<div class="notice error">${esc(backup.warning)}</div>`:''}<p class="muted small">${backup.separate_folder_configured?'Для автоматических копий указана отдельная папка. Убедитесь, что она находится на другом устройстве.':'Автоматические копии хранятся в папке data/backups на этом компьютере. При его поломке они могут пропасть вместе с базой.'}</p><a class="backup-download" href="/api/backup/download">Скачать проверенную копию</a><p class="muted small backup-advice">Сохраните скачанный файл на отдельном защищённом носителе. Копия содержит сотрудников, чеки и неотправленные операции.</p></div>`;
}
async function moyskladPage(){
 S.msStatus=await api('/api/moysklad/status');const st=S.msStatus;
 $('#content').innerHTML=heading('Настройка кассы','Эта касса и её связь с МоимСкладом. Товары, цены, сотрудники и отчёты — в МоемСкладе.')+
  registerHealth(st)+`<div class="panel"><h2>Каталог</h2><p>${st.synced?'Последняя успешная загрузка: '+date(st.synced):'Товары ещё не загружены'}</p><p class="muted small">Товаров в базе: ${S.boot.products.filter(p=>p.active).length}. Изменения цен подтягиваются при запуске и примерно каждые 30 минут. Кнопка «Синхронизировать» находится вверху экрана.</p>${st.auto_error?`<p class="notice error">${esc(st.auto_error)}</p>`:''}${!st.configured?'<p class="notice amber">Нет API-токена МоегоСклада.</p>':''}<p><button class="small ghost" data-action="change-token">${st.configured?'Сменить API-токен':'Ввести API-токен'}</button></p></div>`+
  `<details class="panel"><summary>Настройки подключения и очередь</summary><div style="margin-top:18px"><p>Тип цены: ${esc(st.price_name)}</p><p>${st.sales_enabled?'Передача продаж включена.':'Передача продаж начнётся при первом открытии смены продавцом.'}</p><p class="muted small">Смены и продажи создают реальные документы в МоемСкладе. Фискализация и банковский терминал не подключены.</p><p class="muted small">Резервная копия: ${st.backup_last?date(st.backup_last):'после следующего запуска'}.</p>${st.backup_error?`<p class="notice amber">${esc(st.backup_error)}</p>`:''}${st.active?`<p class="muted small">Вход управляющего с данными МоегоСклада:</p>${btn('Привязать мой вход МоегоСклада','ms-link','small')}`:''}<details><summary>Очередь передачи</summary><div class="toolbar" style="margin-top:14px">${btn('Обновить очередь','ms-queue','small')} ${btn('Повторить отправку','ms-retry','small')}</div><div id="msQueue"></div></details></div></details>`;
 await showQueue();
}
async function showQueue(){
    const data=await api('/api/moysklad/queue');const box=$('#msQueue');if(!box)return;
    box.innerHTML=data.length?`<p class="muted small">Показаны последние ${data.length} операций этой кассы; сводка выше учитывает всю очередь.</p><div class="tablewrap"><table><thead><tr><th>Магазин</th><th>Операция</th><th>№ BeerMag</th><th>Состояние</th><th>Подробности</th></tr></thead><tbody>${data.map(x=>`<tr><td>${esc(S.boot.shops.find(s=>s.id===x.shop_id)?.name||'Магазин № '+x.shop_id)}</td><td>${esc(deliveryKinds[x.kind]||x.kind)}</td><td>${esc(x.local_id)}${x.part_no?' · часть '+esc(x.part_no):''}</td><td>${esc(syncLabel(x.status))}</td><td>${esc(x.error||x.remote_id||'')}</td></tr>`).join('')}</tbody></table></div>`:empty('Очередь пока пуста');
}
async function moyskladAction(a){
    if(a==='ms-link'){
        modal('Вход управляющего через МойСклад',`<p class="muted small">Введите свой логин и пароль МоегоСклада один раз для привязки. Пароль не сохранится в БирМаг.</p>${field('Логин или email','ms-link-login','','text','autocomplete="username"')}${field('Пароль МоегоСклада','ms-link-password','','password','autocomplete="current-password"')}`,btn('Отмена','close')+btn('Привязать','ms-link-save','blue'));return;
    }
    if(a==='ms-link-save'){
        await api('/api/moysklad/link-self',{login:$('#ms-link-login').value,password:$('#ms-link-password').value});close();await refreshBoot();await render();toast('Профиль МоегоСклада привязан для входа управляющего.');return;
    }
    if(a==='ms-enable'){
        if(!confirm('Включить передачу реальных продаж? Покупки будут списывать товары в МоемСкладе. Начните с проверки на одном магазине.'))return;
        await api('/api/moysklad/sales-enable',{enabled:true});if($('#modal').open)close();await refreshBoot();await render();toast('Передача включена. Теперь нажмите «Открыть смену».');return;
    }
    if(a==='ms-queue')return showQueue();
    if(a==='ms-retry'){await api('/api/moysklad/retry',{});toast('Повторная отправка запрошена');return showQueue();}
}
const deliveryKinds={shift_open:'открытие смены',shift_close:'закрытие смены',sale:'продажа',refund:'возврат',partial_refund:'возврат',cash_in:'внесение денег',cash_out:'выплата денег',inventory:'инвентаризация'};
async function refreshDelivery(){
 if(!S.boot?.moysklad)return;
 let p;
 try{p=await api('/api/moysklad/progress')}catch{
  if(!S.boot?.moysklad)return;
  const label=$('#queueStatus');if(label)label.textContent='Состояние передачи неизвестно';
  const last=$('#lastRemoteStatus');if(last)last.textContent='';
  const panel=$('#deliveryPanel');if(panel)panel.innerHTML='<div class="notice error"><strong>Нет связи с сервером БирМаг.</strong> Состояние передачи в МойСклад неизвестно. Проверьте журнал продаж перед повторной оплатой.</div>';
  return;
 }
 if(!S.boot?.moysklad)return;
 const count=p.pending+p.retry;
 const label=$('#queueStatus');if(label)label.textContent=count?'Операций без подтверждения: '+count:'Все сохранённые операции переданы';
 const last=$('#lastRemoteStatus'),confirmed=p.last_confirmed_by_shop?.[S.shop];
 if(last)last.textContent=confirmed?'Последний документ в МойСклад: '+date(confirmed):'';
 const panel=$('#deliveryPanel');if(!panel)return;
 const failed=p.blocked?.find(x=>x.status==='retry');
 const issue=!p.configured?'Нет API-токена МоегоСклада. Управляющий вводит его в «Настройка кассы».':p.worker_error||
  (failed?`Не передана операция «${deliveryKinds[failed.kind]||failed.kind}» № ${failed.local_id}${failed.part_no?' (часть '+failed.part_no+')':''}: ${failed.error||'ответ не подтверждён'}. Касса повторит отправку автоматически.`:'');
 panel.innerHTML=issue?`<div class="notice error"><strong>МойСклад: передача остановилась.</strong> ${esc(issue)} ${manager()?'Подробности: Управление → МойСклад → Очередь.':'Сообщите управляющему; операции сохранены в кассе.'}</div>`:'';
 const backupPanel=$('#backupPanel');if(backupPanel)backupPanel.innerHTML=p.backup_warning?`<div class="notice amber"><strong>Резервная копия требует внимания.</strong> ${esc(p.backup_warning)} ${manager()?'Подробнее: Управление → Подключение → Резервная копия.':'Сообщите управляющему.'}</div>`:'';
}
setInterval(refreshDelivery,3000);

setTimeout(pollSync,1500);

let previousCartLength=0;
function resizeCart(scrollToEnd=false){
    const list=$('#cartLines');if(!list)return;
    const items=[...list.querySelectorAll('.cartline')];
    // Keep «К оплате» and the payment buttons on screen, even on 1024×700 laptops:
    // the list scrolls inside the cart instead of pushing the buttons down.
    const five=items.length>5?items.slice(0,5).reduce((sum,item)=>sum+item.getBoundingClientRect().height,0):Infinity;
    const box=list.getBoundingClientRect?.(),foot=$('#cartFoot')?.getBoundingClientRect?.()?.height||0;
    const room=box?Math.max(96,Math.floor((window.innerHeight||800)-box.top-foot-16)):Infinity;
    const overflow=box&&list.scrollHeight>room;
    const limit=Math.min(five,room);
    list.style.maxHeight=Number.isFinite(limit)&&(items.length>5||overflow)?limit+'px':'';
    if(scrollToEnd)list.scrollTop=list.scrollHeight;
}
window.addEventListener('resize',()=>requestAnimationFrame(()=>resizeCart()));

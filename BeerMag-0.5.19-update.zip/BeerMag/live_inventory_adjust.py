﻿"""Живая проверка: пересчёт кассой → оприходование и списание в МоемСкладе (как делает управляющий) → сверка остатков.

Работает на КОПИИ базы кассы, все документы с номерами BM-TEST… удаляются в конце.
  1. Первый пересчёт (склад пуст) → всё излишек → оприходование из инвентаризации → остаток = посчитанному.
  2. Продажа 1 шт. → остаток уменьшился.
  3. Второй пересчёт: недостача и излишек → списание и оприходование из инвентаризации → остаток = посчитанному.
  4. Удаление всего созданного, остатки вернулись к исходным.
"""
import hashlib, json, os, secrets, shutil, sqlite3, sys, tempfile, threading, time, uuid
import urllib.request, urllib.error, gzip
from contextlib import closing
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPORT=ROOT.parent/'live_inventory_adjust.txt'
LINES=[];STATE={'created':[]};PROBLEMS=[]
def say(t=''):print(t,flush=True);LINES.append(t)
def check(ok,t):
    say('   '+('✓ ' if ok else '✗ ')+t)
    if not ok:PROBLEMS.append(t)
    return ok
def g(q):return f'{q/1000:g}'.replace('.',',')

def raw(method,path,body=None):
    """Прямой запрос к МоемуСкладу (как управляющий в веб-интерфейсе): шаблоны, создание, удаление."""
    m=STATE['moysklad'];data=json.dumps(body,ensure_ascii=False).encode() if body is not None else None
    req=urllib.request.Request(m.BASE+path,data=data,method=method,headers={'Authorization':'Bearer '+STATE['tok'],
        'Accept':'application/json;charset=utf-8','Content-Type':'application/json;charset=utf-8','Accept-Encoding':'gzip'})
    for attempt in range(6):
        try:
            with urllib.request.urlopen(req,timeout=40) as r:
                b=r.read()
                if r.headers.get('Content-Encoding')=='gzip':b=gzip.decompress(b)
                return json.loads(b) if b else {}
        except urllib.error.HTTPError as e:
            b=e.read()
            try:b=gzip.decompress(b)
            except OSError:pass
            if e.code in (429,500,502,503,504) and attempt<5:time.sleep(2+attempt);continue
            text=b.decode('utf-8','replace')
            try:text='; '.join(x.get('error','') for x in json.loads(text).get('errors',[]))
            except Exception:text=text[:300]
            raise RuntimeError(f'МойСклад {method} {path.split("?")[0]}: HTTP {e.code} {text}') from None

def main():
    import start_moysklad
    tok=os.environ.get('BEERMAG_MOYSKLAD_TOKEN','').strip() or start_moysklad.saved_token()
    if not tok:raise SystemExit('Нет сохранённого API-токена.')
    os.environ['BEERMAG_MOYSKLAD_TOKEN']=tok;STATE['tok']=tok
    source=ROOT/'data'/'beerdesk.sqlite3'
    with closing(sqlite3.connect(source)) as real:
        if real.execute('SELECT 1 FROM shifts WHERE closed IS NULL LIMIT 1').fetchone():
            raise SystemExit('На кассе открыта смена — проверку запускают при закрытой смене.')
    work=Path(tempfile.mkdtemp(prefix='beermag-live-invadj-'));STATE['work']=work;copy=work/'copy.sqlite3'
    with closing(sqlite3.connect(source)) as a,closing(sqlite3.connect(copy)) as b:a.backup(b)
    os.environ['BEERDESK_DB']=str(copy);os.environ['BEERMAG_AUTO_SYNC_MINUTES']='0'
    sys.path.insert(0,str(ROOT))
    import server as app, moysklad, moysklad_outbox as outbox
    app.DB=copy;app.init();STATE.update(app=app,moysklad=moysklad)
    with app.connection(True) as d:
        d.execute("UPDATE ms_outbox SET status='sent' WHERE status NOT IN ('sent','skipped')")
        tag='TEST'+secrets.token_hex(3).upper();STATE['tag']=tag
        d.execute("INSERT INTO ms_options(key,value) VALUES('register_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(tag,))
        d.execute("UPDATE shifts SET closed=COALESCE(closed,?) WHERE closed IS NULL",(app.now(),))
        d.execute("UPDATE documents SET status='cancelled' WHERE type='inventory' AND status IN ('draft','waiting')")
        name=os.environ.get('BEERMAG_TEST_SHOP','')
        shop=(d.execute('SELECT m.shop_id FROM ms_shops m JOIN shops s ON s.id=m.shop_id WHERE s.name=?',(name,)).fetchone() or [None])[0] if name else None
        shop=shop or app.moysklad_bridge.bound_shop(d) or (d.execute('SELECT shop_id FROM ms_shops ORDER BY shop_id LIMIT 1').fetchone() or [None])[0]
        if not shop:raise SystemExit('Касса не связана с точкой продаж.')
        point=dict(d.execute('SELECT * FROM ms_shops WHERE shop_id=?',(shop,)).fetchone());store=point['store_id']
        user=d.execute('''SELECT u.* FROM users u JOIN ms_employees m ON m.user_id=u.id WHERE u.active=1 AND m.remote_archived=0
            ORDER BY (u.role='manager') DESC,u.id LIMIT 1''').fetchone()
        if not user:raise SystemExit('Нет сотрудника, связанного с МоимСкладом.')
        session=secrets.token_urlsafe(24)
        d.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(session.encode()).hexdigest(),user['id'],int(time.time())+3600))
        d.execute("INSERT INTO ms_options VALUES('sales_enabled','1') ON CONFLICT(key) DO UPDATE SET value='1'")
        pick=lambda sql:d.execute(sql).fetchone()
        bag=pick("SELECT * FROM products WHERE active=1 AND source_code='01872' AND source_uuid!=''") or \
            pick("SELECT * FROM products WHERE active=1 AND kind='piece' AND price>0 AND source_uuid!='' ORDER BY price LIMIT 1")
        weight=pick("SELECT * FROM products WHERE active=1 AND kind='weight' AND price>0 AND source_uuid!='' ORDER BY name LIMIT 1")
        draft=pick("SELECT * FROM products WHERE active=1 AND kind='draft' AND price>0 AND source_uuid!='' ORDER BY name LIMIT 1")
        if not (bag and weight and draft):raise SystemExit('Не найдены штучный, весовой и разливной товары с привязкой к МоемуСкладу.')
        shop_name=d.execute('SELECT name FROM shops WHERE id=?',(shop,)).fetchone()[0]
    goods=[bag,weight,draft]
    say('БирМаг · живая проверка: пересчёт → оприходование и списание · '+time.strftime('%d.%m.%Y %H:%M')+' · номер '+tag)
    say(f'Точка: {shop_name} · сотрудник: {user["name"]} ({user["role"]}) · копия базы: {copy}')
    say('Товары: '+'; '.join(f'{p["name"]} ({p["kind"]})' for p in goods))

    http=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler);threading.Thread(target=http.serve_forever,daemon=True).start()
    url='http://127.0.0.1:%d'%http.server_port
    def call(path,body=None,allow=False):
        req=urllib.request.Request(url+path,data=json.dumps(body).encode() if body is not None else None,
            headers={'X-BeerDesk':'1','Content-Type':'application/json','Idempotency-Key':str(uuid.uuid4()),'Cookie':'beerdesk='+session})
        try:
            with urllib.request.urlopen(req) as r:return json.load(r)
        except urllib.error.HTTPError as e:
            err={'status':e.code,**json.load(e)}
            if allow:return err
            raise SystemExit('Касса отказала: '+path+' · '+str(err.get('error','')))
    client=moysklad.Client()
    def stock():
        s=client.stock_for_store(store);return {p['id']:s.get(p['source_uuid'],0) for p in goods}
    def pump():
        started=time.time()
        while True:
            with app.connection(True) as d:
                d.execute("UPDATE ms_outbox SET next_try=MIN(next_try,?) WHERE status NOT IN ('sent','skipped')",(time.time()+2,))
                left=[dict(r) for r in d.execute("SELECT id,kind,error FROM ms_outbox WHERE status NOT IN ('sent','skipped') ORDER BY id")]
            if not left:return True
            if time.time()-started>300:
                say('   ✗ очередь не передалась за 5 минут: '+left[0]['kind']+' · '+str(left[0]['error']));PROBLEMS.append('очередь');return False
            outbox.process_one(app,moysklad.Client(retries=0));time.sleep(.5)
    with app.connection() as d:STATE['first']=(d.execute('SELECT COALESCE(MAX(id),0)+1 FROM ms_outbox').fetchone()[0])

    def count(label,qty):
        """Пересчёт одним местом через API кассы, отправка, передача, сверка документа в МоемСкладе."""
        r=call('/api/inventory/start',{'shop_id':shop,'zones':[label]});zone=r['body']['zones'][0]
        items=[{'product_id':p['id'],'qty':f'{qty[p["id"]]/1000:g}'} for p in goods]
        call('/api/inventory/zone',{'shop_id':shop,'id':r['id'],'rev':0,'zone':{'id':zone['id'],'name':zone['name'],'done':True,'items':items}})
        blocked=call('/api/sales',{'shop_id':shop,'payment':'card','expected_total':bag['price']/100,'lines':[{'product_id':bag['id'],'qty':1}]},allow=True)
        check(blocked.get('status') in (409,400),'во время пересчёта продажа не проходит: «'+str(blocked.get('error',''))[:70]+'»')
        cur=call('/api/document?shop_id=%d&id=%d'%(shop,r['id']))
        sent=call('/api/inventory/send',{'shop_id':shop,'id':r['id'],'version':cur['version']})
        check(sent['status'] in ('submitted','sent','waiting','exported'),'пересчёт отправлен, состояние «'+sent['status']+'»')
        pump()
        doc=call('/api/document?shop_id=%d&id=%d'%(shop,r['id']))
        check(doc['status']=='exported','МойСклад принял пересчёт (состояние «'+doc['status']+'»)')
        appr=call('/api/inventory/approve',{'shop_id':shop,'id':r['id'],'version':doc.get('version')},allow=True)
        check(appr.get('status')==409,'касса сама не проводит корректировки: «'+str(appr.get('error',''))[:70]+'»')
        with app.connection() as d:
            jobs=[dict(x) for x in d.execute('''SELECT o.* FROM ms_outbox o JOIN ms_inventory_parts p ON p.job_id=o.id
                WHERE p.document_id=? ORDER BY p.part_no''',(r['id'],))]
        inv=[j['remote_id'] for j in jobs if j['remote_id']]
        check(len(inv)==1,f'в МоемСкладе одна инвентаризация ({len(inv)})')
        return r['id'],inv[0],doc

    def from_inventory(kind,inv_id,want):
        """Как управляющий: «Создать → Оприходование/Списание» из документа инвентаризации."""
        inv_meta={'meta':{'href':STATE['moysklad'].BASE+'entity/inventory/'+inv_id,'type':'inventory','mediaType':'application/json'}}
        tpl=raw('PUT','entity/'+kind+'/new',{'inventory':inv_meta})
        rows=tpl.get('positions',{});rows=rows.get('rows',[]) if isinstance(rows,dict) else rows
        got={moysklad.ident(p['assortment']):round(p['quantity']*1000) for p in rows}
        exp={p['source_uuid']:abs(v) for p,v in want.items() if v}
        check(got==exp,f'шаблон {"оприходования" if kind=="enter" else "списания"} из инвентаризации: позиции '+
              ', '.join(f'{p["name"][:18]} {g(abs(v))}' for p,v in want.items() if v)+('' if got==exp else f' — ПОЛУЧЕНО {got}'))
        if not rows:return None
        n=sum(1 for k,_ in STATE['created'] if k==kind)+1
        body={'name':f'BM-{tag}-{"IE" if kind=="enter" else "IL"}-{n}','description':'Проверка BeerMag — будет удалено',
              'organization':tpl['organization'],'store':tpl['store'],'inventory':inv_meta,'applicable':True,
              'positions':[{k:p[k] for k in ('assortment','quantity','price','reason') if k in p} for p in rows]}
        doc=raw('POST','entity/'+kind,body);STATE['created'].append((kind,doc['id']))
        say(f'   создан документ {doc["name"]}: {len(rows)} поз., сумма {doc.get("sum",0)/100:.2f} ₽, связь с инвентаризацией: '+
            ('есть' if doc.get('inventory') else 'нет'))
        return doc

    before=stock()
    say('\nИсходные остатки склада: '+'; '.join(f'{p["name"][:22]} {g(before[p["id"]])}' for p in goods))

    call('/api/shifts/open',{'shop_id':shop,'cash':'0'})
    say('\n1) Первый пересчёт магазина (начальный остаток), смена открыта')
    q1={bag['id']:10000,weight['id']:2500,draft['id']:30000}
    _,inv1,doc1=count('Витрина (проверка оприходования)',q1)
    diffs={x['product_id']:x['difference'] for x in doc1['body'].get('differences',[])}
    check(all(diffs.get(p['id'],0)==q1[p['id']]-before[p['id']] for p in goods),'расхождения в кассе = посчитано − учётный остаток')
    from_inventory('enter',inv1,{p:q1[p['id']]-before[p['id']] for p in goods if q1[p['id']]>before[p['id']]})
    if any(q1[p['id']]<before[p['id']] for p in goods):from_inventory('loss',inv1,{p:q1[p['id']]-before[p['id']] for p in goods if q1[p['id']]<before[p['id']]})
    s1=stock()
    check(s1==q1,'остатки после оприходования = посчитанному: '+'; '.join(f'{p["name"][:18]} {g(s1[p["id"]])}' for p in goods))

    say('\n2) Продажа 1 шт. через кассу (после пересчёта продажи снова открыты)')
    call('/api/sales',{'shop_id':shop,'payment':'card','expected_total':bag['price']/100,'lines':[{'product_id':bag['id'],'qty':1}]})
    pump();s2=stock()
    check(s2[bag['id']]==q1[bag['id']]-1000,f'{bag["name"][:22]}: было {g(q1[bag["id"]])}, стало {g(s2[bag["id"]])}')

    say('\n3) Второй пересчёт: недостача и излишек')
    q2={bag['id']:7000,weight['id']:2750,draft['id']:30000}
    _,inv2,doc2=count('Витрина (проверка списания)',q2)
    remote={moysklad.ident(p['assortment']):p for p in client.all('entity/inventory/'+inv2+'/positions')}
    for p in goods:
        rp=remote.get(p['source_uuid'],{})
        check(round(rp.get('quantity',0)*1000)==q2[p['id']] and round(rp.get('calculatedQuantity',0)*1000)==s2[p['id']],
              f'{p["name"][:22]}: факт {g(q2[p["id"]])}, учётный {g(s2[p["id"]])} в документе МоегоСклада')
    want={p:q2[p['id']]-s2[p['id']] for p in goods}
    from_inventory('loss',inv2,{p:v for p,v in want.items() if v<0})
    from_inventory('enter',inv2,{p:v for p,v in want.items() if v>0})
    call('/api/shifts/close',{'shop_id':shop,'cash':'0'});pump()
    s3=stock()
    check(s3==q2,'остатки после списания и оприходования = посчитанному: '+'; '.join(f'{p["name"][:18]} {g(s3[p["id"]])}' for p in goods))
    http.shutdown()
    STATE['before']=before;STATE['stock']=stock
    return not PROBLEMS

def cleanup():
    if not STATE.get('app'):return
    app=STATE['app'];say('\n4) Удаляем тестовые документы из МоегоСклада')
    kinds={'inventory':'inventory','shift_open':'retailshift','sale':'retaildemand'}
    with app.connection() as d:
        jobs=[dict(r) for r in d.execute('SELECT kind,remote_id FROM ms_outbox WHERE id>=? AND remote_id IS NOT NULL',(STATE.get('first',10**9),))]
    todo=[(k,i) for k,i in STATE['created'] if k=='loss']+[(k,i) for k,i in STATE['created'] if k=='enter']
    for kind in ('inventory','retaildemand','retailshift'):todo+=[(kind,j['remote_id']) for j in jobs if kinds.get(j['kind'])==kind]
    left=0
    for kind,rid in todo:
        try:raw('DELETE','entity/'+kind+'/'+rid);say(f'   удалён {kind} {rid[:8]}…')
        except Exception as e:left+=1;say(f'   ✗ НЕ удалён {kind} {rid}: {e}');PROBLEMS.append('удаление')
    for kind in ('inventory','enter','loss','retaildemand','retailshift'):
        rows=raw('GET','entity/'+kind+'?limit=20&search=BM-'+STATE['tag']).get('rows',[])
        left+=len(rows)
        if rows:say(f'   ✗ осталось {kind}: '+', '.join(r['name'] for r in rows))
    check(left==0,'тестовых документов в МоемСкладе не осталось')
    if STATE.get('stock'):
        now=STATE['stock']();check(now==STATE['before'],'остатки вернулись к исходным')
    shutil.rmtree(STATE['work'],ignore_errors=True)

if __name__=='__main__':
    try:result=main()
    except SystemExit as e:say('\nПроверка остановлена: '+str(e));result=False
    except Exception as e:say('\nПроверка остановлена из-за ошибки: '+type(e).__name__+': '+str(e));result=False
    finally:
        try:cleanup()
        except Exception as e:say('Удаление не завершено: '+type(e).__name__+': '+str(e));result=False
    say('\nИТОГ: '+('пересчёт, оприходование и списание прошли без ошибок, всё удалено ✓' if result and not PROBLEMS else 'НАЙДЕНЫ ПРОБЛЕМЫ: '+'; '.join(PROBLEMS[:8])))
    REPORT.write_text('\n'.join(LINES),encoding='utf-8')

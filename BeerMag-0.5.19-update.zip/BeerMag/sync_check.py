"""Синхронизация каталога 0.5.15 с настоящим МоимСкладом на КОПИИ базы кассы (только чтение МоегоСклада)."""
import os, sys, sqlite3, tempfile, shutil
from contextlib import closing
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import start_moysklad
os.environ['BEERMAG_MOYSKLAD_TOKEN']=start_moysklad.saved_token() or ''
work=Path(tempfile.mkdtemp());copy=work/'copy.sqlite3'
with closing(sqlite3.connect(ROOT/'data'/'beerdesk.sqlite3')) as a,closing(sqlite3.connect(copy)) as b:a.backup(b)
os.environ['BEERDESK_DB']=str(copy);os.environ['BEERMAG_AUTO_SYNC_MINUTES']='0'
import server as app, moysklad_bridge
app.DB=copy;app.init()
def stats():
    with app.connection() as d:
        return {k:d.execute(v).fetchone()[0] for k,v in {'products':'SELECT COUNT(*) FROM products','active':'SELECT COUNT(*) FROM products WHERE active=1','with_barcode':"SELECT COUNT(*) FROM products WHERE barcode!=''"}.items()}
print('до:',stats())
for i in (1,2):
    ok=moysklad_bridge.auto_sync(app)
    with app.connection() as d:
        opts={r['key']:r['value'] for r in d.execute("SELECT key,value FROM ms_options WHERE key IN ('auto_error','catalog_warning')")}
    print('синхронизация',i,':',ok,stats(),{k:(v or '')[:300] for k,v in opts.items()})
shutil.rmtree(work,ignore_errors=True)

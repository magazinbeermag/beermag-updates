"""Offline update from an official BeerMag ZIP; keeps data and restores code on failure."""
import argparse
import io
import os
import shutil
import socket
import sqlite3
import stat
import tempfile
import zipfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import app_lock


def members(archive,keep=()):
    files = []
    seen = set()
    with zipfile.ZipFile(archive) as package:
        if sum(i.file_size for i in package.infolist()) > 1_000_000_000:
            raise ValueError('Архив слишком большой.')
        if package.testzip():
            raise ValueError('Архив повреждён.')
        for info in package.infolist():
            if '\\' in info.filename or ':' in info.filename:
                raise ValueError('В архиве обнаружен недопустимый путь.')
            path = PurePosixPath(info.filename)
            if info.is_dir():
                continue
            if path.is_absolute() or len(path.parts)<2 or path.parts[0]!='BeerMag' or any(p in ('..','') for p in path.parts):
                raise ValueError('В архиве обнаружен недопустимый путь.')
            relative = Path(*path.parts[1:])
            # The Windows launcher is the currently executing batch file.
            if relative==Path('UPDATE_WINDOWS.bat') or relative.as_posix() in keep:
                continue
            if relative.parts[0] in ('data','demo_data','updates') or relative.suffix=='.pyc':
                raise ValueError('Архив пытается изменить данные кассы.')
            if stat.S_ISLNK(info.external_attr >> 16) or relative in seen:
                raise ValueError('В архиве обнаружена ссылка или повторяющийся файл.')
            seen.add(relative)
            files.append((info,relative))
        if not {Path('server.py'),Path('web/app.js'),Path('README.md')}.issubset(seen):
            raise ValueError('Это не полный архив программы BeerMag.')
        runtime=package.getinfo('BeerMag/runtime/python313.zip') if Path('runtime/python313.zip') in seen else None
        if runtime:
            try:
                with zipfile.ZipFile(io.BytesIO(package.read(runtime))) as standard:
                    if 'encodings/__init__.pyc' not in standard.namelist() or standard.testzip():
                        raise ValueError('Встроенный Python повреждён: нет стандартной библиотеки.')
            except (zipfile.BadZipFile,EOFError):
                raise ValueError('Встроенный Python повреждён: не читается стандартная библиотека.') from None
    return files


def snapshot_database(root,stamp):
    database=root/'data'/'beerdesk.sqlite3'
    if not database.exists():
        return None
    destination=root/'data'/'backups'/('beerdesk-before-update-'+stamp+'.sqlite3')
    destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix('.tmp')
    try:
        with closing(sqlite3.connect(database)) as source,closing(sqlite3.connect(temporary)) as target:
            source.backup(target)
        with closing(sqlite3.connect(temporary)) as check:
            if check.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                raise sqlite3.DatabaseError('Резервная копия повреждена.')
        os.replace(temporary,destination)
    finally:
        try:temporary.unlink(missing_ok=True)
        except OSError:pass  # A cleanup failure must not mask the backup error.
    return destination


def install(archive,root,keep=()):
    root=Path(root).resolve()
    files=members(archive,keep)
    # Do not overwrite the interpreter that is executing this updater on Windows.
    if (root/'runtime'/'python.exe').is_file():
        files=[(info,path) for info,path in files if path.parts[0]!='runtime']
    if not (root/'server.py').is_file():
        raise ValueError('Запускайте обновление из установленной папки BeerMag.')
    with app_lock.exclusive(root/'data'/'beermag.lock'):
        # The lock is understood by this and subsequent releases. Also catch a
        # standard-port process running a release from before the lock existed.
        for port in (8765,8766):
            try:
                with socket.create_connection(('127.0.0.1',port),timeout=.15):
                    raise RuntimeError('Закройте окно работающей кассы и демо перед обновлением.')
            except (ConnectionRefusedError,TimeoutError,OSError):
                pass
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        with tempfile.TemporaryDirectory(prefix='beermag-update-',dir=root.parent) as temporary:
            staging=Path(temporary)/'new'; staging.mkdir()
            with zipfile.ZipFile(archive) as package:
                for info,relative in files:
                    target=staging/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    with package.open(info) as source,target.open('wb') as output:
                        shutil.copyfileobj(source,output)
            snapshot=snapshot_database(root,stamp)
            backup=root/'updates'/('before-'+stamp)
            for _,relative in files:
                existing=root/relative
                if existing.exists():
                    target=backup/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(existing,target)
            changed=[]
            try:
                for _,relative in files:
                    destination=root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                    os.replace(staging/relative,destination)
                    changed.append(relative)
            except Exception:
                for relative in reversed(changed):
                    previous=backup/relative
                    if previous.exists():shutil.copy2(previous,root/relative)
                    else:(root/relative).unlink(missing_ok=True)
                raise
    return snapshot,backup


def main():
    parser=argparse.ArgumentParser(description='Обновить BeerMag из нового ZIP')
    parser.add_argument('archive',nargs='?',help='Новый архив BeerMag-...-Windows.zip')
    args=parser.parse_args()
    if not args.archive:
        # Двойной щелчок без файла: ищем самый новый архив в «Загрузках» и рядом с папкой кассы.
        import re
        here=Path(__file__).resolve().parent
        places=[Path(os.environ.get('USERPROFILE',str(Path.home())))/'Downloads',here.parent,here]
        found=[]
        for place in places:
            try:found+=[p for p in place.glob('BeerMag-*-Windows*.zip') if p.is_file()]
            except OSError:pass
        def version(p):
            m=re.search(r'BeerMag-(\d+(?:\.\d+)+)',p.name);return tuple(int(x) for x in m.group(1).split('.')) if m else ()
        if not found:parser.exit(1,'Архив обновления не найден в «Загрузках». Перетащите файл BeerMag-...-Windows.zip на UPDATE_WINDOWS.bat.\n')
        best=max(found,key=lambda p:(version(p),p.stat().st_mtime))
        print('Найден архив: '+str(best))
        if input('Установить это обновление? (д/н): ').strip().lower() not in ('д','да','y','yes'):parser.exit(0,'Отменено.\n')
        args.archive=str(best)
    try:
        snapshot,backup=install(Path(args.archive).resolve(),Path(__file__).resolve().parent)
    except (OSError,ValueError,RuntimeError,sqlite3.Error,zipfile.BadZipFile) as error:
        parser.exit(1,'Обновление отменено: '+str(error)+'\n')
    print('Файлы программы обновлены. Папка data сохранена.')
    if snapshot:print('Копия базы перед обновлением: '+str(snapshot))
    print('Предыдущие файлы программы: '+str(backup))
    print('Теперь запустите BeerMag обычным способом.')


if __name__=='__main__':
    main()

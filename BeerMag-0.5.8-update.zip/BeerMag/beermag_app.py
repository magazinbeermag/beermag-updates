"""БирМаг — приложение кассы для Windows.

Запускается без чёрного окна (runtime\\pythonw.exe beermag_app.py):
  • значок у часов с меню (открыть кассу, состояние, перезапуск, выход);
  • сервер кассы работает в фоне и сам перезапускается после сбоя;
  • код 42 от сервера — «установить обновление и перезапустить»;
  • окно кассы открывается отдельным окном-приложением (Edge/Chrome --app);
  • второй запуск не создаёт вторую кассу, а просто показывает окно.
"""
import hashlib, json, os, secrets, subprocess, sys, threading, time, urllib.request, webbrowser
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
LOGS=DATA/'logs'
PORT=int(os.environ.get('BEERMAG_PORT','8765'))
URL='http://127.0.0.1:%d/'%PORT
TITLE='БирМаг — касса'
WINDOW_PROFILE=Path(os.environ.get('LOCALAPPDATA') or str(ROOT))/'BeerMagWindow'
CREATE_NO_WINDOW=0x08000000
DETACHED=0x00000008|0x00000200

STOP=threading.Event()
RESTART=threading.Event()
STATE={'proc':None,'status':'Запуск…','ready':False,'error':''}

def log(message):
    try:
        LOGS.mkdir(parents=True,exist_ok=True)
        with (LOGS/'app.log').open('a',encoding='utf-8') as f:f.write(time.strftime('%Y-%m-%d %H:%M:%S ')+message+'\n')
    except OSError:pass

def app_key():
    """Ключ окна кассы: им подтверждаются первая настройка и ввод токена (вместо кода из консоли)."""
    path=DATA/'app-key.txt'
    try:
        key=path.read_text(encoding='ascii').strip()
        if len(key)>=24:return key
    except OSError:pass
    key=secrets.token_urlsafe(24)
    DATA.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(key,encoding='ascii');os.replace(tmp,path)
    return key

NO_PROXY=urllib.request.build_opener(urllib.request.ProxyHandler({}))   # системный прокси не должен мешать 127.0.0.1
def status():
    try:
        with NO_PROXY.open(URL+'api/status',timeout=3) as r:return json.loads(r.read())
    except Exception:return None

# ---------------------------------------------------------------- окно кассы
def browser():
    bases=[os.environ.get(k) for k in ('ProgramFiles(x86)','ProgramFiles','LOCALAPPDATA')]
    for rel in ('Microsoft/Edge/Application/msedge.exe','Google/Chrome/Application/chrome.exe','Yandex/YandexBrowser/Application/browser.exe'):
        for base in bases:
            if base and (Path(base)/rel).is_file():return Path(base)/rel
    return None

def focus_existing():
    """Если окно кассы уже открыто — развернуть его вместо второго окна."""
    if os.name!='nt':return False
    import ctypes
    from ctypes import wintypes
    user=ctypes.WinDLL('user32',use_last_error=True)
    H=wintypes.HWND
    user.GetWindowTextLengthW.argtypes=[H];user.GetWindowTextW.argtypes=[H,wintypes.LPWSTR,ctypes.c_int]
    user.IsWindowVisible.argtypes=[H];user.IsIconic.argtypes=[H];user.ShowWindow.argtypes=[H,ctypes.c_int]
    user.SetForegroundWindow.argtypes=[H]
    PROC=ctypes.WINFUNCTYPE(wintypes.BOOL,H,wintypes.LPARAM)
    user.EnumWindows.argtypes=[PROC,wintypes.LPARAM]
    found=[]
    @PROC
    def each(hwnd,_):
        n=user.GetWindowTextLengthW(hwnd)
        if n and user.IsWindowVisible(hwnd):
            buf=ctypes.create_unicode_buffer(n+1);user.GetWindowTextW(hwnd,buf,n+1)
            if buf.value.startswith(TITLE):found.append(hwnd);return False
        return True
    user.EnumWindows(each,0)
    if not found:return False
    hwnd=found[0]
    if user.IsIconic(hwnd):user.ShowWindow(hwnd,9)   # SW_RESTORE
    user.SetForegroundWindow(hwnd)
    return True

LAST_OPEN=[0.0]
def open_window(key):
    if time.time()-LAST_OPEN[0]<3:return   # двойной щелчок не открывает два окна
    LAST_OPEN[0]=time.time()
    try:
        if focus_existing():return
    except Exception as e:log('Поиск окна: '+repr(e))
    url=URL+'#k='+key
    exe=browser()
    if exe:
        args=[str(exe),'--app='+url,'--user-data-dir='+str(WINDOW_PROFILE),'--no-first-run','--no-default-browser-check',
              '--disable-features=Translate,msEdgeTranslate','--start-maximized','--disable-session-crashed-bubble']
        try:subprocess.Popen(args,creationflags=DETACHED if os.name=='nt' else 0,close_fds=True);return
        except OSError as e:log('Окно кассы: '+repr(e))
    webbrowser.open(url)

# ---------------------------------------------------------------- сервер кассы
def python_exe():
    for name in ('python.exe','python3','python'):
        p=ROOT/'runtime'/name
        if p.is_file():return str(p)
    exe=Path(sys.executable)
    if exe.name.lower()=='pythonw.exe' and exe.with_name('python.exe').is_file():return str(exe.with_name('python.exe'))
    return sys.executable

def rotate(path,limit=5_000_000):
    try:
        if path.stat().st_size>limit:os.replace(path,path.with_suffix('.old.log'))
    except OSError:pass

def spawn(key,launch=''):
    LOGS.mkdir(parents=True,exist_ok=True)
    server_log=LOGS/'server.log';rotate(server_log)
    out=server_log.open('ab')
    env=dict(os.environ,BEERMAG_APP_KEY=key,BEERMAG_LAUNCH_ID=launch,PYTHONIOENCODING='utf-8',PYTHONUNBUFFERED='1')
    try:
        return subprocess.Popen([python_exe(),str(ROOT/'start_moysklad.py'),'--app','--no-browser','--port',str(PORT)],
                                cwd=str(ROOT),env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,
                                creationflags=CREATE_NO_WINDOW if os.name=='nt' else 0)
    finally:out.close()

def log_tail(lines=6):
    try:
        text=(LOGS/'server.log').read_bytes()[-4000:].decode('utf-8','replace')
        return '\n'.join([x for x in text.splitlines() if x.strip()][-lines:])
    except OSError:return ''

def own_hash():
    try:return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    except OSError:return ''

class Supervisor:
    def __init__(self,key,tray,open_first=True):
        self.key=key;self.tray=tray;self.open_first=open_first;self.hash=own_hash()
    def wait_ready(self,proc,launch):
        # Ждём, пока ответит именно наш сервер (по номеру запуска), сколько бы ни длился запуск.
        started=time.time();slow=False
        while proc.poll() is None and not STOP.is_set():
            st=status()
            if st and st.get('launch')==launch:return st
            if not slow and time.time()-started>90:
                slow=True;self.tray.tip('БирМаг — касса запускается дольше обычного…');log('Запуск дольше 90 с')
            time.sleep(.5)
        return None
    def wait_port_free(self):
        # На порту уже отвечает другая касса (например, старое чёрное окно): ждём, пока её закроют.
        warned=False
        while not STOP.is_set() and status():
            if not warned:
                warned=True;log('Порт кассы занят другой программой')
                STATE.update(error='На этом компьютере уже открыта другая касса БирМаг (например, старое чёрное окно). Закройте её.')
                self.tray.tip('БирМаг — закройте другое окно кассы')
                self.tray.balloon('Касса уже открыта','Закройте старое окно кассы БирМаг — после этого касса запустится сама.',error=True)
            time.sleep(5)
    def apply_update(self):
        # Скачанное обновление ставится до запуска сервера; если обновился сам значок — перезапускаем его.
        try:
            # Значок работает неделями: модули обновления каждый раз читаем с диска заново.
            for name in ('autoupdate','update','app_lock'):sys.modules.pop(name,None)
            import autoupdate
            installed=autoupdate.apply_pending()
            if installed:log('Установлено обновление '+installed)
        except Exception as e:
            log('Обновление не установлено: '+repr(e))
        return own_hash()!=self.hash
    def run(self):
        fails=[]
        while not STOP.is_set():
            RESTART.clear()
            self.wait_port_free()
            if STOP.is_set():break
            if self.apply_update():
                log('Приложение обновлено — перезапуск значка');return self.restart_self(None,self.open_first)
            started=time.time();launch=secrets.token_hex(8)
            self.tray.tip('БирМаг — запуск кассы…')
            proc=spawn(self.key,launch);STATE['proc']=proc;log('Сервер запущен, pid %d'%proc.pid)
            st=self.wait_ready(proc,launch)
            if st:
                STATE.update(ready=True,error='',status='работает')
                self.tray.tip('БирМаг %s — касса работает'%st.get('version',''))
                if own_hash()!=self.hash:   # обновление заменило само приложение (запасная проверка)
                    log('Приложение обновлено — перезапуск значка');return self.restart_self(proc,self.open_first)
                if self.open_first:self.open_first=False;open_window(self.key)
            code=proc.wait();STATE.update(ready=False,proc=None)
            if STOP.is_set():break
            log('Сервер завершился с кодом %s'%code)
            if code==42 or RESTART.is_set():
                self.tray.tip('БирМаг — перезапуск…')
                if code==42:self.tray.balloon('БирМаг','Устанавливается обновление, касса перезапускается.')
                continue
            if time.time()-started<30:fails.append(time.time())
            fails=[t for t in fails if t>time.time()-300]
            if len(fails)>=3:
                tail=log_tail()
                STATE.update(status='остановлена',error=tail)
                self.tray.tip('БирМаг — касса не запускается')
                self.tray.balloon('Касса не запускается',(tail.splitlines() or ['См. data\\logs\\server.log'])[-1][:200],error=True)
                log('Касса не запускается: '+tail.replace('\n',' | '))
                RESTART.wait(120)   # «Перезапустить кассу» из меню — или сами пробуем снова через 2 минуты
                fails=[];continue
            self.tray.balloon('БирМаг','Касса была остановлена и запускается снова.')
            time.sleep(3)
    def restart_self(self,proc,open_window_after=False):
        if proc:stop_server(proc)
        self.tray.release()
        exe=Path(sys.executable)
        subprocess.Popen([str(exe),str(Path(__file__)),'--restarted']+([] if open_window_after else ['--no-window']),cwd=str(ROOT),close_fds=True,
                         creationflags=DETACHED if os.name=='nt' else 0)
        STOP.set();self.tray.quit()

def stop_server(proc=None):
    proc=proc or STATE.get('proc')
    if proc and proc.poll() is None:
        proc.terminate()
        try:proc.wait(10)
        except subprocess.TimeoutExpired:proc.kill()

# ---------------------------------------------------------------- значок у часов (Win32)
class Tray:
    """Минимальный значок в области уведомлений на чистом ctypes."""
    OPEN,STATUS,RESTART_ID,LOGS_ID,QUIT=1,2,3,4,9
    def __init__(self,key):
        import ctypes
        from ctypes import wintypes as w
        self.c=ctypes;self.w=w;self.key=key;self.hwnd=None;self.mutex=None
        u=self.user=ctypes.WinDLL('user32',use_last_error=True)
        self.shell=ctypes.WinDLL('shell32',use_last_error=True)
        self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        LRESULT=ctypes.c_ssize_t
        self.WNDPROC=ctypes.WINFUNCTYPE(LRESULT,w.HWND,w.UINT,w.WPARAM,w.LPARAM)
        class WNDCLASSW(ctypes.Structure):
            _fields_=[('style',w.UINT),('lpfnWndProc',self.WNDPROC),('cbClsExtra',ctypes.c_int),('cbWndExtra',ctypes.c_int),
                      ('hInstance',w.HINSTANCE),('hIcon',w.HICON),('hCursor',w.HANDLE),('hbrBackground',w.HBRUSH),
                      ('lpszMenuName',w.LPCWSTR),('lpszClassName',w.LPCWSTR)]
        class GUID(ctypes.Structure):
            _fields_=[('a',ctypes.c_ulong),('b',ctypes.c_ushort),('c',ctypes.c_ushort),('d',ctypes.c_ubyte*8)]
        class NOTIFYICONDATAW(ctypes.Structure):
            _fields_=[('cbSize',w.DWORD),('hWnd',w.HWND),('uID',w.UINT),('uFlags',w.UINT),('uCallbackMessage',w.UINT),
                      ('hIcon',w.HICON),('szTip',ctypes.c_wchar*128),('dwState',w.DWORD),('dwStateMask',w.DWORD),
                      ('szInfo',ctypes.c_wchar*256),('uVersion',w.UINT),('szInfoTitle',ctypes.c_wchar*64),
                      ('dwInfoFlags',w.DWORD),('guidItem',GUID),('hBalloonIcon',w.HICON)]
        self.WNDCLASSW=WNDCLASSW;self.NID=NOTIFYICONDATAW
        u.DefWindowProcW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.DefWindowProcW.restype=LRESULT
        u.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,
                                    w.HWND,w.HMENU,w.HINSTANCE,w.LPVOID];u.CreateWindowExW.restype=w.HWND
        u.RegisterClassW.argtypes=[ctypes.POINTER(WNDCLASSW)];u.RegisterClassW.restype=w.ATOM
        u.LoadImageW.argtypes=[w.HINSTANCE,w.LPCWSTR,w.UINT,ctypes.c_int,ctypes.c_int,w.UINT];u.LoadImageW.restype=w.HANDLE
        u.LoadIconW.argtypes=[w.HINSTANCE,w.LPVOID];u.LoadIconW.restype=w.HICON
        u.AppendMenuW.argtypes=[w.HMENU,w.UINT,ctypes.c_size_t,w.LPCWSTR];u.CreatePopupMenu.restype=w.HMENU
        u.TrackPopupMenu.argtypes=[w.HMENU,w.UINT,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.HWND,w.LPVOID];u.TrackPopupMenu.restype=ctypes.c_int
        u.SetMenuDefaultItem.argtypes=[w.HMENU,w.UINT,w.UINT]
        u.DestroyMenu.argtypes=[w.HMENU]
        u.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
        u.SetForegroundWindow.argtypes=[w.HWND]
        u.MessageBoxW.argtypes=[w.HWND,w.LPCWSTR,w.LPCWSTR,w.UINT]
        u.RegisterWindowMessageW.argtypes=[w.LPCWSTR];u.RegisterWindowMessageW.restype=w.UINT
        u.GetMessageW.argtypes=[ctypes.POINTER(w.MSG),w.HWND,w.UINT,w.UINT]
        u.TranslateMessage.argtypes=[ctypes.POINTER(w.MSG)];u.DispatchMessageW.argtypes=[ctypes.POINTER(w.MSG)]
        u.DestroyWindow.argtypes=[w.HWND]
        self.shell.Shell_NotifyIconW.argtypes=[w.DWORD,ctypes.POINTER(NOTIFYICONDATAW)];self.shell.Shell_NotifyIconW.restype=w.BOOL
        self.kernel.GetModuleHandleW.argtypes=[w.LPCWSTR];self.kernel.GetModuleHandleW.restype=w.HMODULE
        self.kernel.CreateMutexW.argtypes=[w.LPVOID,w.BOOL,w.LPCWSTR];self.kernel.CreateMutexW.restype=w.HANDLE
        self.kernel.CloseHandle.argtypes=[w.HANDLE]
        self.WM_CALLBACK=0x8000+1   # WM_APP+1
        self.lock=threading.Lock();self._tip='БирМаг';self.added=False;self.TASKBAR=0;self.icon=None

    # единственный экземпляр
    def single(self,wait=0):
        end=time.time()+wait
        while True:
            self.mutex=self.kernel.CreateMutexW(None,False,'Local\\BeerMagKassaApp')
            if self.c.get_last_error()!=183:return True      # ERROR_ALREADY_EXISTS
            self.kernel.CloseHandle(self.mutex);self.mutex=None
            if time.time()>=end:return False
            time.sleep(.5)
    def release(self):
        self.remove()
        if self.mutex:self.kernel.CloseHandle(self.mutex);self.mutex=None

    def nid(self,flags):
        n=self.NID();n.cbSize=self.c.sizeof(self.NID);n.hWnd=self.hwnd;n.uID=1;n.uFlags=flags
        return n
    def add(self):
        n=self.nid(0x1|0x2|0x4);n.uCallbackMessage=self.WM_CALLBACK;n.hIcon=self.icon;n.szTip=self._tip[:127]
        self.added=bool(self.shell.Shell_NotifyIconW(0,self.c.byref(n)))
    def remove(self):
        if self.hwnd and self.added:
            n=self.nid(0);self.shell.Shell_NotifyIconW(2,self.c.byref(n));self.added=False
    def tip(self,text):
        with self.lock:
            self._tip=text
            if self.hwnd and self.added:
                n=self.nid(0x4);n.szTip=text[:127];self.shell.Shell_NotifyIconW(1,self.c.byref(n))
    def balloon(self,title,text,error=False):
        with self.lock:
            if self.hwnd and self.added:
                n=self.nid(0x10);n.szInfo=text[:255];n.szInfoTitle=title[:63];n.dwInfoFlags=3 if error else 1
                self.shell.Shell_NotifyIconW(1,self.c.byref(n))
    def message(self,text,flags=0x40):
        return self.user.MessageBoxW(None,text,'БирМаг',flags|0x10000|0x40000)   # поверх окон
    def quit(self):
        if self.hwnd:self.user.PostMessageW(self.hwnd,0x0010,0,0)   # WM_CLOSE

    def menu(self):
        u=self.user;m=u.CreatePopupMenu()
        u.AppendMenuW(m,0,self.OPEN,'Открыть кассу')
        u.AppendMenuW(m,0,self.STATUS,'Состояние')
        u.AppendMenuW(m,0x800,0,None)
        u.AppendMenuW(m,0,self.RESTART_ID,'Перезапустить кассу')
        u.AppendMenuW(m,0,self.LOGS_ID,'Папка журналов')
        u.AppendMenuW(m,0x800,0,None)
        u.AppendMenuW(m,0,self.QUIT,'Выход')
        u.SetMenuDefaultItem(m,self.OPEN,0)
        pt=self.w.POINT();u.GetCursorPos(self.c.byref(pt))
        u.SetForegroundWindow(self.hwnd)
        cmd=u.TrackPopupMenu(m,0x0100|0x0080|0x0002,pt.x,pt.y,0,self.hwnd,None)   # RETURNCMD|NONOTIFY|RIGHTBUTTON
        u.PostMessageW(self.hwnd,0,0,0);u.DestroyMenu(m)
        if cmd:self.command(cmd)

    def command(self,cmd):
        if cmd==self.OPEN:
            if STATE['ready']:open_window(self.key)
            else:self.message('Касса ещё запускается или остановлена.\n\n'+(STATE['error'] or 'Подождите несколько секунд.'),0x30)
        elif cmd==self.STATUS:
            st=status()
            if st:
                lines=['Версия: '+str(st.get('version','')),'Касса работает: '+URL]
                if st.get('token_needed'):lines.append('МойСклад: нужен API-токен (введите в окне кассы).')
                elif st.get('moysklad_ready'):lines.append('МойСклад: подключён.')
                if st.get('setup'):lines.append('Нужна первая настройка управляющего.')
            else:lines=['Касса не отвечает.',STATE['error'] or 'Идёт запуск или перезапуск.']
            try:
                upd=(DATA/'update-log.txt').read_text(encoding='utf-8').strip().splitlines()[-1]
                lines.append('Обновления: '+upd)
            except (OSError,IndexError):pass
            lines.append('Папка программы: '+str(ROOT))
            self.message('\n'.join(lines))
        elif cmd==self.RESTART_ID:
            if self.message('Перезапустить кассу? Незавершённые чеки сохранятся.',0x21)==1:
                RESTART.set();threading.Thread(target=stop_server,daemon=True).start()
        elif cmd==self.LOGS_ID:
            LOGS.mkdir(parents=True,exist_ok=True);os.startfile(str(LOGS))
        elif cmd==self.QUIT:
            if self.message('Закрыть кассу БирМаг?\n\nПока касса закрыта, продажи на этом компьютере невозможны. '
                            'Чтобы снова запустить — ярлык «Касса БирМаг» на рабочем столе.',0x31)==1:
                STOP.set();RESTART.set();self.tip('БирМаг — закрытие…')
                threading.Thread(target=lambda:(stop_server(),self.quit()),daemon=True).start()

    def wndproc(self,hwnd,msg,wparam,lparam):
        try:
            if msg==self.WM_CALLBACK:
                event=lparam&0xFFFF
                if event in (0x0203,0x0202):self.command(self.OPEN)         # щелчок по значку
                elif event in (0x0205,0x007B):self.menu()                   # правая кнопка
                return 0
            if msg==self.TASKBAR and self.TASKBAR:self.add();return 0       # проводник перезапустился
            if msg==0x0010:self.user.DestroyWindow(hwnd);return 0          # WM_CLOSE
            if msg==0x0002:self.remove();self.user.PostQuitMessage(0);return 0   # WM_DESTROY
        except Exception as e:log('Меню: '+repr(e))
        return self.user.DefWindowProcW(hwnd,msg,wparam,lparam)

    def create(self):
        c,w,u=self.c,self.w,self.user
        hinst=self.kernel.GetModuleHandleW(None)
        self._proc=self.WNDPROC(self.wndproc)   # держим ссылку, иначе сборщик мусора удалит callback
        wc=self.WNDCLASSW();wc.lpfnWndProc=self._proc;wc.hInstance=hinst;wc.lpszClassName='BeerMagTray'
        u.RegisterClassW(c.byref(wc))
        self.hwnd=u.CreateWindowExW(0,'BeerMagTray','БирМаг',0,0,0,0,0,None,None,hinst,None)
        self.TASKBAR=u.RegisterWindowMessageW('TaskbarCreated')
        ico=ROOT/'beermag.ico'
        self.icon=u.LoadImageW(None,str(ico),1,0,0,0x10|0x40) if ico.is_file() else None
        if not self.icon:self.icon=u.LoadIconW(None,c.c_void_p(32512))   # IDI_APPLICATION
        self.add()
        if not self.added:   # проводник ещё не готов сразу после входа в Windows
            for _ in range(30):
                time.sleep(2);self.add()
                if self.added:break
        log('Значок у часов: '+('показан' if self.added else 'не удалось показать'))
    def loop(self):
        msg=self.w.MSG()
        while self.user.GetMessageW(self.c.byref(msg),None,0,0)>0:
            self.user.TranslateMessage(self.c.byref(msg));self.user.DispatchMessageW(self.c.byref(msg))

def main():
    args=sys.argv[1:]
    if os.name!='nt':raise SystemExit('Приложение БирМаг работает в Windows. Для проверки используйте server.py.')
    os.chdir(ROOT)
    key=app_key()
    tray=Tray(key)
    if not tray.single(wait=20 if '--restarted' in args else 0):
        # Касса уже работает: только показать окно.
        if status():open_window(key)
        else:tray.message('Касса БирМаг уже запускается. Значок — у часов справа внизу.')
        return
    log('Запуск приложения '+' '.join(args))
    tray.create()
    sup=Supervisor(key,tray,open_first='--no-window' not in args)
    threading.Thread(target=sup.run,daemon=True).start()
    try:tray.loop()
    finally:
        STOP.set();RESTART.set()
        if STATE.get('proc'):stop_server()
        tray.release();log('Приложение закрыто')

if __name__=='__main__':
    try:main()
    except SystemExit:raise
    except Exception as e:
        import traceback;log('Сбой приложения: '+traceback.format_exc())
        raise

"""Local, transactional import and explicit shop mapping; never writes to MoySklad."""
import hashlib
from datetime import datetime, timezone
import json
import secrets
import threading
import time
import uuid
import catalog_import
import moysklad

SYNC_LOCK=threading.Lock()
SYNC_STATE={'running':False,'stage':'','error':'','run_id':0}

def progress():return dict(SYNC_STATE)

def set_stage(message):
    if SYNC_STATE['running']:SYNC_STATE['stage']=message

def start_sync(app):
    if not moysklad.configured():raise moysklad.SyncError('Нет API-токена МоегоСклада: управляющий вводит его в окне кассы.')
    if not SYNC_LOCK.acquire(blocking=False):return False
    SYNC_STATE.update(running=True,stage='Подключаемся к МоемСкладу…',error='',run_id=SYNC_STATE['run_id']+1)
    threading.Thread(target=_sync_worker,args=(app,),daemon=True).start()
    return True

def _sync_worker(app):
    try:
        auto_sync(app)
    except Exception as e:
        message=str(e) if isinstance(e,moysklad.SyncError) else 'Не удалось обновить каталог. Повторите загрузку.'
        SYNC_STATE['error']=message[:300]
        try:
            with app.connection(True) as d:
                d.execute("INSERT INTO ms_options VALUES('auto_error',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(message[:300],))
        except Exception:pass
    finally:
        SYNC_STATE.update(running=False,stage='')
        SYNC_LOCK.release()


def init(d):
    d.executescript('''
    CREATE TABLE IF NOT EXISTS ms_employees(remote_id TEXT PRIMARY KEY, user_id INTEGER UNIQUE NOT NULL REFERENCES users(id), remote_archived INTEGER NOT NULL DEFAULT 0, needs_password INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS ms_folders(remote_id TEXT PRIMARY KEY,name TEXT NOT NULL,path TEXT NOT NULL,archived INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS ms_options(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ms_state(id INTEGER PRIMARY KEY CHECK(id=1), price_name TEXT NOT NULL, synced TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ms_shops(shop_id INTEGER PRIMARY KEY REFERENCES shops(id), retail_id TEXT UNIQUE NOT NULL, store_id TEXT NOT NULL, organization_uuid TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ms_organizations(uuid TEXT PRIMARY KEY, local_id INTEGER NOT NULL REFERENCES organizations(id));
    CREATE TABLE IF NOT EXISTS ms_previews(token TEXT PRIMARY KEY, user_id INTEGER, payload TEXT NOT NULL, fingerprint TEXT NOT NULL, created INTEGER NOT NULL);
    ''')
    if 'parent_id' not in {x['name'] for x in d.execute('PRAGMA table_info(ms_folders)')}:
        d.execute("ALTER TABLE ms_folders ADD COLUMN parent_id TEXT NOT NULL DEFAULT ''")
    for name in ('offline_login','offline_password'):
        if name not in {x['name'] for x in d.execute('PRAGMA table_info(ms_employees)')}:
            d.execute(f"ALTER TABLE ms_employees ADD COLUMN {name} TEXT NOT NULL DEFAULT ''")
    if 'remote_managed' not in {x['name'] for x in d.execute('PRAGMA table_info(ms_employees)')}:
        d.execute('ALTER TABLE ms_employees ADD COLUMN remote_managed INTEGER NOT NULL DEFAULT 0')

def active(d): return d.execute('SELECT 1 FROM ms_state').fetchone() is not None

def register_id(d):
    """Stable random namespace for document names from this one local installation."""
    row=d.execute("SELECT value FROM ms_options WHERE key='register_id'").fetchone()
    if row:return row['value']
    value=uuid.uuid4().hex[:12].upper()
    d.execute("INSERT INTO ms_options(key,value) VALUES('register_id',?)",(value,))
    return value

def bound_shop(d):
    chosen=d.execute("SELECT value FROM ms_options WHERE key='register_retail_id'").fetchone()
    if not chosen:return None
    row=d.execute('SELECT shop_id FROM ms_shops WHERE retail_id=?',(chosen['value'],)).fetchone()
    return row['shop_id'] if row else 0  # Missing mapping must fail closed.

def bind_shop(d,retail_id):
    if not active(d):raise moysklad.SyncError('Сначала синхронизируйте торговые точки.')
    point=d.execute('SELECT shop_id FROM ms_shops WHERE retail_id=?',(retail_id,)).fetchone()
    if not point:raise moysklad.SyncError('Выберите синхронизированную торговую точку.')
    existing=d.execute("SELECT value FROM ms_options WHERE key='register_retail_id'").fetchone()
    if existing and existing['value']==retail_id:return point['shop_id']
    if d.execute('SELECT 1 FROM shifts LIMIT 1').fetchone() or d.execute('SELECT 1 FROM documents LIMIT 1').fetchone():
        raise moysklad.SyncError('На этой кассе уже есть история операций. Переносить её на другой магазин нельзя.')
    d.execute("INSERT INTO ms_options(key,value) VALUES('register_retail_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(retail_id,))
    return point['shop_id']

def fingerprint(d):
    data=[]
    for t in ('products','shops','organizations','packaging','packaging_choices','ms_shops','ms_organizations','ms_state','ms_employees','ms_folders','users'):
        # A successful login rotates only the offline password verifier.
        # It must not invalidate a catalog snapshot being prepared in parallel.
        fields='remote_id,user_id,remote_archived,needs_password,remote_managed' if t=='ms_employees' else '*'
        data.append([dict(x) for x in d.execute('SELECT '+fields+' FROM '+t+' ORDER BY 1')])
    return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()

def locally_configured(d,user_id):
    """Never undo an earlier explicit staff change while repairing an imported profile."""
    for record in d.execute("SELECT detail FROM audit WHERE action='user.updated'"):
        try:
            if json.loads(record['detail']).get('id')==user_id:return True
        except (ValueError,TypeError,AttributeError):continue
    return False

def status(d):
    state=d.execute('SELECT * FROM ms_state').fetchone()
    last=d.execute("SELECT key,value FROM ms_options WHERE key IN ('auto_synced','auto_error','backup_last','backup_error')").fetchall()
    diagnostics={x['key']:x['value'] for x in last}
    return {'configured':moysklad.configured(),'active':active(d),'stage':'sales','sales_enabled':sales_enabled(d),
            'price_name':state['price_name'] if state else 'Цена продажи',
            'synced':state['synced'] if state else None,
            'auto_synced':diagnostics.get('auto_synced'), 'auto_error':diagnostics.get('auto_error',''),
            'backup_last':diagnostics.get('backup_last'), 'backup_error':diagnostics.get('backup_error',''),
            'bound_shop_id':bound_shop(d),'progress':progress(),
            'mappings':[dict(x) for x in d.execute('SELECT * FROM ms_shops ORDER BY shop_id')]}

def auto_sync(app):
    """Fetch outside the write lock, then atomically verify and apply a full snapshot."""
    if not moysklad.configured():return False
    with app.connection() as d:
        manager=d.execute("SELECT * FROM users WHERE role='manager' AND active=1 ORDER BY id LIMIT 1").fetchone()
        if not manager:raise moysklad.SyncError('Нет действующего управляющего для обновления каталога.')
        manager=dict(manager);stamp=fingerprint(d)
        existing=app.rows(d,'SELECT * FROM products ORDER BY id')
        shops=app.rows(d,'SELECT * FROM shops WHERE active=1 ORDER BY id')
        bindings=app.rows(d,'SELECT * FROM ms_shops')
        state=d.execute('SELECT price_name FROM ms_state WHERE id=1').fetchone()
        price_name=state['price_name'] if state else 'Цена продажи'
    payload=prepare_auto(existing,shops,bindings,price_name)
    # One broken card must not stop price updates for every store. Problem
    # cards are skipped: an existing product keeps its previous local state,
    # a new one is not added. The manager sees the list and fixes the cards.
    # Archived cards are imported only to keep them unsellable; do not alarm about them.
    errors=[p for p in payload['rows'] if p['state']=='error' and p.get('active',1)]
    warning=''
    if errors:
        detail='; '.join(p['name']+': '+', '.join(p['errors'][:2]) for p in errors[:5])
        warning=('Пропущено карточек: '+str(len(errors))+'. '+detail+('…' if len(errors)>5 else '')+
                 '. Исправьте их в МоемСкладе; остальные товары и цены обновлены.')[:600]
    set_stage('Сохраняем товары и цены…')
    with app.connection(True) as d:
        preview=save_preview(d,manager,payload,stamp)
        result=commit(d,manager,preview['token'],app.now())
        app.audit(d,manager,'moysklad.auto_sync',result)
        d.execute("INSERT INTO ms_options VALUES('auto_synced',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(app.now(),))
        d.execute("DELETE FROM ms_options WHERE key='auto_error'")
        if warning:d.execute("INSERT INTO ms_options VALUES('catalog_warning',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(warning,))
        else:d.execute("DELETE FROM ms_options WHERE key='catalog_warning'")
    return True

def run_auto_sync(app):
    import os
    import threading
    try:interval=int(os.environ.get('BEERMAG_AUTO_SYNC_MINUTES','30'))
    except ValueError:interval=30
    if interval<=0:return
    wake=threading.Event()
    first=True
    while True:
        if not first:wake.wait(max(1,interval)*60)
        first=False
        if moysklad.configured():
            with app.connection() as d:
                ready=d.execute("SELECT 1 FROM users WHERE role='manager' AND active=1 LIMIT 1").fetchone()
            if ready:start_sync(app)

def prepare(existing, shops, mappings, price_name):
    if not isinstance(price_name,str) or not 1<=len(price_name.strip())<=100: raise moysklad.SyncError('Укажите название цены.')
    price_name=price_name.strip()
    if not isinstance(mappings,list) or len(mappings)!=len(shops): raise moysklad.SyncError('Сопоставьте каждый активный магазин.')
    local_ids={x['id'] for x in shops}
    mapped_ids=[int(x['shop_id']) for x in mappings]
    remote_ids=[x['retail_id'] for x in mappings]
    if set(mapped_ids)!=local_ids or len(set(mapped_ids))!=len(mapped_ids) or len(set(remote_ids))!=len(remote_ids):
        raise moysklad.SyncError('Каждому магазину нужна отдельная торговая точка. Повторы недопустимы.')
    client=moysklad.Client()
    refs={p['id']:p for p in client.references()}
    if any(x not in refs for x in remote_ids): raise moysklad.SyncError('Торговая точка недоступна. Проверьте подключение заново.')
    normalized=catalog_import.prepare(client.catalog(price_name),existing)
    return {'price_name':price_name,'rows':normalized,'mappings':[{'shop_id':int(x['shop_id']),**refs[x['retail_id']]} for x in mappings]}

def save_preview(d,u,payload,stamp):
    if fingerprint(d)!=stamp: raise moysklad.SyncError('Настройки изменились во время загрузки. Повторите проверку.')
    token=secrets.token_urlsafe(24)
    d.execute('DELETE FROM ms_previews WHERE created<?',(int(time.time())-1800,))
    d.execute('INSERT INTO ms_previews VALUES(?,?,?,?,?)',(token,u['id'],json.dumps(payload,ensure_ascii=False),stamp,int(time.time())))
    return {'token':token,**payload}

def commit(d,u,token,now):
    preview=d.execute('SELECT * FROM ms_previews WHERE token=? AND user_id=?',(token,u['id'])).fetchone()
    if not preview or preview['created']<time.time()-1800: raise moysklad.SyncError('Проверка устарела. Загрузите каталог заново.')
    if fingerprint(d)!=preview['fingerprint']: raise moysklad.SyncError('Каталог или настройки изменились. Повторите проверку.')
    if not active(d) and d.execute('SELECT 1 FROM shifts WHERE closed IS NULL').fetchone(): raise moysklad.SyncError('Перед подключением закройте все локальные смены.')
    if not active(d) and d.execute("SELECT 1 FROM documents WHERE status IN ('draft','submitted')").fetchone(): raise moysklad.SyncError('Перед подключением завершите локальные черновики и пересчёты.')
    payload=json.loads(preview['payload']); plans=payload['rows']
    errors=[p for p in plans if p['state']=='error']
    if errors and not payload.get('automatic'): raise moysklad.SyncError('Есть конфликты карточек. Загрузка отменена целиком: сначала устраните конфликты.')
    ready=[p for p in plans if p['state']=='ready']
    if not ready: raise moysklad.SyncError('Нет карточек, готовых к загрузке. Проверьте название цены.')
    kept={p['target_id'] for p in errors if p.get('target_id')}
    previous={r['id']:r['active'] for r in d.execute('SELECT id,active FROM products')} if kept else {}
    # Unavailable, archived and unreviewed products must never remain sellable from an old sync.
    d.execute('UPDATE products SET active=0')
    for ident in kept:
        if ident in previous:d.execute('UPDATE products SET active=? WHERE id=?',(previous[ident],ident))
    created=updated=0
    for p in ready:
        values=[p[k] for k in ('name','kind','barcode','price','active','source_uuid','source_code','category')]+[json.dumps(p['barcodes']),p.get('source_folder_uuid','')]
        if p['target_id']:
            d.execute('UPDATE products SET name=?,kind=?,barcode=?,price=?,active=?,source_uuid=?,source_code=?,category=?,barcodes=?,source_folder_uuid=? WHERE id=?',values+[p['target_id']]); updated+=1
        else:
            d.execute('INSERT INTO products(name,kind,barcode,price,active,source_uuid,source_code,category,barcodes,source_folder_uuid) VALUES(?,?,?,?,?,?,?,?,?,?)',values); created+=1
    # Exact bottle code + verified type and volume in name, never a price or name-only match.
    import re
    for volume,code in ((500,'02227'),(1000,'02064'),(1500,'01383'),(2000,'00269')):
        candidates=list(d.execute("SELECT id,name FROM products WHERE source_code=? AND kind='packaging' AND active=1",(code,)))
        if len(candidates)==1:
            match=re.search(r'бутылка?\s*(\d+(?:[,.]\d+)?)\s*л',candidates[0]['name'],re.I)
            if match and round(float(match[1].replace(',','.'))*1000)==volume:
                d.execute('INSERT INTO packaging VALUES(?,?) ON CONFLICT(volume) DO UPDATE SET product_id=excluded.product_id',(volume,candidates[0]['id']))
    if not payload.get('automatic'): d.execute('DELETE FROM ms_shops')
    for m in payload['mappings']:
        org=d.execute('SELECT local_id FROM ms_organizations WHERE uuid=?',(m['organization_id'],)).fetchone()
        if org:
            oid=org['local_id']; d.execute('UPDATE organizations SET name=?,inn=?,active=1 WHERE id=?',(m['organization_name'],m['inn'],oid))
        else:
            oid=d.execute('INSERT INTO organizations(name,inn) VALUES(?,?)',(m['organization_name'],m['inn'])).lastrowid
            d.execute('INSERT INTO ms_organizations VALUES(?,?)',(m['organization_id'],oid))
        sid=m.get('shop_id')
        if not sid:
            sid=d.execute('INSERT INTO shops(name,organization_id,address) VALUES(?,?,?)',(m['name'],oid,m['address'])).lastrowid
        d.execute('UPDATE shops SET name=?,organization_id=?,address=?,active=1 WHERE id=?',(m['name'],oid,m['address'],sid))
        d.execute('INSERT INTO ms_shops VALUES(?,?,?,?) ON CONFLICT(shop_id) DO UPDATE SET retail_id=excluded.retail_id,store_id=excluded.store_id,organization_uuid=excluded.organization_uuid',(sid,m['id'],m['store_id'],m['organization_id']))
    if payload.get('automatic'):
        sync_people(d,payload)
        d.execute('DELETE FROM ms_folders')
        for f in payload['folders']:
            d.execute('INSERT INTO ms_folders(remote_id,name,path,archived,parent_id) VALUES(?,?,?,?,?)',(f['id'],f['name'],f['path'],int(f['archived']),f.get('parent_id','')))
        # Keep legacy shops with history or employee access; retire only untouched setup placeholders.
        for old in list(d.execute('SELECT * FROM shops WHERE id NOT IN (SELECT shop_id FROM ms_shops)')):
            granted=any(old['id'] in json.loads(u['shops']) for u in d.execute("SELECT shops FROM users WHERE role!='manager'"))
            used=d.execute('SELECT 1 FROM documents WHERE shop_id=? UNION ALL SELECT 1 FROM shifts WHERE shop_id=? LIMIT 1',(old['id'],old['id'])).fetchone()
            if old['name'].startswith('Магазин ') and not used and not granted:d.execute('UPDATE shops SET active=0 WHERE id=?',(old['id'],))
        incoming={m['id'] for m in payload['mappings']}
        for old in list(d.execute('SELECT * FROM ms_shops')):
            if old['retail_id'] not in incoming:
                if d.execute('SELECT 1 FROM shifts WHERE shop_id=? AND closed IS NULL',(old['shop_id'],)).fetchone():raise moysklad.SyncError('Закройте смену магазина, удалённого из МоегоСклада.')
                d.execute('UPDATE shops SET active=0 WHERE id=?',(old['shop_id'],))
    # Older installations gave the first manager temporary shops called "Магазин 1".
    # Keep those records for history, but replace privileged access with real POS points.
    actual=sorted(r['shop_id'] for r in d.execute('SELECT shop_id FROM ms_shops JOIN shops ON shops.id=ms_shops.shop_id WHERE shops.active=1'))
    d.execute("UPDATE users SET shops=? WHERE role IN ('manager','admin')",(json.dumps(actual),))
    stamp=datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
    d.execute('INSERT INTO ms_state VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET price_name=excluded.price_name,synced=excluded.synced',(payload['price_name'],stamp))
    d.execute('DELETE FROM ms_previews')
    return {'created':created,'updated':updated,'review':len(plans)-len(ready),'skipped':len(errors),'shops':len(payload['mappings']),'employees':len(payload.get('employees',[])),'groups':len(payload.get('folders',[]))}


def sales_enabled(d):
    row=d.execute("SELECT value FROM ms_options WHERE key='sales_enabled'").fetchone()
    return bool(row and row['value']=='1')

def prepare_auto(existing,shops,bindings,price_name):
    price_name=(price_name or 'Цена продажи').strip()
    if not price_name or len(price_name)>100:raise moysklad.SyncError('Укажите название цены.')
    c=moysklad.Client();set_stage('Загружаем точки продаж и склады…');points=c.references()
    if not points:raise moysklad.SyncError('Не найдены активные торговые точки. Настройки сохранены.')
    known={b['retail_id']:b for b in bindings};used={b['shop_id'] for b in bindings}
    missing=set(known)-{point['id'] for point in points}
    if missing:
        raise moysklad.SyncError('API МоегоСклада не показывает '+str(len(missing))+' ранее связанных торговых точек. Проверьте аккаунт, доступ к точкам продаж и включены ли они. Настройки и очередь кассы сохранены.')
    mappings=[]
    for point in points:
        bound=known.get(point['id']);sid=bound['shop_id'] if bound else None
        if bound and (bound['store_id']!=point['store_id'] or bound['organization_uuid']!=point['organization_id']):
            raise moysklad.SyncError('В МоемСкладе изменился склад или организация уже связанной точки. Нужна проверка перед переносом связи.')
        if sid is None:
            matches=[x for x in shops if x['id'] not in used and x['name']==point['name']]
            if len(matches)==1:sid=matches[0]['id'];used.add(sid)
        mappings.append({'shop_id':sid,**point})
    set_stage('Загружаем товары и цены…')
    rows=catalog_import.prepare(c.catalog(price_name),existing,include_all=True)
    set_stage('Загружаем сотрудников и их торговые точки…')
    employees=c.employees()
    set_stage('Загружаем группы товаров…')
    folders=c.folders()
    return {'automatic':True,'price_name':price_name,'mappings':mappings,
            'rows':rows,'employees':employees,'folders':folders}

def sync_people(d,payload):
    shops={r['retail_id']:r['shop_id'] for r in d.execute('SELECT * FROM ms_shops')}
    incoming=set()
    for e in payload['employees']:
        incoming.add(e['id']);old=d.execute('SELECT * FROM ms_employees WHERE remote_id=?',(e['id'],)).fetchone()
        if old:
            uid=old['user_id'];d.execute('UPDATE users SET name=? WHERE id=?',(e['name'],uid))
        else:
            login=(e['uid'] or 'ms-'+e['id']).lower()
            # Existing seller can be linked only by both login and full displayed name.
            local=list(d.execute("SELECT * FROM users WHERE role='seller' AND lower(name)=lower(?) AND login IN (?,?) AND id NOT IN (SELECT user_id FROM ms_employees)",(e['name'],login,login.split('@')[0])))
            if len(local)==1:
                uid=local[0]['id'];d.execute('INSERT INTO ms_employees(remote_id,user_id,remote_archived,needs_password) VALUES(?,?,?,0)',(e['id'],uid,int(e['archived'])))
            else:
                uid=None
            if uid is None and d.execute('SELECT 1 FROM users WHERE login=?',(login,)).fetchone():login='ms-'+e['id']
            if uid is None:
                salt=secrets.token_hex(16)
                unknown=hashlib.scrypt(secrets.token_bytes(32),salt=salt.encode(),n=16384,r=8,p=1).hex()
                access=sorted({shops[p] for p in e.get('points',[]) if p in shops})
                uid=d.execute("INSERT INTO users(login,name,password,role,shops,active) VALUES(?,?,?,'seller',?,?)",(login,e['name'],salt+':'+unknown,json.dumps(access),int(len(access)==1 and not e['archived']))).lastrowid
                d.execute('INSERT INTO ms_employees(remote_id,user_id,remote_archived,needs_password) VALUES(?,?,?,1)',(e['id'],uid,int(e['archived'])))
        d.execute('UPDATE ms_employees SET remote_archived=? WHERE remote_id=?',(int(e['archived']),e['id']))
        if old and old['remote_managed'] and not e['archived']:
            privilege=e.get('privilege')
            current=d.execute('SELECT role,active FROM users WHERE id=?',(uid,)).fetchone()
            if privilege in ('manager','admin'):
                if current['role']!=privilege or not current['active']:
                    d.execute('UPDATE users SET role=?,active=1 WHERE id=?',(privilege,uid))
                    d.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
                    d.execute("UPDATE ms_employees SET offline_login='',offline_password='' WHERE remote_id=?",(e['id'],))
            else:
                # Revocation in MoySklad must revoke elevated BeerMag sessions.
                d.execute("UPDATE users SET role='seller',active=0,shops='[]' WHERE id=?",(uid,))
                d.execute("UPDATE ms_employees SET remote_managed=0,offline_login='',offline_password='' WHERE remote_id=?",(e['id'],))
                d.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
        user=d.execute('SELECT role,shops,active FROM users WHERE id=?',(uid,)).fetchone()
        assigned=sorted({shops[p] for p in e.get('points',[]) if p in shops})
        if user['role']=='seller':
            open_shift=d.execute('SELECT shop_id FROM shifts WHERE user_id=? AND closed IS NULL',(uid,)).fetchone()
            if open_shift and open_shift['shop_id'] not in assigned:
                raise moysklad.SyncError('У сотрудника открыта смена в другой точке. Закройте смену до смены привязки.')
            d.execute('UPDATE users SET shops=?,active=? WHERE id=?',(json.dumps(assigned),int(len(assigned)==1 and not e['archived']),uid))
            if user['shops']!=json.dumps(assigned) or not (len(assigned)==1 and not e['archived']):
                d.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
                d.execute("UPDATE ms_employees SET offline_login='',offline_password='' WHERE remote_id=?",(e['id'],))
        # A manager or admin may be a cashier at one point in MoySklad, while
        # their BeerMag role grants access to every active POS point.
        if e['archived']:
            d.execute("UPDATE ms_employees SET offline_login='',offline_password='' WHERE remote_id=?",(e['id'],))
            u=d.execute('SELECT role FROM users WHERE id=?',(uid,)).fetchone()
            if u['role']=='manager' and d.execute("SELECT COUNT(*) FROM users WHERE role='manager' AND active=1").fetchone()[0]<=1:
                raise moysklad.SyncError('Архивный сотрудник — последний управляющий BeerMag. Назначьте другого управляющего перед синхронизацией.')
            d.execute('UPDATE users SET active=0 WHERE id=?',(uid,));d.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
    for missing in list(d.execute('SELECT * FROM ms_employees')):
        if missing['remote_id'] not in incoming:
            u=d.execute('SELECT role,active FROM users WHERE id=?',(missing['user_id'],)).fetchone()
            if u['role']=='manager' and u['active']:raise moysklad.SyncError('Управляющий пропал из списка сотрудников МоегоСклада. Проверьте права API.')
            d.execute('UPDATE users SET active=0 WHERE id=?',(missing['user_id'],))
            d.execute('DELETE FROM sessions WHERE user_id=?',(missing['user_id'],))
            d.execute('UPDATE ms_employees SET remote_archived=1 WHERE remote_id=?',(missing['remote_id'],))
            d.execute("UPDATE ms_employees SET offline_login='',offline_password='' WHERE remote_id=?",(missing['remote_id'],))

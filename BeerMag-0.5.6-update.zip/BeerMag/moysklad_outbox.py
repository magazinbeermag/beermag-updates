"""Persistent ordered outbox. Every create has an immutable UUID syncId."""
import json
import re
import time
import uuid
import threading
from collections import Counter
from decimal import Decimal, InvalidOperation
from datetime import datetime, timedelta, timezone
import moysklad
import moysklad_bridge

WAKE=threading.Event()
WORKER_ERROR=''

def init(d):
    d.execute('''CREATE TABLE IF NOT EXISTS ms_outbox(
        id INTEGER PRIMARY KEY, kind TEXT NOT NULL, local_id INTEGER NOT NULL,
        sync_id TEXT UNIQUE NOT NULL, payload TEXT NOT NULL, dependency INTEGER REFERENCES ms_outbox(id),
        status TEXT NOT NULL DEFAULT 'pending', remote_id TEXT, attempts INTEGER NOT NULL DEFAULT 0,
        next_try REAL NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0,
        error TEXT NOT NULL DEFAULT '', shop_id INTEGER NOT NULL DEFAULT 0,
        sent_at TEXT, UNIQUE(kind,local_id))''')
    d.execute('''CREATE TABLE IF NOT EXISTS ms_inventory_parts(
        job_id INTEGER PRIMARY KEY REFERENCES ms_outbox(id),document_id INTEGER NOT NULL REFERENCES documents(id),
        part_no INTEGER NOT NULL,UNIQUE(document_id,part_no))''')
    d.execute('''CREATE TABLE IF NOT EXISTS ms_inventory_adjustments(
        job_id INTEGER PRIMARY KEY REFERENCES ms_outbox(id),document_id INTEGER NOT NULL REFERENCES documents(id),
        kind TEXT NOT NULL,part_no INTEGER NOT NULL,UNIQUE(document_id,kind,part_no))''')
    if 'shop_id' not in {x['name'] for x in d.execute('PRAGMA table_info(ms_outbox)')}:
        d.execute('ALTER TABLE ms_outbox ADD COLUMN shop_id INTEGER NOT NULL DEFAULT 0')
    if 'sent_at' not in {x['name'] for x in d.execute('PRAGMA table_info(ms_outbox)')}:
        # Older acknowledgements have no reliable timestamp; do not fabricate one.
        d.execute('ALTER TABLE ms_outbox ADD COLUMN sent_at TEXT')
    # Migrate queued jobs made by earlier releases before allowing independent stores to proceed.
    for kind,source in (
        ('shift_open','shifts'),('shift_close','shifts'),
        ('sale','documents'),('refund','documents'),('partial_refund','sale_returns'),
        ('cash_in','cash_movements'),('cash_out','cash_movements')):
        d.execute(f'''UPDATE ms_outbox SET shop_id=(SELECT shop_id FROM {source} WHERE id=ms_outbox.local_id)
            WHERE kind=? AND shop_id=0 AND EXISTS(SELECT 1 FROM {source} WHERE id=ms_outbox.local_id)''',(kind,))
    d.execute('''UPDATE ms_outbox SET shop_id=(SELECT documents.shop_id FROM ms_inventory_parts
        JOIN documents ON documents.id=ms_inventory_parts.document_id WHERE ms_inventory_parts.job_id=ms_outbox.id)
        WHERE kind='inventory' AND shop_id=0 AND EXISTS(SELECT 1 FROM ms_inventory_parts WHERE job_id=ms_outbox.id)''')
    d.execute('''UPDATE ms_outbox SET shop_id=(SELECT documents.shop_id FROM ms_inventory_adjustments
        JOIN documents ON documents.id=ms_inventory_adjustments.document_id WHERE ms_inventory_adjustments.job_id=ms_outbox.id)
        WHERE kind IN ('loss','enter') AND shop_id=0 AND EXISTS(SELECT 1 FROM ms_inventory_adjustments WHERE job_id=ms_outbox.id)''')
    d.execute('CREATE INDEX IF NOT EXISTS ms_outbox_shop_order ON ms_outbox(shop_id,id,status)')
    d.execute('CREATE INDEX IF NOT EXISTS ms_outbox_confirmations ON ms_outbox(shop_id,status,sent_at)')
    # The process lock guarantees no old worker survives a restart. Recover
    # leases and old, longer backoff periods so saved jobs resume immediately.
    d.execute("UPDATE ms_outbox SET locked_until=0,next_try=0 WHERE status!='sent'")

def meta(kind,ident):
    # IDs come from synced data or checked response IDs, never arbitrary server URLs.
    value=str(uuid.UUID(str(ident)))
    return {'meta':{'href':moysklad.BASE+'entity/'+kind+'/'+value,'type':kind,'mediaType':'application/json'}}

def moment(value):
    return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(timezone(timedelta(hours=3))).strftime('%Y-%m-%d %H:%M:%S')

def shift_time(value):
    """MoySklad can return dates with milliseconds or an explicit UTC offset."""
    if not isinstance(value,str) or not value.strip():return None
    if 'T' not in value and ' ' not in value:return None
    try:
        value=datetime.fromisoformat(value.strip().replace('Z','+00:00'))
        msk=timezone(timedelta(hours=3))
        return value.replace(tzinfo=msk) if value.tzinfo is None else value.astimezone(msk)
    except ValueError:return None

def confirmed_shift_close(remote,remote_id,opened):
    """The shift is closed if the same remote document has a valid close date.

    Its close timestamp may differ from the locally requested one when the
    service normalizes or assigns it. The identity and ordering still matter.
    """
    try:
        if str(uuid.UUID(str(remote.get('id'))))!=str(uuid.UUID(remote_id)):
            raise ValueError()
    except (ValueError,TypeError,AttributeError):
        raise moysklad.SyncError('МойСклад вернул другую смену. Нужна проверка управляющего.') from None
    closed=shift_time(remote.get('closeDate'))
    if closed is None:return False
    # МойСклад хранит время смены с точностью до минуты: смена, открытая в 14:39:05
    # и закрытая в 14:39:40, возвращается как 14:39:00 — это не ошибка. Сравниваем
    # по минутам и с тем началом смены, которое записано в самом МоемСкладе.
    starts=[t for t in (shift_time(opened),shift_time(remote.get('moment'))) if t is not None]
    if not starts:
        raise moysklad.SyncError('Дата закрытия в МоемСкладе раньше открытия смены. Нужна проверка управляющего.')
    start=min(starts).replace(second=0,microsecond=0)
    if closed.replace(second=0,microsecond=0)<start:
        raise moysklad.SyncError('Дата закрытия в МоемСкладе раньше открытия смены. Нужна проверка управляющего.')
    return True

def document_name(d,kind,local_id):
    return 'BM-'+moysklad_bridge.register_id(d)+'-'+(kind+'-' if kind else '')+str(local_id)

def enqueue(d,kind,local_id,payload,shop_id,dependency=None):
    sync=str(uuid.uuid4())
    payload={**payload,'syncId':sync}
    ident=d.execute('INSERT INTO ms_outbox(kind,local_id,sync_id,payload,shop_id,dependency) VALUES(?,?,?,?,?,?)',(kind,local_id,sync,json.dumps(payload,ensure_ascii=False),shop_id,dependency)).lastrowid
    WAKE.set()
    return ident

def shop_meta(d,shop):
    r=d.execute('SELECT * FROM ms_shops WHERE shop_id=?',(shop,)).fetchone()
    if not r:raise moysklad.SyncError('Магазин не связан с торговой точкой. Выполните синхронизацию.')
    return {'retailStore':meta('retailstore',r['retail_id']),'organization':meta('organization',r['organization_uuid']),'store':meta('store',r['store_id'])}

def open_shift(d,shift,user):
    payload={**shop_meta(d,shift['shop_id']),'name':document_name(d,'',shift['id']),
             'moment':moment(shift['opened']),'description':'BeerMag · '+user['name']}
    return enqueue(d,'shift_open',shift['id'],payload,shift['shop_id'])

def pay_split(body):
    """Наличная и безналичная части суммы продажи или возврата (копейки)."""
    if body.get('payment')=='mixed':return int(body['cash_amount']),int(body['card_amount'])
    return (body['total'],0) if body.get('payment')=='cash' else (0,body['total'])

def sale(d,doc,user):
    body=doc['body'];dep=d.execute("SELECT id FROM ms_outbox WHERE kind='shift_open' AND local_id=?",(body['shift_id'],)).fetchone()
    if not dep:raise moysklad.SyncError('Откройте новую смену BeerMag для передачи в МойСклад.')
    positions=[]
    for line in body['lines']:
        p=d.execute('SELECT source_uuid FROM products WHERE id=?',(line['product_id'],)).fetchone()
        if not p or not p['source_uuid']:raise moysklad.SyncError('Товар не связан с МоимСкладом. Обновите каталог.')
        positions.append({'assortment':meta('product',p['source_uuid']),'quantity':line['qty']/1000,'price':line['price'],'discount':0})
    payload={**shop_meta(d,doc['shop_id']),'name':document_name(d,'',doc['id']),
             'moment':moment(doc['created']),'applicable':True,'positions':positions,
             'cashSum':pay_split(body)[0],'noCashSum':pay_split(body)[1],
             'description':'BeerMag · продавец: '+user['name']+' · покупка '+str(doc['id'])}
    # Tax settings are inherited from the existing retail point; do not invent rates.
    return enqueue(d,'sale',doc['id'],payload,doc['shop_id'],dep['id'])

def cash_agent(d,user_id):
    employee=d.execute('SELECT remote_id FROM ms_employees WHERE user_id=?',(user_id,)).fetchone()
    if not employee:
        raise moysklad.SyncError('Сотрудник денежной операции не привязан к МоемуСкладу. Войдите с данными МоегоСклада или привяжите профиль сотрудника и повторите отправку.')
    return meta('employee',employee['remote_id'])

def cash_move(d,movement,user):
    dep=d.execute("SELECT id FROM ms_outbox WHERE kind='shift_open' AND local_id=?",(movement['shift_id'],)).fetchone()
    if not dep:raise moysklad.SyncError('Смена не связана с МоимСкладом.')
    point=shop_meta(d,movement['shop_id'])
    payload={'organization':point['organization'],'agent':cash_agent(d,movement['user_id']),
             'name':document_name(d,'C',movement['id']),
             'moment':moment(movement['created']),'sum':movement['amount'],'applicable':True,
             'description':'BeerMag · '+('внесение' if movement['kind']=='in' else 'выплата')+' · '+movement['note']+' · '+user['name']}
    return enqueue(d,'cash_in' if movement['kind']=='in' else 'cash_out',movement['id'],payload,movement['shop_id'],dep['id'])

def refund(d,doc,user,shift,reason):
    original=d.execute("SELECT * FROM ms_outbox WHERE kind='sale' AND local_id=?",(doc['id'],)).fetchone()
    current=d.execute("SELECT * FROM ms_outbox WHERE kind='shift_open' AND local_id=?",(shift['id'],)).fetchone()
    # Offline refunds are allowed: the return waits in the queue behind the
    # original sale and gets the sale's MoySklad id when it is sent.
    if not original or not current:
        raise moysklad.SyncError('Продажа или смена не связаны с МоимСкладом. Нужна проверка управляющего.')
    source=json.loads(original['payload'])
    payload={**shop_meta(d,doc['shop_id']),'name':document_name(d,'R',doc['id']),
             'moment':moment(datetime.now(timezone.utc).isoformat()),'applicable':True,
             'positions':source['positions'],'cashSum':source['cashSum'],
             'noCashSum':source['noCashSum'],
             'description':'BeerMag · возврат покупки '+str(doc['id'])+' · '+reason+' · '+user['name'],
             '_refund_shift_id':shift['id']}
    return enqueue(d,'refund',doc['id'],payload,doc['shop_id'],original['id'])

def partial_refund(d,doc,return_id,body,user,shift):
    original=d.execute("SELECT * FROM ms_outbox WHERE kind='sale' AND local_id=?",(doc['id'],)).fetchone()
    current=d.execute("SELECT id FROM ms_outbox WHERE kind='shift_open' AND local_id=?",(shift['id'],)).fetchone()
    if not original or not current:
        raise moysklad.SyncError('Продажа или смена не связаны с МоимСкладом. Нужна проверка управляющего.')
    source=json.loads(original['payload'])
    positions=[]
    for line in body['lines']:
        original_line=source['positions'][line['line_index']]
        positions.append({**original_line,'quantity':line['qty']/1000})
    total=body['total']
    payload={**shop_meta(d,doc['shop_id']),'name':document_name(d,'R',str(doc['id'])+'-'+str(return_id)),
             'moment':moment(datetime.now(timezone.utc).isoformat()),'applicable':True,'positions':positions,
             'cashSum':pay_split(body)[0],'noCashSum':pay_split(body)[1],
             'description':'BeerMag · частичный возврат покупки '+str(doc['id'])+' · '+body['reason']+' · '+user['name'],
             '_refund_shift_id':shift['id']}
    return enqueue(d,'partial_refund',return_id,payload,doc['shop_id'],original['id'])

def inventory(d,doc,user):
    """Export immutable inventory batches including zero facts for uncounted stock."""
    base=shop_meta(d,doc['shop_id'])
    positions=[]
    for line in doc['body']['lines']:
        p=d.execute('SELECT source_uuid FROM products WHERE id=?',(line['product_id'],)).fetchone()
        if not p or not p['source_uuid'] or line['qty'] is None:
            raise moysklad.SyncError('В пересчёте есть товар без связи с МоимСкладом или без количества. Обновите каталог.')
        positions.append({'assortment':meta('product',p['source_uuid']),
                          'quantity':line['qty']/1000,
                          'calculatedQuantity':doc['body']['baseline'].get(str(line['product_id']),0)/1000})
    if not positions:raise moysklad.SyncError('В пересчёте нет товаров.')
    for start in range(0,len(positions),400):
        part=start//400+1
        payload={'store':base['store'],'organization':base['organization'],
                 'name':document_name(d,'I',f'{doc["id"]}-{part}'),
                 'moment':moment(datetime.now(timezone.utc).isoformat()),'positions':positions[start:start+400],
                 'description':f'BeerMag · пересчёт {doc["id"]}, часть {part} · {user["name"]}. Расхождения проверяет управляющий в МоемСкладе.'}
        job=enqueue(d,'inventory',doc['id']*1000+part,payload,doc['shop_id'])
        d.execute('INSERT INTO ms_inventory_parts(job_id,document_id,part_no) VALUES(?,?,?)',(job,doc['id'],part))
    return (len(positions)+399)//400

def inventory_status(d,document_id):
    statuses=[r['status'] for r in d.execute('''SELECT o.status FROM ms_inventory_parts p
        JOIN ms_outbox o ON o.id=p.job_id WHERE p.document_id=? ORDER BY p.part_no''',(document_id,))]
    if not statuses:return None
    statuses += [r['status'] for r in d.execute('''SELECT o.status FROM ms_inventory_adjustments a
        JOIN ms_outbox o ON o.id=a.job_id WHERE a.document_id=? ORDER BY a.job_id''',(document_id,))]
    if 'retry' in statuses:return 'retry'
    return 'sent' if all(status=='sent' for status in statuses) else 'pending'

def inventory_adjust(d,doc,user,client):
    """Queue only confirmed differences, with purchase cost fetched by the manager."""
    point=shop_meta(d,doc['shop_id'])
    last=d.execute('''SELECT o.id FROM ms_inventory_parts p JOIN ms_outbox o ON o.id=p.job_id
        WHERE p.document_id=? ORDER BY p.part_no DESC LIMIT 1''',(doc['id'],)).fetchone()
    if not last:raise moysklad.SyncError('Документы пересчёта отсутствуют в очереди.')
    by_kind={'loss':[],'enter':[]}
    # Fetch all prices before enqueuing anything. A missing price must not
    # leave only half of the adjustments queued.
    for line in doc['body']['differences']:
        delta=line['difference']
        if not delta:continue
        product=d.execute('SELECT source_uuid FROM products WHERE id=?',(line['product_id'],)).fetchone()
        if not product or not product['source_uuid']:raise moysklad.SyncError('Товар расхождения не найден в каталоге МоегоСклада.')
        try:price=client.purchase_price(product['source_uuid'])
        except moysklad.SyncError as e:raise moysklad.SyncError(line['name']+': '+str(e)) from None
        by_kind['loss' if delta<0 else 'enter'].append({'assortment':meta('product',product['source_uuid']),
            'quantity':abs(delta)/1000,'price':price})
    jobs=[]
    for kind in ('loss','enter'):
        for start in range(0,len(by_kind[kind]),400):
            part=start//400+1
            payload={'store':point['store'],'organization':point['organization'],
                'name':document_name(d,'I'+('L' if kind=='loss' else 'E'),f'{doc["id"]}-{part}'),
                'moment':moment(datetime.now(timezone.utc).isoformat()),'applicable':True,
                'positions':by_kind[kind][start:start+400],
                'description':f'BeerMag · корректировка по инвентаризации {doc["id"]}, часть {part} · {user["name"]}'}
            job=enqueue(d,kind,doc['id']*1000+part,payload,doc['shop_id'],last['id'])
            d.execute('INSERT INTO ms_inventory_adjustments(job_id,document_id,kind,part_no) VALUES(?,?,?,?)',
                      (job,doc['id'],kind,part))
            jobs.append(job)
    return len(jobs)

def close_shift(d,shift):
    dep=d.execute("SELECT id FROM ms_outbox WHERE kind='shift_open' AND local_id=?",(shift['id'],)).fetchone()
    if not dep:raise moysklad.SyncError('Смена не связана с МоимСкладом.')
    payload={'closeDate':moment(shift['closed'])}
    if shift.get('closing_cash') is not None and shift.get('expected_cash') is not None:
        # The manager sees the cash count in the MoySklad shift itself.
        rub=lambda v:f"{v/100:.2f}".replace('.',',')
        diff=shift['closing_cash']-shift['expected_cash']
        closer=d.execute('SELECT name FROM users WHERE id=?',(shift.get('closed_by') or shift['user_id'],)).fetchone()
        opener=d.execute('SELECT name FROM users WHERE id=?',(shift['user_id'],)).fetchone()
        payload['description']=('BeerMag · смену открыл(а): '+(opener['name'] if opener else '—')+
            ' · закрыл(а): '+(closer['name'] if closer else '—')+' · наличных должно быть '+rub(shift['expected_cash'])+
            ' ₽, посчитано '+rub(shift['closing_cash'])+' ₽'+('' if diff==0 else (' · НЕДОСТАЧА ' if diff<0 else ' · ИЗЛИШЕК ')+rub(abs(diff))+' ₽'))[:4000]
    return enqueue(d,'shift_close',shift['id'],payload,shift['shop_id'],dep['id'])

def public_status(d,document_id):
    r=d.execute("SELECT status FROM ms_outbox WHERE kind='sale' AND local_id=?",(document_id,)).fetchone()
    return r['status'] if r else None

def refund_status(d,document_id):
    r=d.execute("SELECT status FROM ms_outbox WHERE kind='refund' AND local_id=?",(document_id,)).fetchone()
    if r:return r['status']
    states=[row['status'] for row in d.execute("""SELECT o.status FROM sale_returns r JOIN ms_outbox o
        ON o.kind='partial_refund' AND o.local_id=r.id WHERE r.sale_id=?""",(document_id,))]
    if 'retry' in states:return 'retry'
    if 'pending' in states:return 'pending'
    return 'sent' if states else None

def verify_remote(result,job,payload):
    if not isinstance(result,dict) or not result.get('id'):raise moysklad.SyncError('МойСклад не подтвердил номер документа.')
    str(uuid.UUID(result['id']))
    if result.get('syncId')!=job['sync_id']:raise moysklad.SyncError('Не совпал идентификатор отправленного документа. Нужна проверка управляющего.')
    for field in ('retailStore','organization','store'):
        if field in payload and moysklad.ident(result.get(field,{}))!=moysklad.ident(payload[field]):
            raise moysklad.SyncError('Связи документа в МоемСкладе изменены. Нужна проверка управляющего.')
    if job['kind'] in ('sale','refund','partial_refund'):
        expected=payload['cashSum']+payload['noCashSum']
        # МойСклад округляет каждую строку сам; допускаем расхождение не больше копейки на строку,
        # чтобы из-за копейки не остановилась вся очередь магазина. Оплата должна совпасть точно.
        try:drift=abs(float(result.get('sum'))-expected)
        except (TypeError,ValueError):drift=float('inf')
        if result.get('applicable') is not True or drift>len(payload.get('positions',[])) or result.get('cashSum',0)!=payload['cashSum'] or result.get('noCashSum',0)!=payload['noCashSum']:
            raise moysklad.SyncError('Документ найден, но сумма, оплата или проведение не совпали. Нужна проверка управляющего.')
    if job['kind'] in ('refund','partial_refund') and moysklad.ident(result.get('demand',{}))!=moysklad.ident(payload['demand']):
        raise moysklad.SyncError('Возврат не связан с исходной продажей. Нужна проверка управляющего.')
    if job['kind']=='inventory' and result.get('name')!=payload['name']:
        raise moysklad.SyncError('Номер инвентаризации в МоемСкладе не совпал. Нужна проверка управляющего.')
    if job['kind'] in ('loss','enter') and (result.get('name')!=payload['name'] or result.get('applicable') is not True):
        raise moysklad.SyncError('Корректировка остатков не подтверждена. Нужна проверка управляющего.')
    if job['kind'] in ('cash_in','cash_out'):
        if (moysklad.ident(result.get('agent') or {})!=moysklad.ident(payload['agent'])
                or result.get('sum')!=payload['sum'] or result.get('applicable') is not True):
            raise moysklad.SyncError('Сотрудник или сумма денежной операции не совпали в МоемСкладе. Нужна проверка управляющего.')
    return result['id']

def verify_inventory_positions(client,remote_id,payload):
    remote=client.all('entity/inventory/'+str(uuid.UUID(remote_id))+'/positions')
    checked_baseline=all('calculatedQuantity' in p for p in payload['positions'])
    expected={moysklad.ident(p['assortment']):(round(p['quantity']*1000),round(p['calculatedQuantity']*1000))
              if checked_baseline else round(p['quantity']*1000) for p in payload['positions']}
    actual={}
    for p in remote:
        key=moysklad.ident(p.get('assortment',{}))
        if not key or key in actual or p.get('quantity') is None or (checked_baseline and p.get('calculatedQuantity') is None):
            raise moysklad.SyncError('Позиции инвентаризации не подтверждены. Нужна проверка управляющего.')
        try:
            quantity=Decimal(str(p['quantity']))*1000
            calculated=Decimal(str(p['calculatedQuantity']))*1000 if checked_baseline else Decimal(0)
            if not all(x.is_finite() and x==x.to_integral_value() for x in (quantity,calculated)):raise ValueError()
            actual[key]=(int(quantity),int(calculated)) if checked_baseline else int(quantity)
        except (ValueError,InvalidOperation,TypeError):
            raise moysklad.SyncError('Количество в инвентаризации не подтверждено. Нужна проверка управляющего.') from None
    if len(expected)!=len(payload['positions']) or actual!=expected:
        raise moysklad.SyncError('Фактическое количество в МоемСкладе не совпало. Нужна проверка управляющего.')

def verify_adjustment_positions(client,kind,remote_id,payload):
    remote=client.all('entity/'+kind+'/'+str(uuid.UUID(remote_id))+'/positions')
    def signature(p):
        try:
            quantity=Decimal(str(p['quantity']))*1000
            price=Decimal(str(p['price']))
            product=moysklad.ident(p.get('assortment',{}))
            if not product or quantity<=0 or quantity!=quantity.to_integral_value() or price<0:
                raise ValueError()
            return product,int(quantity),price
        except (ValueError,InvalidOperation,TypeError,KeyError):
            raise moysklad.SyncError('Позиции корректировки остатков не подтверждены.') from None
    if Counter(map(signature,remote))!=Counter(map(signature,payload['positions'])):
        raise moysklad.SyncError('Количество или цена в корректировке остатков не совпали. Нужна проверка управляющего.')

def verify_inventory_balance(app,client,document_id,store_id):
    """Do not mark the last adjustment complete until the counted stock is visible."""
    with app.connection() as d:
        document=d.execute('SELECT body FROM documents WHERE id=?',(document_id,)).fetchone()
        if not document:raise moysklad.SyncError('Исходный пересчёт отсутствует.')
        expected={}
        for line in json.loads(document['body'])['lines']:
            product=d.execute('SELECT source_uuid FROM products WHERE id=?',(line['product_id'],)).fetchone()
            if not product or not product['source_uuid']:
                raise moysklad.SyncError('Товар пересчёта больше не связан с МоимСкладом.')
            expected[product['source_uuid']]=line['qty']
    stock=client.stock_for_store(store_id)
    if any(stock.get(key,0)!=value for key,value in expected.items()):
        raise moysklad.SyncError('Документ корректировки создан, но итоговые остатки ещё не совпали с пересчётом. Проверьте склад; повтор будет с тем же номером.')

def verify_sale_positions(client,kind,remote_id,payload):
    """Confirm the exact assortment, quantity and price after a lost response too."""
    remote=client.all('entity/'+kind+'/'+str(uuid.UUID(remote_id))+'/positions')
    def signature(position):
        try:
            product=moysklad.ident(position.get('assortment',{}))
            quantity=Decimal(str(position['quantity']))*1000
            price=Decimal(str(position['price']))
            discount=Decimal(str(position.get('discount',0)))
            if not product or quantity<=0 or quantity!=quantity.to_integral_value() or price<0 or discount!=0:
                raise ValueError()
            return product,int(quantity),price
        except (TypeError,KeyError,ValueError,InvalidOperation):
            raise moysklad.SyncError('Позиции продажи или возврата не подтверждены. Нужна проверка управляющего.') from None
    if Counter(map(signature,remote))!=Counter(map(signature,payload['positions'])):
        raise moysklad.SyncError('Товары, количество или цены в МоемСкладе не совпали. Нужна проверка управляющего.')

def process_one(app,client=None):
    with app.connection(True) as d:
        # Only the oldest unconfirmed job in each store may run. A failed store
        # must not hold up independent registers at the other locations.
        candidates=d.execute('''SELECT q.* FROM ms_outbox q WHERE q.status!='sent'
            AND NOT EXISTS(SELECT 1 FROM ms_outbox older WHERE older.shop_id=q.shop_id
            AND older.id<q.id AND older.status!='sent') ORDER BY q.id''').fetchall()
        job=dep=None
        for row in candidates:
            candidate=dict(row)
            if candidate['kind'] not in ('inventory','loss','enter') and not app.moysklad_bridge.sales_enabled(d):continue
            if candidate['next_try']>time.time() or candidate['locked_until']>time.time():continue
            prerequisite=d.execute('SELECT * FROM ms_outbox WHERE id=?',(candidate['dependency'],)).fetchone() if candidate['dependency'] else None
            if candidate['dependency'] and (not prerequisite or prerequisite['status']!='sent'):continue
            job,dep=candidate,prerequisite
            break
        if job is None:return False
        d.execute('UPDATE ms_outbox SET locked_until=?,attempts=attempts+1 WHERE id=?',(time.time()+180,job['id']))
    try:
        c=client or moysklad.Client();payload=json.loads(job['payload'])
        if job['kind'] in ('cash_in','cash_out') and not payload.get('agent'):
            # Older versions queued cash documents without the required employee.
            # Repair only that field in the saved job; keep its original syncId,
            # dependency, amount and place in the queue across retries.
            with app.connection(True) as d:
                movement=d.execute('SELECT user_id FROM cash_movements WHERE id=?',(job['local_id'],)).fetchone()
                if not movement:raise moysklad.SyncError('Исходная денежная операция отсутствует. Нужна проверка управляющего.')
                payload['agent']=cash_agent(d,movement['user_id'])
                d.execute('UPDATE ms_outbox SET payload=? WHERE id=?',(json.dumps(payload,ensure_ascii=False),job['id']))
        if job['kind']=='shift_close':
            remote_id=dep['remote_id'];target='entity/retailshift/'+str(uuid.UUID(remote_id))
            opened=json.loads(dep['payload'])
            remote=c.get(target)
            if moysklad.ident(remote.get('retailStore') or {})!=moysklad.ident(opened['retailStore']):
                raise moysklad.SyncError('Смена в МоемСкладе принадлежит другой торговой точке. Нужна проверка управляющего.')
            if not confirmed_shift_close(remote,remote_id,opened['moment']):
                c.write('PUT',target,{k:payload[k] for k in ('closeDate','description') if k in payload})
            remote=c.get(target)
            if moysklad.ident(remote.get('retailStore') or {})!=moysklad.ident(opened['retailStore']):
                raise moysklad.SyncError('Смена в МоемСкладе принадлежит другой торговой точке. Нужна проверка управляющего.')
            if not confirmed_shift_close(remote,remote_id,opened['moment']):
                raise moysklad.SyncError('Закрытие смены пока не подтверждено.')
        else:
            kind={'shift_open':'retailshift','sale':'retaildemand','refund':'retailsalesreturn','partial_refund':'retailsalesreturn','inventory':'inventory','loss':'loss','enter':'enter','cash_in':'retaildrawercashin','cash_out':'retaildrawercashout'}.get(job['kind'])
            if not kind:raise moysklad.SyncError('Неизвестная операция очереди.')
            if job['kind'] in ('refund','partial_refund'):
                shift_id=payload.pop('_refund_shift_id')
                with app.connection() as d:
                    shift=d.execute("SELECT remote_id,status FROM ms_outbox WHERE kind='shift_open' AND local_id=?",(shift_id,)).fetchone()
                if not shift or shift['status']!='sent':raise moysklad.SyncError('Смена возврата не подтверждена.')
                payload['retailShift']=meta('retailshift',shift['remote_id'])
                # The dependency is the original sale, confirmed before this job may run.
                if not dep or dep['kind']!='sale' or dep['status']!='sent' or not dep['remote_id']:
                    raise moysklad.SyncError('Исходная продажа ещё не передана.')
                payload['demand']=meta('retaildemand',dep['remote_id'])
            elif dep:payload['retailShift']=meta('retailshift',dep['remote_id'])
            # REMAP makes POST with an existing syncId idempotent. Collection
            # filtering by syncId is not guaranteed for these retail endpoints;
            # a rejected filter used to block the first shift and every later
            # operation in the same store. Retry the same immutable payload,
            # then read the specific returned document for full verification.
            try:created=c.write('POST','entity/'+kind,payload)
            except moysklad.SyncError as error:
                # If this document was created earlier and the reply was lost, some
                # API versions reject the repeated syncId instead of returning it.
                # Find our own document by its unique name and check its syncId.
                code=re.search(r'HTTP (\d{3})',str(error))
                if not code or not code.group(1).startswith('4') or code.group(1) in ('401','403','404','429'):raise
                try:found=[x for x in c.get('entity/'+kind,filter='name='+payload['name'],limit=10).get('rows',[])
                           if isinstance(x,dict) and x.get('syncId')==job['sync_id']]
                except moysklad.SyncError:found=[]
                if len(found)!=1:raise error  # show the original reason to the manager
                created=found[0]
            if not isinstance(created,dict) or not created.get('id'):
                raise moysklad.SyncError('МойСклад не вернул идентификатор документа. Отправка будет проверена повторно.')
            remote_id=str(uuid.UUID(created['id']))
            remote=c.get('entity/'+kind+'/'+remote_id)
            remote_id=verify_remote(remote,job,payload)
            if job['kind']=='inventory':verify_inventory_positions(c,remote_id,payload)
            if job['kind'] in ('loss','enter'):verify_adjustment_positions(c,kind,remote_id,payload)
            if job['kind'] in ('loss','enter'):
                with app.connection() as d:
                    adjustment=d.execute('SELECT document_id FROM ms_inventory_adjustments WHERE job_id=?',(job['id'],)).fetchone()
                    remaining=d.execute('''SELECT COUNT(*) n FROM ms_inventory_adjustments a JOIN ms_outbox o ON o.id=a.job_id
                        WHERE a.document_id=? AND a.job_id!=? AND o.status!='sent' ''',
                        (adjustment['document_id'],job['id'])).fetchone()['n'] if adjustment else 1
                if remaining==0:
                    verify_inventory_balance(app,c,adjustment['document_id'],moysklad.ident(payload['store']))
            if job['kind'] in ('sale','refund','partial_refund'):verify_sale_positions(c,kind,remote_id,payload)
        with app.connection(True) as d:
            confirmed_at=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
            d.execute("UPDATE ms_outbox SET status='sent',remote_id=?,locked_until=0,next_try=0,error='',sent_at=? WHERE id=?",
                      (remote_id,confirmed_at,job['id']))
            if job['kind']=='inventory':
                # The count is complete once every part is in MoySklad; the manager
                # reviews and posts write-offs there, not in the POS.
                row=d.execute('SELECT document_id FROM ms_inventory_parts WHERE job_id=?',(job['id'],)).fetchone()
                if row and inventory_status(d,row['document_id'])=='sent':
                    d.execute("UPDATE documents SET status='exported',version=version+1,updated=? WHERE id=? AND status='submitted'",
                              (confirmed_at,row['document_id']))
            if job['kind'] in ('loss','enter'):
                row=d.execute('SELECT document_id FROM ms_inventory_adjustments WHERE job_id=?',(job['id'],)).fetchone()
                if row and inventory_status(d,row['document_id'])=='sent':
                    d.execute("UPDATE documents SET status='exported',version=version+1,updated=? WHERE id=? AND status='adjusting'",
                              (confirmed_at,row['document_id']))
        return True
    except Exception as e:
        # Do not log raw external responses, tokens or any stock values.
        message=str(e) if isinstance(e,moysklad.SyncError) else 'Не удалось подтвердить отправку. Проверьте подключение и очередь.'
        with app.connection(True) as d:
            d.execute("UPDATE ms_outbox SET status='retry',locked_until=0,error=?,next_try=? WHERE id=?",(message,time.time()+min(60,2*2**min(job['attempts'],5)),job['id']))
        return False

def run(app):
    global WORKER_ERROR
    while True:
        try:
            if moysklad.configured():
                completed=process_one(app)
                WORKER_ERROR=''
                if completed:continue
        except Exception:
            WORKER_ERROR='Очередь не может обработать операцию. Проверьте базу кассы и перезапустите программу.'
        WAKE.wait(2);WAKE.clear()

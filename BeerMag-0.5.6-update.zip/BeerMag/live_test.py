"""Живая проверка работы без интернета на настоящем МоемСкладе (запускается на кассе).

Что делает (2–3 минуты, без участия продавца):
 1. Берёт КОПИЮ базы кассы во временную папку — рабочая база и её очередь не меняются.
 2. «Без интернета»: открывает тестовую смену, пробивает дешёвый товар (пакет) наличными и
    безналом, повторяет один чек тем же ключом, делает частичный и полный возврат,
    внесение и выдачу 10 ₽, закрывает смену. Всё копится в очереди.
 3. «Плохая связь»: передаёт очередь в настоящий МойСклад, специально теряя ответы после
    записи и обрывая запросы, и «перезапускает» кассу посреди передачи.
 4. Проверяет в МоемСкладе: каждый документ ровно один раз, суммы и связи верные.
 5. Удаляет все свои тестовые документы из МоегоСклада (номера BM-TEST…).
Отчёт: data/live-test-report.txt. Деньги и остатки после удаления возвращаются как были.
"""
import json, os, random, secrets, shutil, sqlite3, sys, tempfile, threading, time, uuid, hashlib
import urllib.request, urllib.error
from contextlib import closing
from pathlib import Path

ROOT=Path(__file__).resolve().parent
LINES=[]
STATE={}
MODE='inventory' if '--inventory' in sys.argv else 'sales'
REPORT=ROOT/'data'/('live-test-inventory-report.txt' if MODE=='inventory' else 'live-test-report.txt')
KINDS={'inventory':'inventory','shift_open':'retailshift','sale':'retaildemand','refund':'retailsalesreturn','partial_refund':'retailsalesreturn','cash_in':'retaildrawercashin','cash_out':'retaildrawercashout'}
def say(text=''):
    print(text,flush=True);LINES.append(text)

def token():
    t=os.environ.get('BEERMAG_MOYSKLAD_TOKEN','').strip()
    if t:return t
    import start_moysklad
    return start_moysklad.saved_token()

def cleanup():
    """Удалить из МоегоСклада всё, что создала проверка — и при успехе, и при сбое."""
    if not STATE.get('app'):
        if STATE.get('work'):shutil.rmtree(STATE['work'],ignore_errors=True)
        return
    app,moysklad=STATE['app'],STATE['moysklad']
    say('\nУдаляем тестовые документы из МоегоСклада')
    with app.connection() as d:
        rows=[dict(r) for r in d.execute('SELECT kind,remote_id FROM ms_outbox WHERE id>=? AND remote_id IS NOT NULL',(STATE['first'],))]
    order=['inventory','retailsalesreturn','retaildemand','retaildrawercashin','retaildrawercashout','retailshift']
    for kind in order:
        for r in rows:
            if KINDS.get(r['kind'])!=kind:continue
            req=urllib.request.Request(moysklad.BASE+'entity/'+kind+'/'+r['remote_id'],method='DELETE',
                headers={'Authorization':'Bearer '+STATE['tok'],'Accept-Encoding':'gzip'})
            try:urllib.request.urlopen(req,timeout=20).read();say(f'   удалён {kind} {r["remote_id"][:8]}…')
            except (urllib.error.URLError,OSError) as e:
                say(f'   НЕ удалён {kind} {r["remote_id"]} — удалите вручную (номер {STATE["tag"]})')
    shutil.rmtree(STATE['work'],ignore_errors=True);STATE.clear()

def main():
    tok=token()
    if not tok:raise SystemExit('Нет сохранённого API-токена. Сначала запустите кассу через START_WINDOWS.bat.')
    os.environ['BEERMAG_MOYSKLAD_TOKEN']=tok
    source=ROOT/'data'/'beerdesk.sqlite3'
    if not source.exists():raise SystemExit('База кассы не найдена.')
    with closing(sqlite3.connect(source)) as real:
        if real.execute('SELECT 1 FROM shifts WHERE closed IS NULL LIMIT 1').fetchone():
            raise SystemExit('На этой кассе открыта смена. Запустите проверку после закрытия смены (или до открытия).')
    work=Path(tempfile.mkdtemp(prefix='beermag-live-test-'));STATE['work']=work
    copy=work/'copy.sqlite3'
    with closing(sqlite3.connect(source)) as a,closing(sqlite3.connect(copy)) as b:a.backup(b)
    os.environ['BEERDESK_DB']=str(copy)
    sys.path.insert(0,str(ROOT))
    import server as app, moysklad, moysklad_outbox as outbox
    app.DB=copy;app.init()
    say('БирМаг · живая проверка '+('инвентаризации' if MODE=='inventory' else 'без интернета')+' · '+time.strftime('%d.%m.%Y %H:%M'))
    say('Папка кассы: '+str(ROOT))
    say('Рабочая база не меняется: используется копия '+str(copy))
    with app.connection(True) as d:
        # Только тестовые документы: чужая очередь копии не отправляется, номер кассы — TEST.
        d.execute("UPDATE ms_outbox SET status='sent' WHERE status!='sent'")
        tag='TEST'+secrets.token_hex(3).upper()
        d.execute("INSERT INTO ms_options(key,value) VALUES('register_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(tag,))
        d.execute("UPDATE shifts SET closed=COALESCE(closed,?) WHERE closed IS NULL",(app.now(),))
        d.execute("UPDATE documents SET status='cancelled' WHERE type='inventory' AND status='draft'")
        shop=app.moysklad_bridge.bound_shop(d) or (d.execute('SELECT shop_id FROM ms_shops ORDER BY shop_id LIMIT 1').fetchone() or [None])[0]
        if not shop:
            shops=d.execute('SELECT COUNT(*) FROM ms_shops').fetchone()[0]
            sales=d.execute("SELECT COUNT(*) FROM documents WHERE type='sale'").fetchone()[0]
            raise SystemExit('Касса не связана с точкой продаж: в этой папке ('+str(ROOT)+') торговые точки из МоегоСклада '
                             'ещё не загружены (точек: %d, продаж в базе: %d). Скорее всего проверка запущена не из той папки, '
                             'где работает касса. Запустите ПРОВЕРКА_ИНВЕНТАРИЗАЦИИ.bat из рабочей папки кассы '
                             '(или сначала войдите в кассу управляющим и дождитесь загрузки из МоегоСклада).'%(shops,sales))
        user=d.execute('''SELECT u.* FROM users u JOIN ms_employees m ON m.user_id=u.id
            WHERE u.active=1 AND m.remote_archived=0 ORDER BY (u.role='manager') DESC,u.id LIMIT 1''').fetchone()
        if not user:raise SystemExit('Нет сотрудника, связанного с МоимСкладом. Войдите в кассу через МойСклад и повторите.')
        if user['role']=='seller' and shop not in json.loads(user['shops']):
            d.execute('UPDATE users SET shops=? WHERE id=?',(json.dumps([shop]),user['id']))
        session=secrets.token_urlsafe(24)
        d.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(session.encode()).hexdigest(),user['id'],int(time.time())+3600))
        d.execute("INSERT INTO ms_options VALUES('sales_enabled','1') ON CONFLICT(key) DO UPDATE SET value='1'")
        bag=d.execute("SELECT * FROM products WHERE active=1 AND source_code='01872'").fetchone() or \
            d.execute("SELECT * FROM products WHERE active=1 AND kind IN ('piece','packaging') AND price>0 AND source_uuid!='' ORDER BY price LIMIT 1").fetchone()
        if not bag:raise SystemExit('Не найден дешёвый штучный товар для проверки (например «Пакет Майка»).')
        weight=d.execute("SELECT * FROM products WHERE active=1 AND kind='weight' AND price>0 AND source_uuid!='' ORDER BY price LIMIT 1").fetchone()
        shop_name=d.execute('SELECT name FROM shops WHERE id=?',(shop,)).fetchone()[0]
    say(f'Точка: {shop_name} · сотрудник: {user["name"]} · товар: {bag["name"]} ({bag["price"]/100:.2f} ₽) · номер теста: {tag}')

    http=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
    threading.Thread(target=http.serve_forever,daemon=True).start()
    url='http://127.0.0.1:%d'%http.server_port
    def call(path,body=None,key=None):
        req=urllib.request.Request(url+path,data=json.dumps(body).encode() if body is not None else None,
            headers={'X-BeerDesk':'1','Content-Type':'application/json','Idempotency-Key':key or str(uuid.uuid4()),'Cookie':'beerdesk='+session})
        try:
            with urllib.request.urlopen(req) as r:return json.load(r)
        except urllib.error.HTTPError as e:raise SystemExit('Касса отказала: '+path+' · '+json.load(e).get('error',''))

    class Flaky:
        """Настоящий клиент МоегоСклада, которому «мешает» плохая связь."""
        mode='offline';rng=random.Random(7)
        def __init__(self):self.real=moysklad.Client()
        def _before(self):
            if Flaky.mode=='offline':raise moysklad.ConnectivityError('Нет интернета (проверка)')
            if Flaky.rng.random()<.15:raise moysklad.SyncError('Обрыв до отправки (проверка)')
        def get(self,*a,**k):self._before();return self.real.get(*a,**k)
        def all(self,*a,**k):self._before();return self.real.all(*a,**k)
        def write(self,*a,**k):
            self._before();result=self.real.write(*a,**k)
            if Flaky.rng.random()<.35:raise moysklad.SyncError('Ответ потерян после записи (проверка)')
            return result
        def stock_for_store(self,*a):self._before();return self.real.stock_for_store(*a)

    def pump():
        """Передать очередь при плохой связи, как настоящая касса (с паузами и «перезапусками»)."""
        Flaky.mode='bad';steps=0;seen={};started=time.time()
        while True:
            with app.connection(True) as d:
                # Как настоящая касса: паузы между попытками не больше 3 с (МойСклад ограничивает
                # число запросов в секунду; без пауз он отвечает 429 и очередь стоит).
                d.execute("UPDATE ms_outbox SET next_try=MIN(next_try,?) WHERE status!='sent'",(time.time()+3,))
                if steps and steps%5==0:outbox.init(d)
                left=[dict(r) for r in d.execute("SELECT id,kind,attempts,error FROM ms_outbox WHERE status!='sent' ORDER BY id")]
            for job in left:
                if job['error'] and not job['error'].endswith('(проверка)'):
                    seen.setdefault((job['kind'],job['error']),0);seen[(job['kind'],job['error'])]+=1
            if not left:break
            if time.time()-started>480:
                say('   НЕ ПЕРЕДАНО за 8 минут. Застряла операция: '+left[0]['kind']+' · попыток '+str(left[0]['attempts']))
                for (kind,err),n in sorted(seen.items(),key=lambda x:-x[1])[:8]:say(f'   ошибка МоегоСклада ({kind}, {n} раз): {err}')
                raise SystemExit('Очередь не передалась — ошибки выше, отправьте отчёт разработчику')
            if outbox.process_one(app,Flaky()):steps+=1
            time.sleep(.6)
        if seen:
            say('   по пути МойСклад отвечал ошибками (касса их пережила):')
            for (kind,err),n in sorted(seen.items(),key=lambda x:-x[1])[:6]:say(f'     {kind}: {err} ×{n}')
        say(f'   вся очередь передана за {int(time.time()-started)} с ✓')

    if MODE=='inventory':return inventory_flow(app,outbox,moysklad,call,Flaky,pump,shop,bag,tag,tok)
    price=bag['price']
    def sale(count,payment,key=None):
        body={'shop_id':shop,'payment':payment,'expected_total':price*count/100,'lines':[{'product_id':bag['id'],'qty':count}]}
        if payment=='cash':body['received']=str(price*count/100)
        return call('/api/sales',body,key)
    say('\n1) Нет интернета — работаем как обычно')
    call('/api/shifts/open',{'shop_id':shop,'cash':'10'})
    s1=sale(1,'cash');s2=sale(2,'card');key=str(uuid.uuid4());s3=sale(1,'cash',key)
    dup=sale(1,'cash',key)   # тот же чек ещё раз — как двойное нажатие или потерянный ответ
    say('   смена открыта, 3 чека; повтор третьего чека тем же ключом: '+('второго чека нет ✓' if dup.get('duplicate') else 'ОШИБКА — создан второй чек'))
    if weight:   # 0.5.3: сложная оплата + весовой товар (проверка копеек как в МоемСкладе)
        total=app.amount(weight['price'],285)+price
        mixed=call('/api/sales',{'shop_id':shop,'payment':'mixed','cash_amount':f'{(total//2)/100:.2f}','expected_total':total/100,
                                 'lines':[{'product_id':weight['id'],'qty':0.285},{'product_id':bag['id'],'qty':1}]})
        say(f"   сложная оплата: {weight['name']} 0,285 кг + пакет = {total/100:.2f} ₽ (наличными {mixed['body']['cash_amount']/100:.2f}, картой {mixed['body']['card_amount']/100:.2f}) ✓")
    call('/api/sales/refund',{'shop_id':shop,'id':s2['id'],'reason':'проверка: частичный','money_returned':True,'lines':[{'line_index':0,'qty':1}]})
    call('/api/sales/refund',{'shop_id':shop,'id':s1['id'],'reason':'проверка: полный','money_returned':True})
    call('/api/cash/move',{'shop_id':shop,'kind':'out','amount':'10','note':'проверка'})
    expected=call('/api/shift?shop_id='+str(shop))['totals']['cash_on_hand']
    call('/api/shifts/close',{'shop_id':shop,'cash':f'{expected/100:.2f}'})
    with app.connection() as d:
        jobs=[dict(r) for r in d.execute("SELECT * FROM ms_outbox WHERE status!='sent' ORDER BY id")]
    for _ in range(3):outbox.process_one(app,Flaky())
    say(f'   возвраты, выдача денег, закрытие смены — в очереди {len(jobs)} операций, в МойСклад ничего не ушло ✓')

    STATE.update(app=app,first=jobs[0]['id'],tok=tok,moysklad=moysklad,tag=tag)
    say('\n2) Связь появилась, но плохая: обрывы, потерянные ответы, перезапуски кассы')
    pump()

    say('\n3) Сверка с МоимСкладом')
    client=moysklad.Client();ok=True;created=[]
    with app.connection() as d:
        done=[dict(r) for r in d.execute('SELECT * FROM ms_outbox WHERE id>=? ORDER BY id',(jobs[0]['id'],))]
    for job in done:
        if job['kind']=='shift_close':continue
        kind=KINDS[job['kind']];name=json.loads(job['payload'])['name']
        rows=client.get('entity/'+kind,filter='name='+name,limit=10).get('rows',[])
        mine=[r for r in rows if r.get('syncId')==job['sync_id']]
        created.append((kind,job['remote_id']))
        good=len(rows)==1 and len(mine)==1
        payload=json.loads(job['payload']);extra=''
        if good and job['kind'] in ('sale','refund','partial_refund'):
            doc=mine[0];paid=payload['cashSum']+payload['noCashSum']
            same=doc.get('sum')==paid and doc.get('cashSum')==payload['cashSum'] and doc.get('noCashSum')==payload['noCashSum']
            extra=f" сумма {doc.get('sum',0)/100:.2f} = нал {doc.get('cashSum',0)/100:.2f} + безнал {doc.get('noCashSum',0)/100:.2f} "+('✓' if same else '✗ копейки не совпали')
            good&=same
        ok&=good
        say(f'   {name:<22} {kind:<20} в МоемСкладе: {len(rows)} шт. '+('✓' if good else '✗ ДУБЛЬ/НЕТ')+extra)
    shift=client.get('entity/retailshift/'+[r for k,r in created if k=='retailshift'][0])
    closed=bool(shift.get('closeDate'));ok&=closed
    say('   смена закрыта в МоемСкладе: '+('да ✓' if closed else 'нет ✗'))
    say('\nИТОГ: '+('всё передано ровно один раз, дублей нет ✓' if ok else 'НАЙДЕНЫ ПРОБЛЕМЫ — отправьте этот отчёт разработчику'))

    http.shutdown()
    return ok

def inventory_flow(app,outbox,moysklad,call,Flaky,pump,shop,bag,tag,tok):
    """Пересчёт по местам → отправка в МойСклад при плохой связи → сверка → удаление."""
    with app.connection() as d:
        store=d.execute('SELECT store_id FROM ms_shops WHERE shop_id=?',(shop,)).fetchone()[0]
        weight=d.execute("SELECT * FROM products WHERE active=1 AND kind='weight' AND source_uuid!='' ORDER BY name LIMIT 1").fetchone()
    say('\n1) Считаем магазин по местам (без связи с МоимСкладом)')
    r=call('/api/inventory/start',{'shop_id':shop,'zones':['Витрина (проверка)','Подсобка (проверка)']})
    a,b=r['body']['zones']
    put=lambda z,items,rev,done:call('/api/inventory/zone',{'shop_id':shop,'id':r['id'],'rev':rev,'zone':{'id':z['id'],'name':z['name'],'done':done,'items':items}})
    put(a,[{'product_id':bag['id'],'qty':'3'}],0,True)
    items=[{'product_id':bag['id'],'qty':'2'}]+([{'product_id':weight['id'],'qty':'1.25'}] if weight else [])
    put(b,items,0,True)
    blocked=False
    try:call('/api/sales',{'shop_id':shop,'payment':'card','expected_total':bag['price']/100,'lines':[{'product_id':bag['id'],'qty':1}]})
    except SystemExit as e:blocked='пересч' in str(e).lower() or 'смен' in str(e).lower()
    say('   два места посчитаны: '+bag['name']+' 3 + 2'+(', '+weight['name']+' 1,25 кг' if weight else '')+(' · продажи во время пересчёта закрыты ✓' if blocked else ''))
    say('\n2) Отправляем: касса читает текущие остатки склада из МоегоСклада')
    current=call('/api/document?shop_id=%d&id=%d'%(shop,r['id']))
    sent=call('/api/inventory/send',{'shop_id':shop,'id':r['id'],'version':current['version']})
    with app.connection() as d:
        jobs=[dict(x) for x in d.execute("""SELECT o.* FROM ms_outbox o JOIN ms_inventory_parts p ON p.job_id=o.id
            WHERE p.document_id=? ORDER BY p.part_no""",(r['id'],))]
        body=json.loads(d.execute('SELECT body FROM documents WHERE id=?',(r['id'],)).fetchone()[0])
    STATE.update(app=app,first=jobs[0]['id'],tok=tok,moysklad=moysklad,tag=tag)
    zeros=sum(1 for x in body['lines'] if x.get('auto_zero'))
    say(f'   в пересчёте {len(body["lines"])} позиций, из них {zeros} с учётным остатком, но не найдены (факт 0); частей документа: {len(jobs)}')
    Flaky.mode='bad'
    say('\n3) Передача при плохой связи')
    pump()
    say('\n4) Сверка с МоимСкладом')
    client=moysklad.Client();ok=True
    stock=client.stock_for_store(store)
    with app.connection() as d:
        jobs=[dict(d.execute('SELECT * FROM ms_outbox WHERE id=?',(j['id'],)).fetchone()) for j in jobs]
    for job in jobs:
        payload=json.loads(job['payload'])
        rows=client.get('entity/inventory',filter='name='+payload['name'],limit=10).get('rows',[])
        mine=[x for x in rows if x.get('syncId')==job['sync_id']]
        remote=client.all('entity/inventory/'+job['remote_id']+'/positions') if job['remote_id'] else []
        good=len(rows)==1 and len(mine)==1 and len(remote)==len(payload['positions'])
        ok&=good
        say(f'   {payload["name"]:<22} в МоемСкладе: {len(rows)} шт., позиций {len(remote)} из {len(payload["positions"])} '+('✓' if good else '✗'))
        for p in remote:
            key=moysklad.ident(p.get('assortment',{}))
            if key==bag['source_uuid']:
                q=round(p['quantity']*1000);c=round(p.get('calculatedQuantity',0)*1000)
                good=q==5000 and c==stock.get(key,0);ok&=good
                say(f'   {bag["name"]}: факт {q/1000:g}, учётный {c/1000:g} (склад сейчас {stock.get(key,0)/1000:g}) '+('✓' if good else '✗'))
            if weight and key==weight['source_uuid']:
                good=round(p['quantity']*1000)==1250;ok&=good
                say(f'   {weight["name"]}: факт {p["quantity"]:g} кг '+('✓' if good else '✗'))
    status=call('/api/document?shop_id=%d&id=%d'%(shop,r['id']))['status']
    ok&=status=='exported'
    say('   пересчёт в кассе завершён после приёма МоимСкладом: '+('да ✓' if status=='exported' else 'нет ✗ ('+status+')'))
    say('   остатки склада НЕ изменились (инвентаризация МоегоСклада их не меняет) ✓' if client.stock_for_store(store)==stock else '   ✗ остатки склада изменились')
    say('\nИТОГ: '+('инвентаризация передана ровно один раз, количества верные ✓' if ok else 'НАЙДЕНЫ ПРОБЛЕМЫ — отправьте этот отчёт разработчику'))
    return ok

if __name__=='__main__':
    try:result=main()
    except SystemExit as e:say('\nПроверка остановлена: '+str(e));result=False
    except Exception as e:say('\nПроверка остановлена из-за ошибки: '+type(e).__name__+': '+str(e));result=False
    finally:
        try:cleanup()
        except Exception as e:say('Удаление тестовых документов не завершено: '+str(e))
    REPORT.parent.mkdir(exist_ok=True);REPORT.write_text('\n'.join(LINES),encoding='utf-8')
    print('\nОтчёт сохранён: '+str(REPORT))

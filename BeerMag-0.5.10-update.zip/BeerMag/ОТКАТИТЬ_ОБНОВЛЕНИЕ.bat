@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
echo Откат кассы BeerMag к версии, стоявшей до последнего обновления.
echo Сначала закройте кассу: значок БирМаг у часов, правая кнопка, «Выход».
echo.
"%~dp0runtime\python.exe" update.py --rollback
pause

@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
echo Пробная касса первой получает новые версии BeerMag. Остальные кассы получают их,
echo когда владелец подтвердит, что на пробной кассе всё работает. Нужна одна пробная касса.
echo.
"%~dp0runtime\python.exe" autoupdate.py
echo.
set /p answer=1 - сделать пробной, 2 - сделать обычной, Enter - ничего не менять: 
if /i "%answer%"=="1" "%~dp0runtime\python.exe" autoupdate.py --pilot-on
if /i "%answer%"=="2" "%~dp0runtime\python.exe" autoupdate.py --pilot-off
pause

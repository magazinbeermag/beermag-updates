"""Offline update from an official BeerMag ZIP; keeps data and restores code on failure."""
import argparse
import io
import json
import os
import re
import shutil
import socket
import sqlite3
import stat
import tempfile
import zipfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import app_lock


def members(archive,keep=()):
    files = []
    seen = set()
    with zipfile.ZipFile(archive) as package:
        if sum(i.file_size for i in package.infolist()) > 1_000_000_000:
            raise ValueError('Архив слишком большой.')
        if package.testzip():
            raise ValueError('Архив повреждён.')
        for info in package.infolist():
            if '\\' in info.filename or ':' in info.filename:
                raise ValueError('В архиве обнаружен недопустимый путь.')
            path = PurePosixPath(info.filename)
            if info.is_dir():
                continue
            if path.is_absolute() or len(path.parts)<2 or path.parts[0]!='BeerMag' or any(p in ('..','') for p in path.parts):
                raise ValueError('В архиве обнаружен недопустимый путь.')
            relative = Path(*path.parts[1:])
            # The Windows launcher is the currently executing batch file.
            if relative==Path('UPDATE_WINDOWS.bat') or relative.as_posix() in keep:
                continue
            if relative.parts[0] in ('data','demo_data','updates') or relative.suffix=='.pyc':
                raise ValueError('Архив пытается изменить данные кассы.')
            if stat.S_ISLNK(info.external_attr >> 16) or relative in seen:
                raise ValueError('В архиве обнаружена ссылка или повторяющийся файл.')
            seen.add(relative)
            files.append((info,relative))
        if not {Path('server.py'),Path('web/app.js'),Path('README.md')}.issubset(seen):
            raise ValueError('Это не полный архив программы BeerMag.')
        runtime=package.getinfo('BeerMag/runtime/python313.zip') if Path('runtime/python313.zip') in seen else None
        if runtime:
            try:
                with zipfile.ZipFile(io.BytesIO(package.read(runtime))) as standard:
                    if 'encodings/__init__.pyc' not in standard.namelist() or standard.testzip():
                        raise ValueError('Встроенный Python повреждён: нет стандартной библиотеки.')
            except (zipfile.BadZipFile,EOFError):
                raise ValueError('Встроенный Python повреждён: не читается стандартная библиотека.') from None
    return files


def snapshot_database(root,stamp):
    database=root/'data'/'beerdesk.sqlite3'
    if not database.exists():
        return None
    destination=root/'data'/'backups'/('beerdesk-before-update-'+stamp+'.sqlite3')
    destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix('.tmp')
    try:
        with closing(sqlite3.connect(database)) as source,closing(sqlite3.connect(temporary)) as target:
            source.backup(target)
        with closing(sqlite3.connect(temporary)) as check:
            if check.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                raise sqlite3.DatabaseError('Резервная копия повреждена.')
        os.replace(temporary,destination)
    finally:
        try:temporary.unlink(missing_ok=True)
        except OSError:pass  # A cleanup failure must not mask the backup error.
    return destination


BACKUP_INFO='_beermag_backup.json'
BLOCKED='update-blocked.json'


def register_closed():
    # The lock is understood by this and subsequent releases. Also catch a
    # standard-port process running a release from before the lock existed.
    for port in (8765,8766):
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.15):
                raise RuntimeError('Закройте окно работающей кассы и демо перед обновлением.')
        except (ConnectionRefusedError,TimeoutError,OSError):
            pass


def program_version(folder):
    try:m=re.search(r'BeerMag (\d+\.\d+\.\d+)',(Path(folder)/'server.py').read_text(encoding='utf-8')[:200])
    except OSError:return ''
    return m.group(1) if m else ''


def blocked_versions(root):
    try:return {str(x) for x in json.loads((Path(root)/'data'/BLOCKED).read_text(encoding='utf-8'))}
    except (OSError,ValueError,TypeError):return set()


def block_version(root,version):
    """Отозванную на этой кассе версию автообновление больше не скачивает (ждёт следующую)."""
    if not version:return
    path=Path(root)/'data'/BLOCKED;path.parent.mkdir(parents=True,exist_ok=True)
    versions=sorted(blocked_versions(root)|{version})
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(versions),encoding='utf-8');os.replace(temporary,path)


def last_backup(root):
    """Самая свежая неиспользованная копия прежней версии (папки before-<время> сортируются по времени)."""
    folders=sorted(p for p in (Path(root)/'updates').glob('before-*') if p.is_dir())
    return folders[-1] if folders else None


def backup_info(backup):
    try:info=json.loads((backup/BACKUP_INFO).read_text(encoding='utf-8'))
    except (OSError,ValueError):info={}
    if 'existed' not in info:   # копия от 0.5.8 и раньше: описи нет, возвращаем то, что в ней лежит
        info['existed']=sorted(p.relative_to(backup).as_posix() for p in backup.rglob('*') if p.is_file() and p.name!=BACKUP_INFO)
        info['files']=info['existed']
    return info


def restore_database(root,snapshot,label):
    """Вернуть базу из копии, сделанной перед обновлением. Текущая база откладывается рядом, не удаляется."""
    database=root/'data'/'beerdesk.sqlite3'
    aside=root/'data'/'backups'/('beerdesk-failed-update-'+label+'.sqlite3')
    aside.parent.mkdir(parents=True,exist_ok=True)
    if database.exists():
        with closing(sqlite3.connect(database)) as source,closing(sqlite3.connect(aside)) as target:
            source.backup(target)
    temporary=database.with_suffix('.restore')
    shutil.copy2(snapshot,temporary)
    with closing(sqlite3.connect(temporary)) as check:
        ok=check.execute('PRAGMA quick_check').fetchone()[0]=='ok'
    if not ok:
        temporary.unlink(missing_ok=True);raise sqlite3.DatabaseError('Копия базы перед обновлением повреждена.')
    for leftover in (Path(str(database)+'-wal'),Path(str(database)+'-shm')):
        leftover.unlink(missing_ok=True)
    os.replace(temporary,database)
    return aside


def rollback(root,restore_db=False):
    """Вернуть файлы программы, какими они были до последнего обновления, и отозвать новую версию.

    restore_db=True только при автооткате, когда новая версия ни разу не запустилась
    (продаж в ней не было): тогда база тоже возвращается к копии перед обновлением.
    """
    root=Path(root).resolve()
    backup=last_backup(root)
    if not backup:raise ValueError('Нет сохранённой прежней версии: откатывать не к чему.')
    info=backup_info(backup)
    bad=program_version(root)
    with app_lock.exclusive(root/'data'/'beermag.lock'):
        register_closed()
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        existed=set(info['existed'])
        # Запущенный bat-файл отката под cmd.exe не переписывается и не удаляется.
        running={'ОТКАТИТЬ_ОБНОВЛЕНИЕ.bat'}
        for name in info['files']:
            if name not in existed and name not in running:(root/name).unlink(missing_ok=True)   # файл появился только в новой версии
        for name in info['existed']:
            if name in running:continue
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(backup/name,target)
        aside=None
        snapshot=root/'data'/'backups'/info['snapshot'] if info.get('snapshot') else None
        if restore_db and snapshot and snapshot.is_file():
            aside=restore_database(root,snapshot,(bad or 'unknown')+'-'+stamp)
        block_version(root,bad or info.get('to',''))
        # Копия использована: повторный откат не должен вернуть её ещё раз.
        os.replace(backup,backup.with_name('used-'+backup.name))
    return {'from':bad or info.get('to',''),'to':program_version(root) or info.get('from',''),
            'database_restored':bool(aside),'failed_database':str(aside) if aside else ''}


def install(archive,root,keep=()):
    root=Path(root).resolve()
    files=members(archive,keep)
    # Do not overwrite the interpreter that is executing this updater on Windows.
    if (root/'runtime'/'python.exe').is_file():
        files=[(info,path) for info,path in files if path.parts[0]!='runtime']
    if not (root/'server.py').is_file():
        raise ValueError('Запускайте обновление из установленной папки BeerMag.')
    with app_lock.exclusive(root/'data'/'beermag.lock'):
        register_closed()
        stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        with tempfile.TemporaryDirectory(prefix='beermag-update-',dir=root.parent) as temporary:
            staging=Path(temporary)/'new'; staging.mkdir()
            with zipfile.ZipFile(archive) as package:
                for info,relative in files:
                    target=staging/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    with package.open(info) as source,target.open('wb') as output:
                        shutil.copyfileobj(source,output)
            snapshot=snapshot_database(root,stamp)
            backup=root/'updates'/('before-'+stamp)
            existed=[]
            for _,relative in files:
                existing=root/relative
                if existing.exists():
                    target=backup/relative;target.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(existing,target);existed.append(relative)
            # Опись копии: по ней откат вернёт прежние файлы и уберёт добавленные обновлением.
            backup.mkdir(parents=True,exist_ok=True)
            (backup/BACKUP_INFO).write_text(json.dumps({
                'from':program_version(root),'to':program_version(staging),'created':stamp,
                'snapshot':snapshot.name if snapshot else '',
                'files':[x.as_posix() for _,x in files],'existed':[x.as_posix() for x in existed]},
                ensure_ascii=False,indent=1),encoding='utf-8')
            changed=[]
            try:
                for _,relative in files:
                    destination=root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                    os.replace(staging/relative,destination)
                    changed.append(relative)
            except Exception:
                for relative in reversed(changed):
                    previous=backup/relative
                    if previous.exists():shutil.copy2(previous,root/relative)
                    else:(root/relative).unlink(missing_ok=True)
                raise
    return snapshot,backup


def manual_rollback(parser):
    """ОТКАТИТЬ_ОБНОВЛЕНИЕ.bat: вернуть прежнюю версию программы. База и продажи остаются как есть."""
    root=Path(__file__).resolve().parent
    backup=last_backup(root)
    if not backup:parser.exit(1,'Нет сохранённой прежней версии: откатывать не к чему.\n')
    info=backup_info(backup)
    print('Сейчас установлена версия: '+(program_version(root) or 'неизвестна'))
    print('Будет возвращена версия:  '+(info.get('from') or 'предыдущая (копия от '+backup.name[7:15]+')'))
    print('Продажи, смены и настройки кассы сохранятся. Отозванную версию касса больше не скачает,')
    print('следующее исправленное обновление установится как обычно.')
    if input('Откатить обновление? (д/н): ').strip().lower() not in ('д','да','y','yes'):parser.exit(0,'Отменено.\n')
    try:result=rollback(root)
    except (OSError,ValueError,RuntimeError,sqlite3.Error) as error:
        parser.exit(1,'Откат не выполнен: '+str(error)+'\n')
    (root/'data'/'update-probation.json').unlink(missing_ok=True)
    print('Готово: версия '+result['from']+' отозвана, касса возвращена к версии '+(result['to'] or 'предыдущей')+'.')
    print('Теперь запустите кассу ярлыком «Касса БирМаг».')


def main():
    parser=argparse.ArgumentParser(description='Обновить BeerMag из нового ZIP')
    parser.add_argument('archive',nargs='?',help='Новый архив BeerMag-...-Windows.zip')
    parser.add_argument('--rollback',action='store_true',help='Вернуть версию, стоявшую до последнего обновления')
    args=parser.parse_args()
    if args.rollback:return manual_rollback(parser)
    if not args.archive:
        # Двойной щелчок без файла: ищем самый новый архив в «Загрузках» и рядом с папкой кассы.
        import re
        here=Path(__file__).resolve().parent
        places=[Path(os.environ.get('USERPROFILE',str(Path.home())))/'Downloads',here.parent,here]
        found=[]
        for place in places:
            try:found+=[p for p in place.glob('BeerMag-*-Windows*.zip') if p.is_file()]
            except OSError:pass
        def version(p):
            m=re.search(r'BeerMag-(\d+(?:\.\d+)+)',p.name);return tuple(int(x) for x in m.group(1).split('.')) if m else ()
        if not found:parser.exit(1,'Архив обновления не найден в «Загрузках». Перетащите файл BeerMag-...-Windows.zip на UPDATE_WINDOWS.bat.\n')
        best=max(found,key=lambda p:(version(p),p.stat().st_mtime))
        print('Найден архив: '+str(best))
        if input('Установить это обновление? (д/н): ').strip().lower() not in ('д','да','y','yes'):parser.exit(0,'Отменено.\n')
        args.archive=str(best)
    try:
        snapshot,backup=install(Path(args.archive).resolve(),Path(__file__).resolve().parent)
    except (OSError,ValueError,RuntimeError,sqlite3.Error,zipfile.BadZipFile) as error:
        parser.exit(1,'Обновление отменено: '+str(error)+'\n')
    print('Файлы программы обновлены. Папка data сохранена.')
    if snapshot:print('Копия базы перед обновлением: '+str(snapshot))
    print('Предыдущие файлы программы: '+str(backup))
    print('Теперь запустите BeerMag обычным способом.')


if __name__=='__main__':
    main()

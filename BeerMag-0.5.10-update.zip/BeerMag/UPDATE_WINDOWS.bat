@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
echo Обновление кассы BeerMag. Сначала закройте окно работающей кассы.
"%~dp0runtime\python.exe" update.py %1
pause

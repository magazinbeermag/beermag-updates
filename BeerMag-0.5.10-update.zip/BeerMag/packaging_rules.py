"""Local packaging choices, independent of the upstream catalogue price/stock."""
SLOTS=[('cup-500',500,'Стаканчик 0,5 л'),('bottle-500',500,'Бутылка 0,5 л'),('bottle-1000',1000,'Бутылка 1 л'),('bottle-1500',1500,'Бутылка 1,5 л'),('bottle-2000',2000,'Бутылка 2 л')]

def init(d):
    d.execute('CREATE TABLE IF NOT EXISTS packaging_choices(slot TEXT PRIMARY KEY, product_id INTEGER REFERENCES products(id), enabled INTEGER NOT NULL DEFAULT 1)')

def rules(d):
    saved={r['slot']:dict(r) for r in d.execute('SELECT * FROM packaging_choices')}
    old={r['volume']:r['product_id'] for r in d.execute('SELECT * FROM packaging')}
    codes={'cup-500':'01970','bottle-500':'02227','bottle-1000':'02064','bottle-1500':'01383','bottle-2000':'00269'}
    output=[]
    for slot,volume,label in SLOTS:
        matches=list(d.execute("SELECT id FROM products WHERE source_code=? AND kind IN ('piece','packaging')",(codes[slot],)))
        # Source code is stable across imports; never create or guess another product.
        pid=matches[0]['id'] if len(matches)==1 else saved.get(slot,{}).get('product_id') or (old.get(volume) if slot.startswith('bottle-') else None)
        output.append({'slot':slot,'volume':volume,'label':label,'product_id':pid,'enabled':1})
    return output

def available(d,pid):
    related=[r for r in rules(d) if r['product_id']==pid]
    return not related or any(r['enabled'] for r in related)

def is_pack(d,p):
    return p['kind']=='packaging' or any(r['product_id']==p['id'] for r in rules(d))

@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
"%~dp0runtime\python.exe" start_moysklad.py
rem Код 42: касса перезапускается, чтобы установить загруженное обновление.
:again
if errorlevel 42 if not errorlevel 43 (
    "%~dp0runtime\python.exe" start_moysklad.py --no-browser
    goto again
)
pause

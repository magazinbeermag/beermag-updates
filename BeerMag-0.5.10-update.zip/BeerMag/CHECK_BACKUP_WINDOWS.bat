@echo off
chcp 65001 >nul
cd /d "%~dp0"
if "%~1"=="" (
    echo Перетащите файл на CHECK_BACKUP_WINDOWS.bat
    pause
    exit /b 1
)
if not exist "%~dp0runtime\python.exe" (
    echo Встроенный Python не найден. Распакуйте архив полностью.
    pause
    exit /b 1
)
"%~dp0runtime\python.exe" check_backup.py "%~1"
pause

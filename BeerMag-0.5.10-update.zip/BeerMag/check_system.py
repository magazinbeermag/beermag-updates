"""Read-only preflight report for a single BeerMag register."""
import os
import shutil
import sqlite3
import sys
import tempfile
import time
from contextlib import closing
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def inspect(root=ROOT, database=None, backup_dir=None):
    root=Path(root)
    database=Path(database) if database else Path(os.environ.get('BEERDESK_DB',root/'data'/'beerdesk.sqlite3'))
    backup_dir=Path(backup_dir) if backup_dir else Path(os.environ.get('BEERMAG_BACKUP_DIR',database.parent/'backups'))
    report=[]
    def add(level,message):report.append((level,message))
    if sys.version_info<(3,11):add('ОШИБКА','Нужен Python 3.11 или новее.')
    else:add('OK','Python '+sys.version.split()[0]+'.')
    if not database.is_file():
        add('ВНИМАНИЕ','База ещё не создана. Запустите BeerMag и настройте управляющего.')
    else:
        try:
            with closing(sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True,timeout=2)) as db:
                if db.execute('PRAGMA quick_check').fetchone()[0]!='ok':
                    raise sqlite3.DatabaseError('Нарушена целостность SQLite.')
                tables={row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not {'users','documents','ms_outbox','ms_options','ms_state'}.issubset(tables):
                    raise sqlite3.DatabaseError('В базе нет необходимых таблиц BeerMag.')
                add('OK','База данных читается и прошла проверку целостности.')
                if db.execute('SELECT COUNT(*) FROM users').fetchone()[0]==0:
                    add('ВНИМАНИЕ','Управляющий ещё не настроен.')
                if not db.execute('SELECT 1 FROM ms_state LIMIT 1').fetchone():
                    add('ВНИМАНИЕ','Каталог МоегоСклада ещё не синхронизирован.')
                elif not db.execute("SELECT 1 FROM ms_options WHERE key='register_retail_id'").fetchone():
                    if db.execute("SELECT 1 FROM ms_employees m JOIN users u ON u.id=m.user_id WHERE u.active=1 AND m.remote_archived=0 AND u.shops NOT IN ('[]','') LIMIT 1").fetchone():
                        add('OK','Торговая точка выбирается автоматически по назначению кассира в МоемСкладе.')
                    else:add('ВНИМАНИЕ','Нет активного кассира с торговой точкой из МоегоСклада.')
                retry=db.execute("SELECT COUNT(*) FROM ms_outbox WHERE status='retry'").fetchone()[0]
                pending=db.execute("SELECT COUNT(*) FROM ms_outbox WHERE status='pending'").fetchone()[0]
                if retry:add('ВНИМАНИЕ',f'Ошибок передачи: {retry}. Проверьте очередь от имени управляющего.')
                if pending:add('ВНИМАНИЕ',f'Ожидают передачи: {pending}. Дождитесь подтверждения.')
                if not retry and not pending:add('OK','Непереданных операций нет.')
        except sqlite3.Error as error:
            add('ОШИБКА','База не прошла проверку: '+str(error))
    try:
        backup_dir.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryFile(dir=backup_dir):pass
        backups=[p for p in backup_dir.glob('*.sqlite3') if p.is_file()]
        if not backups:add('ВНИМАНИЕ','В папке копий ещё нет резервной копии: '+str(backup_dir))
        else:
            latest=max(backups,key=lambda p:p.stat().st_mtime)
            if time.time()-latest.stat().st_mtime>2*3600:
                add('ВНИМАНИЕ','Последняя копия старше двух часов: '+str(latest))
            else:add('OK','Резервная копия найдена: '+str(latest))
    except OSError:
        add('ОШИБКА','Нельзя записать резервную копию в '+str(backup_dir))
    try:
        free=shutil.disk_usage(database.parent if database.parent.exists() else root).free
        if free<100*1024**2:add('ОШИБКА','Свободного места меньше 100 МБ.')
        elif free<1024**3:add('ВНИМАНИЕ','Свободного места меньше 1 ГБ.')
        else:add('OK','Свободного места больше 1 ГБ.')
    except OSError:add('ОШИБКА','Не удалось проверить свободное место.')
    return report


def main():
    report=inspect()
    print('BeerMag — проверка этого компьютера (без подключения к МоемСкладу)\n')
    for level,message in report:print('['+level+'] '+message)
    print('\nПроверка не отправляет данные и не раскрывает API-токен.')
    return 1 if any(level=='ОШИБКА' for level,_ in report) else 0


if __name__=='__main__':raise SystemExit(main())

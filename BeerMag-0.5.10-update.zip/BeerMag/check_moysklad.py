"""Read-only MoySklad connectivity and catalogue preflight. Never writes a document."""
import argparse
import getpass
import os
import sqlite3
from contextlib import closing
from pathlib import Path

import catalog_import
import moysklad


def saved_price_name():
    path=Path(os.environ.get('BEERDESK_DB',str(Path(__file__).resolve().parent/'data'/'beerdesk.sqlite3')))
    if not path.is_file():return 'Цена продажи'
    try:
        with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as db:
            row=db.execute('SELECT price_name FROM ms_state LIMIT 1').fetchone()
            return row[0] if row else 'Цена продажи'
    except sqlite3.Error:return 'Цена продажи'


def inspect(client,price_name):
    points=client.references()
    if not points:raise moysklad.SyncError('Не найдены активные торговые точки со складом и организацией.')
    products=catalog_import.prepare(client.catalog(price_name),[],include_all=True)
    staff=client.employees()
    folders=client.folders()
    errors=sum(item['state']=='error' for item in products)
    ready=sum(item['state']=='ready' for item in products)
    return {'points':len(points),'products':len(products),'ready':ready,'errors':errors,
            'employees':len(staff),'folders':len(folders)}


def main(argv=None):
    parser=argparse.ArgumentParser(description='Проверка чтения из МоегоСклада без записи документов')
    parser.add_argument('--price-name',help='Название цены (по умолчанию: цена текущей кассы)')
    args=parser.parse_args(argv)
    if not os.environ.get('BEERMAG_MOYSKLAD_TOKEN','').strip():
        print('Введите API-токен МоегоСклада. Он не сохраняется и не печатается.')
        token=getpass.getpass('API-токен: ').strip()
        if not token:
            print('Токен не введён.')
            return 1
        os.environ['BEERMAG_MOYSKLAD_TOKEN']=token
        del token
    name=(args.price_name or saved_price_name()).strip()
    if not name:
        print('Название цены пустое.')
        return 1
    try:
        print('Проверяю чтение справочников МоегоСклада; это может занять несколько минут...',flush=True)
        result=inspect(moysklad.Client(),name)
    except moysklad.SyncError as error:
        print('ОШИБКА: '+str(error))
        return 1
    except (KeyError,TypeError,ValueError) as error:
        print('ОШИБКА: данные API требуют проверки ('+type(error).__name__+').')
        return 1
    print('Торговые точки: {points}; карточки: {products} (готовы: {ready}, конфликты: {errors}); '
          'сотрудники: {employees}; группы: {folders}.'.format(**result))
    if result['errors']:
        print('ВНИМАНИЕ: найдены конфликты каталога. Проверьте карточки в кассе перед синхронизацией.')
        return 1
    print('Чтение API и разбор каталога прошли. Запись продаж и инвентаризаций не проверялась.')
    return 0


if __name__=='__main__':raise SystemExit(main())

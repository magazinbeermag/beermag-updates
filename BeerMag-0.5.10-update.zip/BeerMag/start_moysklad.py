"""Remember the API token with Windows DPAPI for this Windows user and computer."""
import getpass
import os
import runpy
import sys
from pathlib import Path

TOKEN_FILE=Path(__file__).with_name('data')/'moysklad-token.dpapi'

def dpapi(data,protect):
    if os.name!='nt':raise OSError('Сохранение токена доступно только в Windows.')
    import ctypes
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_ubyte))]
    source=(ctypes.c_ubyte*len(data)).from_buffer_copy(data)
    input_blob=Blob(len(data),source);output_blob=Blob()
    crypt=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    fn=crypt.CryptProtectData if protect else crypt.CryptUnprotectData
    fn.restype=wintypes.BOOL
    fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_wchar_p if protect else ctypes.c_void_p,
                 ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
    kernel.LocalFree.restype=ctypes.c_void_p
    kernel.LocalFree.argtypes=[ctypes.c_void_p]
    if not fn(ctypes.byref(input_blob),'BeerMag MoySklad' if protect else None,None,None,None,1,ctypes.byref(output_blob)):
        raise OSError(ctypes.get_last_error(),'Не удалось защитить или прочитать API-токен Windows.')
    try:return ctypes.string_at(output_blob.pbData,output_blob.cbData)
    finally:kernel.LocalFree(ctypes.cast(output_blob.pbData,ctypes.c_void_p))

def saved_token():
    if not TOKEN_FILE.exists():return ''
    try:return dpapi(TOKEN_FILE.read_bytes(),False).decode('utf-8').strip()
    except (OSError,UnicodeError):
        print('Сохранённый токен недоступен этому пользователю Windows. Введите токен заново.')
        return ''

def save_token(token):
    TOKEN_FILE.parent.mkdir(parents=True,exist_ok=True)
    encrypted=dpapi(token.encode('utf-8'),True)
    temporary=TOKEN_FILE.with_suffix('.tmp')
    try:
        temporary.write_bytes(encrypted)
        os.replace(temporary,TOKEN_FILE)
    finally:temporary.unlink(missing_ok=True)

if __name__ == '__main__':
    if '--reset-token' in sys.argv:
        TOKEN_FILE.unlink(missing_ok=True)
        sys.argv.remove('--reset-token')
    app='--app' in sys.argv
    if app:sys.argv.remove('--app')   # запуск из приложения: без консоли, токен вводится в окне кассы
    token=os.environ.get('BEERMAG_MOYSKLAD_TOKEN','').strip() or saved_token()
    if not token and not app:
        print('BeerMag: первый запуск. Введите API-токен МоегоСклада (символы скрыты).')
        token=getpass.getpass('API-токен: ').strip()
        if not token: raise SystemExit('Токен не введён. Запуск отменён.')
        try:save_token(token)
        except OSError:print('Токен не удалось сохранить. В следующий раз его нужно будет ввести снова.')
    if token:os.environ['BEERMAG_MOYSKLAD_TOKEN']=token
    del token
    # A signed update downloaded earlier is installed now, before the register starts.
    try:
        import autoupdate
        installed=autoupdate.apply_pending()
        if installed:
            print('Установлено обновление BeerMag '+installed+'.',flush=True)
            # Касса должна загрузить уже новые файлы, а не модули прежней версии из памяти.
            for name in ('autoupdate','update','app_lock'):sys.modules.pop(name,None)
    except Exception as error:
        print('Обновление не установлено: '+str(error)+'. Касса запускается в прежней версии.',flush=True)
    runpy.run_path(str(Path(__file__).with_name('server.py')),run_name='__main__')

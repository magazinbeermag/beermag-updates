"""Run an isolated, offline BeerMag demo with synthetic data."""
import json
import os
import runpy
import sys
import uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parent
# Never inherit production credentials or a production database path.
os.environ.pop('BEERMAG_MOYSKLAD_TOKEN',None)
os.environ['BEERMAG_DEMO']='1'
os.environ['BEERDESK_DB']=str(ROOT/'demo_data'/'beermag-demo.sqlite3')
import server

def folder_id(path):return str(uuid.uuid5(uuid.NAMESPACE_URL,'beermag-demo/folder/'+path))

def seed():
    server.init()
    with server.connection(True) as d:
        if d.execute('SELECT 1 FROM users LIMIT 1').fetchone():return False
        org=d.execute("INSERT INTO organizations(name,inn) VALUES('Демо ИП · учебные данные','')").lastrowid
        for n in range(1,12):
            d.execute('INSERT INTO shops(name,organization_id) VALUES(?,?)',(f'Демо магазин {n:02d}',org))
        manager=d.execute('INSERT INTO users(login,name,password,role,shops) VALUES(?,?,?,?,?)',
            ('demo','Демо управляющий',server.password_hash('demo-manager-123'),'manager',json.dumps(list(range(1,12))))).lastrowid
        seller=d.execute('INSERT INTO users(login,name,password,role,shops) VALUES(?,?,?,?,?)',
            ('seller','Демо продавец',server.password_hash('demo-seller-123'),'seller','[1]')).lastrowid
        d.execute("INSERT INTO suppliers(name) VALUES('Демо поставщик')")
        categories=['Пиво розлив','Пиво розлив/Светлое','Пиво розлив/Светлое/Лагер',
            'Пиво розлив/Тёмное','Напитки','Напитки/Лимонады','Закуски','Закуски/Рыба',
            'Закуски/Орехи','ТАРА','Пустая группа']
        for path in categories:
            parent=path.rsplit('/',1)[0] if '/' in path else ''
            d.execute('INSERT INTO ms_folders(remote_id,name,path,archived,parent_id) VALUES(?,?,?,?,?)',
                (folder_id(path),path.rsplit('/',1)[-1],path,0,folder_id(parent) if parent else ''))
        # Names, prices and quantities here are invented. Codes for packaging follow the POS rules.
        goods=[
            ('Лагер светлый · демо','draft',18000,'101','Пиво розлив/Светлое/Лагер'),
            ('Лагер янтарный · демо','draft',21000,'102','Пиво розлив/Светлое/Лагер'),
            ('Пшеничное · демо','draft',22000,'103','Пиво розлив/Светлое'),
            ('Портер · демо','draft',25000,'104','Пиво розлив/Тёмное'),
            ('Вишнёвый эль · демо','draft',24000,'105','Пиво розлив'),
            ('Лимонад тархун · демо','draft',13000,'106','Напитки/Лимонады'),
            ('Лимонад цитрус · демо','draft',14000,'107','Напитки/Лимонады'),
            ('Вода газированная · демо','piece',6500,'108','Напитки'),
            ('Сухарики чесночные · демо','piece',8500,'201','Закуски'),
            ('Чипсы · демо','piece',10500,'202','Закуски'),
            ('Кальмар сушёный · демо','weight',175000,'203','Закуски/Рыба'),
            ('Судак сушёный · демо','weight',240000,'204','Закуски/Рыба'),
            ('Фисташки · демо','weight',160000,'205','Закуски/Орехи'),
            ('Арахис · демо','weight',65000,'206','Закуски/Орехи'),
            ('Стаканчик 0,5 л · демо','piece',500,'01970','ТАРА'),
            ('ПЭТ бутылка 0,5 л · демо','packaging',1600,'02227','ТАРА'),
            ('ПЭТ бутылка 1 л · демо','packaging',1800,'02064','ТАРА'),
            ('ПЭТ бутылка 1,5 л · демо','packaging',2000,'01383','ТАРА'),
            ('ПЭТ бутылка 2 л · демо','packaging',2200,'00269','ТАРА'),
            ('Стаканчик 0,2 л · демо','piece',200,'01712','ТАРА'),
            ('ПЭТ бутылка 5 л · демо','piece',4800,'00603','ТАРА'),
            ('Пакет Майка · демо','piece',600,'01872','ТАРА')]
        ids={}
        for name,kind,price,code,category in goods:
            ids[code]=d.execute('''INSERT INTO products(name,kind,price,barcode,source_code,category,source_folder_uuid)
                VALUES(?,?,?,?,?,?,?)''',(name,kind,price,'299'+code.zfill(9)+'0',code,category,folder_id(category))).lastrowid
        manager_user=server.one(d,'SELECT * FROM users WHERE id=?',(manager,))
        for shop in range(1,12):
            receipt=server.newdoc(d,manager_user,'receipt',shop,{'supplier':{'name':'Демо поставщик'},
                'number':f'DEMO-{shop:02d}','date':server.now(),'lines':[],'total':0},'posted')
            for _,kind,_,code,_ in goods:
                stock=12000 if kind=='draft' else 8000 if kind=='weight' else 25000
                server.movement(d,receipt,ids[code],stock)
        # A couple of historic receipts make the sales screen useful immediately.
        seller_user=server.one(d,'SELECT * FROM users WHERE id=?',(seller,))
        shift=d.execute('INSERT INTO shifts(shop_id,user_id,opened,closed) VALUES(?,?,?,?)',
            (1,seller,server.now(),server.now())).lastrowid
        for code,payment in [('101','cash'),('103','card')]:
            p=server.one(d,'SELECT * FROM products WHERE id=?',(ids[code],))
            bottle=server.one(d,'SELECT * FROM products WHERE id=?',(ids['02227'],))
            total=p['price']//2+bottle['price']
            lines=[{'product_id':bottle['id'],'name':bottle['name'],'kind':'packaging','qty':1000,'price':bottle['price'],'total':bottle['price'],'group':0},
                   {'product_id':p['id'],'name':p['name'],'kind':'draft','qty':500,'price':p['price'],'total':p['price']//2,'group':0}]
            doc=server.newdoc(d,seller_user,'sale',1,{'lines':lines,'total':total,
                'payment':payment,'received':total,'change':0,'shift_id':shift,
                'organization':{'name':'Демо ИП · учебные данные','inn':''}},'posted')
            for line in lines:server.movement(d,doc,line['product_id'],-line['qty'])
    return True

if __name__=='__main__':
    created=seed()
    print('\nBeerMag ДЕМО · все данные вымышлены · МойСклад не подключён')
    if created:print('Создана отдельная демо база, рабочие данные не затронуты.')
    print('Управляющий: demo / demo-manager-123')
    print('Продавец: seller / demo-seller-123')
    print('Для сброса демо закройте программу и удалите папку demo_data.\n',flush=True)
    sys.argv=[str(ROOT/'server.py'),'--port','8766',*sys.argv[1:]]
    runpy.run_path(str(ROOT/'server.py'),run_name='__main__')
